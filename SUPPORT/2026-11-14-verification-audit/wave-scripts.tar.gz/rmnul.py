import os
p = "\\\\?\\C:\\Users\\<USER>\\Practice_runs\\cryptohack_org\\_REPO_BUILD\\cryptohack.org-Qwen3.8-ai-campaign-05OCT26-10NOV26\\nul"
try:
    os.remove(p)
    print("nul removed")
except Exception as e:
    print("nul:", e)
