import socket, json, sys
host, port = 'socket.cryptohack.org', 13371
BVAL = sys.argv[1]
s = socket.create_connection((host, port), timeout=15)
s.settimeout(10)
buf = b''
def rdlines():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:100]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
first = rdlines()
amsg = json.loads(first[0].split('Intercepted from Alice:',1)[1])
# relay Alice honestly to Bob
s.sendall((json.dumps({"p": amsg['p'], "g": amsg['g'], "A": amsg['A']}) + '\n').encode())
r = rdlines()
bob = '\n'.join(r).split('Intercepted from Bob:',1)[1].split('<')[0].strip()
# inject bad B toward Alice
inj = json.dumps({"B": BVAL})
s.sendall((inj + '\n').encode())
print("injected to Alice:", inj)
allr = []
for i in range(3):
    rr = rdlines(); allr += rr
    print("RESP%d:" % i, [l[:700] for l in rr])
    if any('<EOF>' in l for l in rr): break
s.close()
