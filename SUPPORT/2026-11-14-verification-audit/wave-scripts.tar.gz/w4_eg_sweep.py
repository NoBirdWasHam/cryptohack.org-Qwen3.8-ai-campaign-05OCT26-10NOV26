import re, hashlib, sys
from Crypto.Cipher import AES
from Crypto.Util import Padding as P
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
txt = open('eg_relay_DH64.txt').read()
p  = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
g  = int(re.search(r'"g": "0x([0-9a-f]+)"', txt).group(1), 16)
A  = int(re.search(r'"A": "0x([0-9a-f]+)"', txt).group(1), 16)
B  = int(re.search(r'"B": "0x([0-9a-f]+)"', txt).group(1), 16)
iv = re.search(r'"iv": "([0-9a-f]+)"', txt).group(1)
ct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt).group(1)
ivb, ctb = bytes.fromhex(iv), bytes.fromhex(ct)
import sympy
fac = sympy.factorint(p-1)
print("p-1 factors:", fac)

def bsgs(gx, hx, q):
    from math import isqrt
    m = isqrt(q) + 1
    table = {}; e = 1
    for j in range(m):
        table.setdefault(e, j); e = e * gx % p
    gm = pow(gx, m, p); cur = hx
    for i in range(m + 1):
        if cur in table:
            x = (table[cur] - i*m) % q
            if pow(gx, x, p) == hx: return x
        cur = cur * gm % p
    raise RuntimeError("bsgs")

a = 0; mod = 1
for q, e in fac.items():
    pe = q**e
    gq = pow(g, (p-1)//pe, p); hq = pow(A, (p-1)//pe, p)
    if q > 10**9 and e == 1:
        xi = bsgs(gq, hq, q)
    else:
        xi = 0
        gqq = pow(gq, pe//q, p)
        for k in range(e):
            rem = hq * pow(gq, -xi, p) % p
            hk = pow(rem, pe//(q**(k+1)), p)
            xi += bsgs(gqq, hk, q) * (q**k)
    a = (a + mod * ((xi - a) * pow(mod, -1, pe) % pe)) % (mod*pe); mod *= pe
assert pow(g, a, p) == A
S = pow(B, a, p)
print("S =", S)
# KDF variant sweep
cands = {}
sinp = str(S)
for iname, inp in [('str', sinp.encode()), ('hex', format(S,'x').encode()),
                   ('0xhex', format(S,'#x').encode()),
                   ('bytes', S.to_bytes((S.bit_length()+7)//8, 'big')),
                   ('bytes_be8', S.to_bytes(8,'big'))]:
    for hname, H in [('sha1', hashlib.sha1), ('md5', hashlib.md5), ('sha256', hashlib.sha256)]:
        dg = H(inp).digest()
        cands[f'{hname}({iname})[:16]'] = dg[:16]
        cands[f'{hname}({iname})[16:32]'] = dg[16:32]
        cands[f'{hname}({iname})full'] = dg
        cands[f'{hname}({iname}).hex[:16]'] = H(inp).hexdigest()[:16].encode()
for name, key in cands.items():
    if len(key) not in (16, 24, 32): continue
    try:
        pt = AES.new(key, AES.MODE_CBC, ivb).decrypt(ctb)
    except Exception:
        continue
    last = pt[-1]
    if 1 <= last <= 16 and all(b == last for b in pt[-last:]) and b'crypto' in pt:
        print("HIT", name, pt)
    elif b'crypto' in pt or b'{' in pt:
        print("partial", name, pt[:40])
print("done sweep")
