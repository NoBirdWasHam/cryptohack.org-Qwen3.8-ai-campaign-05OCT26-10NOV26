import socket, sys
s = socket.create_connection(('socket.cryptohack.org', 13379), timeout=20)
s.settimeout(15)
buf = b''
out = []
while True:
    try: d = s.recv(65536)
    except socket.timeout:
        out.append('<TIMEOUT buf=%r>' % buf[:120]); break
    if not d:
        out.append(buf.decode(errors='replace')); break
    buf += d
    while b'\n' in buf:
        ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace'))
open('eg_capture.txt','w').write('\n'.join(out))
print('\n'.join(x[:400] for x in out))
