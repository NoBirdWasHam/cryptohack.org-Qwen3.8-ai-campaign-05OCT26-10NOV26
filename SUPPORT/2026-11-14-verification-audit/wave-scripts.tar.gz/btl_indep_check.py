import sys
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch")
src = open(r"~/AppData/Local/hermes/cache/scratch/btl_velu_check.py").read()
ns = {}; exec(src.split("random.seed(7)")[0], ns)
F2 = ns['F2']
p = 92935740571
f = F2(p)

def jinv(A, B):
    a2, a4 = A, B
    b2 = f.sm(a2, 4); b4 = f.sm(a4, 2); b6 = (0, 0)
    b8 = f.sub((0,0), f.sq(a4))
    c4 = f.sub(f.sq(b2), f.sm(b4, 24))
    D = f.add(f.add(f.sm(f.mul(f.sq(b2), b8), -1), f.sm(f.mul(f.sq(b4), b4), -8)),
              f.add(f.sm(f.sq(b6), -27), f.sm(f.mul(b2, f.mul(b4, b6)), 9)))
    return f.mul(f.mul(c4, c4), f.mul(c4, f.inv(D)))

# Step 1: Vélu 2-isogeny E: y^2=x^3+x  (kernel {(0,0),O}) -> E1: y^2 = x^3 - 2x^2 + x
A1, B1 = (-2, 0), (1, 0)
j1 = jinv(A1, B1)
print("j1 =", j1, "(expect 64)")

# Step 2: find u with j1 == j2(u) for E2: y^2 = x^3 + u^2*A1 x + u^3 (dual family)
found = None
for u in range(1, 300):
    Au = f.mul(f.sq((u, 0)), A1)
    Bu = f.mul(f.pow((u, 0), 3), (1, 0))
    if jinv(Au, Bu) == j1:
        found = u; break
print("u =", found)
assert found is not None
u = (found, 0)
A2 = f.mul(f.sq(u), A1); B2 = f.mul(f.pow(u, 3), (1, 0))

# Step 3: dual 2-isogeny on E2 at its kernel point (0,0): codomain y^2 = x^3 + (A2 + 5*0? )
# Vélu 2: kernel (0,0): A' = A + 5a, a = A2, alpha=0 -> A' = 6*A2? standard dual of earlier: E2-> y^2 = x^3 + 6*A2 x^2 + (9*A2^2? ...). Use general Vélu-2: for kernel x-coord g with g^3+A g^2+B g + C=0 (C=0 here g=0):
# Vélu: t = 3g^2 + 2Ag + B = A2 (B=a?? here B = 9A2^2?? ) -- recompute properly:
# E2: y^2 = x^3 + A2 x^2 + B2 x, g=0 root: g' = -A2 - g = -A2
# Vélu: v = 3g^2 + 2 A2 g + B2 = B2 ; w = 2g^3 + A2 g^2 = 0? standard:
# x' = x + (v(x - g) - w)/... for single nonzero kernel point Q=(g,·):
#   x' = x + (3 g^2 + 2 A g + B)/(x-g) - (2 g^3 + A g^2)/(x-g)^2?? (sign conv) -> with g=0: x' = x + B2/x
# codomain: A' = A - 5B2? ; B' = -B2 - 2 A B2? Use known dual formula instead: for E: x^3+A x^2+Bx with B = a (from step1 pattern)
# Safer: derive by matching: Vélu 2 (kernel g=0): A' = A - 5*B? B' = -B - 2*A*B? Check on step1 inverse: E1 (A=-2,B=1): A' should = 0? (back to E: A=0,B=1)
def velu2(A, B):
    Ap = f.sub(A, f.sm(B, 5))
    Bp = f.sub(f.sm(B, -1), f.sm(f.mul(A, B), 2))
    return Ap, Bp
A3c, B3c = velu2(A1, B1)
print("sanity dual-from-E1 (expect 0,1):", A3c, B3c)
A3, B3 = velu2(A2, B2)
j3 = jinv(A3, B3)
print("j3 =", j3)
target = (91493879515, 48495725269)
print("MATCHES SCAN RESULT:", j3 == target)
