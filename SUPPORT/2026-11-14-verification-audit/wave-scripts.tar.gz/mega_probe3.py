import socket, json, random
from Crypto.Util.number import long_to_bytes

class Stream:
    def __init__(self, s):
        self.s = s; self.buf = b""
    def line(self):
        while b"\n" not in self.buf:
            d = self.s.recv(65536)
            if not d: return None
            self.buf += d
        ln, self.buf = self.buf.split(b"\n", 1)
        return ln.decode(errors="replace")
    def json(self):
        while True:
            ln = self.line()
            if ln is None: raise RuntimeError("EOF")
            t = ln.strip()
            if t.startswith("{") and t.endswith("}"):
                try: return json.loads(t)
                except Exception: pass
            elif t: pass
    def send(self, obj):
        self.s.sendall((json.dumps(obj) + "\n").encode())

s = socket.create_connection(("socket.cryptohack.org", 13409), timeout=60)
st = Stream(s)
material = st.json()
n, e = material["share_key_pub"]
st.send({"action": "wait_login"}); st.json()
s_small = 12345678901234567890
m_true = n - s_small
ct = pow(s_small, e, n) * (n - 1) % n
st.send({"action": "send_challenge",
         "SID_enc": long_to_bytes(ct).hex(),
         "share_key_enc": material["share_key_enc"],
         "master_key_enc": material["master_key_enc"]})
r = st.json()
print(json.dumps(r)[:200])
sid = bytes.fromhex(r["SID"]) if "SID" in r and r["SID"] else b""
exp = long_to_bytes(m_true)[:-16]
print("correct-oracle-match:", sid == exp)
print("len:", len(sid))
p1 = json.load(open(r"~/AppData/Local/hermes/cache/scratch/mega_fault1.json"))
m1 = int(p1["SID_hex"], 16) << 128   # top 240 bytes of earlier m'(n-1), low128 unknown
# if faulted: m'(n-1)+1 = K = p(h+1) and m'(s)+s = same K  => K known top from both consistent
# if correct: sid1 == (n-1)[:-16] and sid2 == (n-s)[:-16]
sid1 = bytes.fromhex(p1["SID_hex"])
print("sid1 match n-1:", sid1 == long_to_bytes(n - 1)[:-16], "sid2 match n-s:", sid == exp)
s.close()
