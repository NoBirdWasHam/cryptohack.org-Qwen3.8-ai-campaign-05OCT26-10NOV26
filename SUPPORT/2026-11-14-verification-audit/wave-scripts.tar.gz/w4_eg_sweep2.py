import re, hashlib, sys
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
from Crypto.Cipher import AES
txt = open('eg_relay_DH64.txt').read()
p  = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
g  = int(re.search(r'"g": "0x([0-9a-f]+)"', txt).group(1), 16)
A  = int(re.search(r'"A": "0x([0-9a-f]+)"', txt).group(1), 16)
B  = int(re.search(r'"B": "0x([0-9a-f]+)"', txt).group(1), 16)
iv = re.search(r'"iv": "([0-9a-f]+)"', txt).group(1)
ct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt).group(1)
ivb, ctb = bytes.fromhex(iv), bytes.fromhex(ct)
import sympy
fac = sympy.factorint(p-1)
def bsgs(gx, hx, q):
    from math import isqrt
    m = isqrt(q) + 1
    table = {}; e = 1
    for j in range(m):
        table.setdefault(e, j); e = e * gx % p
    gm = pow(gx, m, p); cur = hx
    for i in range(m + 1):
        if cur in table:
            x = (table[cur] - i*m) % q
            if pow(gx, x, p) == hx: return x
        cur = cur * gm % p
    raise RuntimeError("bsgs")
a = 0; mod = 1
for q, e in fac.items():
    pe = q**e
    gq = pow(g, (p-1)//pe, p); hq = pow(A, (p-1)//pe, p)
    if q > 10**9 and e == 1:
        xi = bsgs(gq, hq, q)
    else:
        xi = 0
        gqq = pow(gq, pe//q, p)
        for k in range(e):
            rem = hq * pow(gq, -xi, p) % p
            hk = pow(rem, pe//(q**(k+1)), p)
            xi += bsgs(gqq, hk, q) * (q**k)
    a = (a + mod * ((xi - a) * pow(mod, -1, pe) % pe)) % (mod*pe); mod *= pe
assert pow(g, a, p) == A
S = pow(B, a, p)
print("S =", S, " a =", a)
def hits(pt, name):
    try:
        s = pt.decode('latin1')
    except Exception:
        return
    if 'crypto' in s or ('{' in s and '}' in s and sum(c.isalnum() for c in s) > 10):
        print("HIT", name, repr(pt))
def modes(key, name):
    if len(key) not in (16,24,32): return
    for mode, mk in [('CBC', lambda: AES.new(key, AES.MODE_CBC, ivb[:min(16,len(ivb))])),
                     ('CTR', lambda: AES.new(key, AES.MODE_CTR, nonce=ivb[:8])),
                     ('OFB', lambda: AES.new(key, AES.MODE_OFB, iv=ivb[:16])),
                     ('CFB', lambda: AES.new(key, AES.MODE_CFB, iv=ivb[:16], segment_size=128))]:
        try:
            c = mk(); pt = c.decrypt(ctb); hits(pt, name+'/'+mode)
        except Exception:
            pass
inputs = {'str': str(S).encode(), 'hex': format(S,'x').encode(),
          'bytes': S.to_bytes(max(8,(S.bit_length()+7)//8), 'big')}
for iname, inp in inputs.items():
    for hn, H in [('sha1', hashlib.sha1), ('md5', hashlib.md5), ('sha256', hashlib.sha256)]:
        dg = H(inp).digest()
        modes(dg[:16], f'{hn}({iname})[:16]')
        modes(dg[16:32] if len(dg)>16 else b'', f'{hn}({iname})[16:32]')
        modes(dg, f'{hn}({iname})full')
        modes(H(inp).hexdigest()[:16].encode(), f'{hn}({iname})hexdigest[:16]')
# also sha1 twice, and raw S bytes padded
modes(S.to_bytes(16,'big'), 'Sbytes16')
modes((str(S).encode()*2)[:16], 'strrep')
print("sweep2 done")
