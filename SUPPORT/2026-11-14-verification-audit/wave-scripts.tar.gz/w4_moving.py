import sys, json, hashlib
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
from eclib import Curve, point_order, PohligHellman
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import sympy

p = 1331169830894825846283645180581
E = Curve(p-35, 98, p)  # a=-35
G = (479691812266187139164535778017, 568535594075310466177352868412)
P1 = (1110072782478160369250829345256, 800079550745409318906383650948)
P2 = (1290982289093010194550717223760, 762857612860564354370535420319)
for P_ in (G, P1, P2): assert E.on(P_)
print("points on curve ok")
# trace-0 test
assert E.mul(G, p+1) is None, "ord not dividing p+1"
fac = sympy.factorint(p+1)
print("p+1 =", fac)
ordG = point_order(E, G, fac)
print("ordG =", ordG)
fac_ord = {q:e for q,e in fac.items() if ordG % q == 0}
n_a = PohligHellman(E, G, P1, ordG, fac_ord)
assert E.mul(G, n_a) == P1, "PH failed"
S = E.mul(P2, n_a)
assert S is not None and E.on(S)
key = hashlib.sha1(str(S[0]).encode('ascii')).digest()[:16]
iv = bytes.fromhex('eac58c26203c04f68d63dc2c58d79aca')
ct = bytes.fromhex('bb9ecbd3662d0671fd222ccb07e27b5500f304e3621a6f8e9c815bc8e4e6ee6ebc718ce9ca115cb4e41acb90dbcabb0d')
pt = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(ct), 16).decode()
print("moving n_a =", n_a)
print("moving flag:", pt)
json.dump({'n_a': str(n_a), 'flag': pt}, open(r'~/AppData/Local/hermes/cache/scratch/w4_moving.json','w'))
