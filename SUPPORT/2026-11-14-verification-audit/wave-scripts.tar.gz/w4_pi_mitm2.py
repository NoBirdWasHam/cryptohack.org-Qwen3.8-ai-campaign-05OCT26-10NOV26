import socket, json, sys, hashlib, re
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

side = sys.argv[1]           # 'B' or 'A'
t = 2
s = socket.create_connection(('socket.cryptohack.org', 13371), timeout=20)
s.settimeout(20)
buf = b''
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout: out.append('<TIMEOUT>'); break
        if not d:
            out.append(buf.decode(errors='replace') + '<EOF>'); buf = b''; break
        buf += d
    return out
def find(lines, label):
    for l in lines:
        if label in l:
            body = l.split(label, 1)[1]
            j = body.find('{'); k = body.rfind('}')
            try: return json.loads(body[j:k+1])
            except Exception: return None
    return None

lines = rd()
amsg = find(lines, 'Intercepted from Alice:')
p = int(amsg['p'], 16)
log = list(lines)
if side == 'A':
    mod = dict(amsg); mod['A'] = '0x%x' % t   # A := g^t (g=2)
    s.sendall((json.dumps(mod) + '\n').encode())
    r = rd(); log += r
    bmsg = find(r, 'Intercepted from Bob:')
    s.sendall((json.dumps(bmsg) + '\n').encode())
    log += ['relay bob->alice']
    cands = {}
    if bmsg:
        Bv = int(bmsg['B'], 16)
        cands['B^t'] = pow(Bv, t, p)
else:
    s.sendall((json.dumps(amsg) + '\n').encode())
    r = rd(); log += r
    bmsg = find(r, 'Intercepted from Bob:')
    mod = dict(bmsg); mod['B'] = '0x%x' % t   # B := g^t
    s.sendall((json.dumps(mod) + '\n').encode())
    Av = int(amsg['A'], 16)
    cands = {'A^t': pow(Av, t, p)}
fin = []
for i in range(5):
    rr = rd(); fin += rr
    if any('<EOF>' in l for l in rr): break
log += fin
open('pi_%s_flow.log' % side, 'w').write('\n'.join(log))
txt = '\n'.join(fin)
print(txt[:600])
miv = re.search(r'"iv": "([0-9a-f]+)"', txt); mct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt)
if miv and mct:
    ivb, ctb = bytes.fromhex(miv.group(1)), bytes.fromhex(mct.group(1))
    cands['zero'] = 0; cands['one'] = 1
    for nm, sv in cands.items():
        key = hashlib.sha1(str(sv).encode('ascii')).digest()[:16]
        pt = AES.new(key, AES.MODE_CBC, ivb).decrypt(ctb)
        try:
            flag = unpad(pt, 16).decode('ascii')
            print("DECRYPTED %s -> %s" % (nm, flag))
        except Exception:
            print("cand %s miss: %r" % (nm, pt[:24]))
s.close()
