# Hermes-identity saturation: N threads of long streamed chat completions on the Hermes key.
# The gate admits 1 and keeps the rest waiting at the key limit -> queue permanently full,
# GPU never idle on the Hermes slot. HA keeps its reserved slot. Runs DUR seconds or until
# stop.flag appears next to this file.
import json, re, threading, time, urllib.request, pathlib

DUR = 600                      # seconds of sustained load
THREADS = 3                    # 1 admitted + waiting at the key gate; queue always full
MAX_TOKENS = 1200              # long decodes = long GPU occupancy per admission
URL = "http://192.168.1.166:8080/v1/chat/completions"
STOP = pathlib.Path(__file__).with_name("stop.flag")

# key straight from this machine's Hermes provider env file (the Hermes identity, as intended)
env = (pathlib.Path.home() / "AppData/Local/hermes/.env").read_text(encoding="utf-8")
KEY = re.search(r"HERMES_CUSTOM_QWEN3_8_FLASH_API_KEY\s*=\s*(\S+)", env).group(1).strip("'\"")

PROMPT = ("Summarize in detail, sentence by sentence, the history and engineering tradeoffs of "
          "inference engines. " + "The quick brown fox jumps over the lazy dog near the riverbank. ") * 250

lock = print_lock = threading.Lock()
end = time.time() + DUR
done = {"ok": 0, "err": 0}

def worker(n):
    body = json.dumps({"model": "strata", "messages": [{"role": "user", "content": PROMPT}],
                       "max_tokens": MAX_TOKENS, "stream": True, "temperature": 0.8}).encode()
    while time.time() < end and not STOP.exists():
        req = urllib.request.Request(URL, data=body, method="POST", headers={
            "Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=DUR) as r:
                first = None
                for chunk in r:                       # stream until generation finishes
                    if first is None:
                        first = time.time() - t0
            dt = time.time() - t0
            with lock:
                done["ok"] += 1
                print(f"[w{n}] ok  total={dt:6.1f}s  first-byte={first:7.1f}s  (wait at gate vs generate)", flush=True)
        except Exception as e:
            with lock:
                done["err"] += 1
                print(f"[w{n}] err {type(e).__name__}: {e}", flush=True)
            time.sleep(2)
    print(f"[w{n}] stopped", flush=True)

threads = [threading.Thread(target=worker, args=(i,), daemon=True) for i in range(THREADS)]
print(f"saturating {URL} for {DUR}s with {THREADS} threads on the Hermes key", flush=True)
for t in threads: t.start()
for t in threads: t.join()
print(f"finished: ok={done['ok']} err={done['err']}", flush=True)
