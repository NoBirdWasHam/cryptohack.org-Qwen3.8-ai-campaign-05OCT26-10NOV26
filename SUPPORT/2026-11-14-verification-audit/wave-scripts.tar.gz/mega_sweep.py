import socket, json
from Crypto.Util.number import long_to_bytes

class Stream:
    def __init__(self, s):
        self.s = s; self.buf = b""
    def line(self):
        while b"\n" not in self.buf:
            d = self.s.recv(65536)
            if not d: return None
            self.buf += d
        ln, self.buf = self.buf.split(b"\n", 1)
        return ln.decode(errors="replace")
    def json(self):
        while True:
            ln = self.line()
            if ln is None: raise RuntimeError("EOF")
            t = ln.strip()
            if t.startswith("{") and t.endswith("}"):
                try: return json.loads(t)
                except Exception: pass
    def send(self, obj):
        self.s.sendall((json.dumps(obj) + "\n").encode())

for i in range(10):
    try:
        s = socket.create_connection(("socket.cryptohack.org", 13409), timeout=30)
        st = Stream(s)
        material = st.json()
        n, e = material["share_key_pub"]
        st.send({"action": "wait_login"}); st.json()
        st.send({"action": "send_challenge",
                 "SID_enc": long_to_bytes(n - 1).hex(),
                 "share_key_enc": material["share_key_enc"],
                 "master_key_enc": material["master_key_enc"]})
        r = st.json()
        sid = bytes.fromhex(r["SID"]) if r.get("SID") else b""
        match = sid == long_to_bytes(n - 1)[:-16]
        print(f"conn {i}: correct-decrypt={match}", "" if match else "  <-- FAULTED!!!")
        if not match:
            json.dump({"material": material, "SID_hex": r["SID"]},
                      open(rf"~/AppData/Local/hermes/cache/scratch/mega_faulty_conn_{i}.json", "w"))
            break
        s.close()
    except Exception as ex:
        print("conn", i, "ERR", ex)
