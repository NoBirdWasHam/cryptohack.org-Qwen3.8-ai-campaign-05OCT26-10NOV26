from Crypto.PublicKey import RSA
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import random

k = RSA.generate(2048)  # default random_func -> leaks ROCA fingerprint
n = k.n
print("n bits", n.bit_length())

def k1(x):  # real modexp of 2^(2^16)
    return pow(2, pow(2, 16), x)

fp = k1(n)
r = fp % (2**32)
r = r << 16 | 0xd0d3fe37
r = r % 2**64
c = 2**63 / 538172707  # float approx, use exact fractions later
import math
from fractions import Fraction
cfrac = Fraction(2**63, 538172707)
delta = ((r - Fraction(3847, 538172707) * (2**64)) / cfrac)
delta = delta - math.floor(delta)
print("delta =", float(delta))
k2 = int(delta * 538172707 + 581268)
print("k2 =", k2, "target ~", 4096 * 163 * math.log(2))
random.seed(12345)
cands = list(range(140000, 230000))
random.shuffle(cands)
found = None
for tries in range(20000):
    s = 0
    for i in range(k2):
        s += random.choice(cands)
    if k1(n) == k1(pow(2, s, n) * 253288424756198793763517483093026293900322881270953038078039832322819301045569):
        found = s
        break
print("found s =", found, "after", tries, "tries")
if found:
    g = math.gcd(pow(2, found, n) - 254496592233, n)
    print("gcd factor:", g)
    p = g
    q = n // p if p * (n // p) == n else None
    if q:
        print("FACTORED:", p * q == n, p.bit_length(), q.bit_length())
        secret = SHA256.new(long_to_bytes(p) + long_to_bytes(q)).digest()
        FLAG = b"FLAG-REDACTED-SEE-FLAGS-MIRROR"
        ct = AES.new(secret, AES.MODE_ECB).encrypt(pad(FLAG, 16))
        dec = AES.new(secret, AES.MODE_ECB).decrypt(ct)
        print("AES roundtrip ok:", dec.startswith(b"crypto{"))
