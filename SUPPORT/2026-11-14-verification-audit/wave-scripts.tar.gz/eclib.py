"""Elliptic curve helpers: affine short-Weierstrass over Fp, order check, PH DLP (BSGS/rho)."""
import random, hashlib
from math import isqrt

class Curve:
    def __init__(self, a, b, p):
        self.a, self.b, self.p = a, b, p
    def on(self, P):
        if P is None: return True
        x, y = P
        return (y*y - (x*x*x + self.a*x + self.b)) % self.p == 0
    def inv(self, P):
        return None if P is None else (P[0], (-P[1]) % self.p)
    def add(self, P, Q):
        if P is None: return Q
        if Q is None: return P
        p = self.p
        x1, y1 = P; x2, y2 = Q
        if x1 == x2:
            if (y1 + y2) % p == 0: return None
            lam = (3*x1*x1 + self.a) * pow(2*y1, -1, p) % p
        else:
            lam = (y2 - y1) * pow(x2 - x1, -1, p) % p
        x3 = (lam*lam - x1 - x2) % p
        return (x3, (lam*(x1 - x3) - y1) % p)
    def mul(self, P, n):
        n %= (1 << 300)
        if P is None or n == 0: return None
        if n < 0: return self.mul(self.inv(P), -n)
        Q, R = P, None
        while n:
            if n & 1: R = self.add(R, Q)
            Q = self.add(Q, Q); n >>= 1
        return R
    def order_of(self, P, cand_factors):
        """order of P given dict prime->exp dividing |E|"""
        o = 1
        for q, e in cand_factors.items():
            k = q**e
            # find minimal exp of q needed
            t = self.mul(P, o)  # not helpful; do incrementally
            # compute q^f * P == O test
            f = 0
            m = self.mul(P, (o * 1))
            # simpler: for this prime power, find smallest f<=e with q^{e'} trick
            # order contribution: smallest q^f such that [o*q^f]P == O where o=product of other parts handled later
            # do the standard: start with full q^e, reduce
            pass
        # simpler full approach:
        o = 1
        for q, e in sorted(cand_factors.items()):
            pe = q**e
            # minimal f: q^f | order-part for this prime: test [N/q^f]...
            f = e
            base = self.mul(P, (pe // q))
            # accumulate: let cur = [N/q]P for total N later... do iterative:
            pass
        return None  # unused placeholder

def point_order(E, P, fac):
    """fac: dict prime->exp, with ord(P) | prod(p**e)."""
    N = 1
    for q, e in fac.items(): N *= q**e
    o = N
    for q in fac:
        while o % q == 0 and E.mul(P, o // q) is None:
            o //= q
    return o

def bsgs(E, G, H, r):
    """DLP in subgroup <G> of order dividing r: x with H=[x]G."""
    if H is None:
        return 0
    m = isqrt(r) + 1
    table = {}
    cur = None
    for j in range(m):
        if cur is not None:
            table.setdefault(cur, j)
        cur = E.add(cur, G)
    # H = [x]G, x = i*m + j  =>  H - i*m*G = [j]G
    negGm = E.inv(E.mul(G, m))
    cur = H
    for i in range(m + 1):
        if cur in table:
            x = i*m + table[cur]
            if E.mul(G, x % r) == H: return x % r
        cur = E.add(cur, negGm)
    return None

def PohligHellman(E, G, H, ordG, fac):
    """G order ordG (fac = factorization dict). Return x = log_G H."""
    x = 0
    mod = 1
    for q, e in fac.items():
        if ordG % q == 0:
            # solve n mod q^e (e = v_q(ordG))
            ee = 0; t = ordG
            while t % q == 0: t //= q; ee += 1
            pe = q**ee
            Gq = E.mul(G, ordG // pe)      # order pe
            Hq = E.mul(H, ordG // pe)
            if q**1 * ee and q <= 10**8:
                # digit-by-digit PH (fast for small q), BSGS per digit
                digit = []
                gq = E.mul(Gq, pe // q)     # order q
                gamma = Hq
                base = 1
                xj = 0
                curG = Gq
                for k in range(ee):
                    # gamma_k = H - x-part, multiply by (pe/q^{k+1})
                    hk = E.mul(E.add(Hq, E.inv(E.mul(G, xj % ordG))), pe // (q**(k+1)))
                    dk = bsgs(E, gq, hk, q)
                    xj += dk * (q**k)
                digit_x = xj % pe
            else:
                digit_x = bsgs(E, Gq, Hq, pe)  # only ok if pe small
            x = crt(x, mod, digit_x, pe)
            mod *= pe
    return x % mod

def crt(a, m, b, n):
    g = pow(m, -1, n)
    return (a + m * ((b - a) * g % n)) % (m*n)
