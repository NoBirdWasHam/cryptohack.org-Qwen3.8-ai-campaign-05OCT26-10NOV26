import hashlib, json
from Crypto.Cipher import AES

D = json.load(open("~/AppData/Local/hermes/cache/scratch/wots2/data_c1cf7f9624cc5c43e06c5c10b551a0e3.json"))

H = lambda b: hashlib.sha256(b).digest()
pub = [bytes.fromhex(p) for p in D["public_key"]]
KEY_LEN, BYTE_MAX = 32, 255

def chain(x, n):
    for _ in range(n):
        x = H(x)
    return x

# target message (deterministic from pub_key[0], per chal.py line 71)
message2 = f"{pub[0].hex()} sent 999999 WOTScoins to me".encode()
t = bytearray(H(message2))

sigs = [ [bytes.fromhex(s) for s in e["signature"]] for e in D["signatures"] ]
msgs = [e["message"].encode() for e in D["signatures"]]
digs = [ bytearray(H(m)) for m in msgs ]

# sanity: given signatures verify against public key
for j in range(len(sigs)):
    ok = all(chain(sigs[j][i], digs[j][i] + 1) == pub[i] for i in range(KEY_LEN))
    assert ok, f"sig {j} fails"

forged = []
missing = []
for i in range(KEY_LEN):
    done = False
    for j in range(len(sigs)):
        if digs[j][i] >= t[i]:
            forged.append(chain(sigs[j][i], digs[j][i] - t[i]))
            done = True
            break
    if not done:
        missing.append(i)

print("missing coords:", missing)
if not missing:
    ok = all(chain(forged[i], t[i] + 1) == pub[i] for i in range(KEY_LEN))
    print("forged signature verifies:", ok)
    if ok:
        aes_key = bytes([s[0] for s in forged])
        iv = bytes.fromhex(D["iv"])
        enc = bytes.fromhex(D["enc"])
        pt = AES.new(aes_key, AES.MODE_CBC, iv).decrypt(enc)
        print("plaintext:", pt)
        print("FLAG:", pt.rstrip(b"\x00").decode(errors="replace"))
