# Search for a working small-root lattice family: p | (A + L), |L| < 2^128, p ~ 2^1024, N ~ 2^2048
import math, random, itertools
from Crypto.PublicKey import RSA
from fpylll import IntegerMatrix
from fpylll.fplll.lll import lll_reduction
from fpylll.fplll.bkz import bkz_reduction
from fpylll.fplll.bkz_param import BKZParam

X = 1 << 128

def build_family(kind, m, C, N):
    # returns list of (coeffs_low_to_high, weight_hint)
    polys = []
    x2 = None
    if kind == "std":            # {x^i f^j N^{m-j}}
        for j in range(m + 1):
            for i in range(m - j + 1):
                c = poly_mul(poly_pow([C, 1], j), x_pow(i), pow(N, m - j))
                polys.append(c)
    elif kind == "fhkls":        # {x^i f^j N^{ceil((i+j)/2)-j}}
        for s in range(1, 2 * m + 1):
            for j in range(0, min(m, s) + 1):
                i = s - j
                e = (s + 1) // 2 - j
                if e < 0: continue
                c = poly_mul(poly_pow([C, 1], j), x_pow(i), pow(N, e))
                polys.append(c)
    return polys

def poly_mul(a, b, scale=1):
    r = [0] * (len(a) + len(b) - 1)
    for i, av in enumerate(a):
        if av:
            for j, bv in enumerate(b):
                r[i + j] += av * bv
    if scale != 1:
        r = [v * scale for v in r]
    return r

def poly_pow(p, k):
    r = [1]
    for _ in range(k):
        r = poly_mul(r, p)
    return r

def x_pow(i):
    return [0] * i + [1]

def make_matrix(polys, X):
    maxdeg = max(len(p) for p in polys) - 1
    rows = []
    for p in polys:
        row = [(p[k] if k < len(p) else 0) * pow(X, k) for k in range(maxdeg + 1)]
        rows.append(row)
    return rows

def try_solve(rows, N, C, X, use_bkz=False):
    M = IntegerMatrix.from_matrix(rows)
    if use_bkz:
        M = bkz_reduction(M, BKZParam(25))
    else:
        M = lll_reduction(M)
    roots = set()
    for row in M:
        cf = []
        ok = True
        for k in range(len(row)):
            v = int(row[k]); w = pow(X, k)
            if v % w: ok = False; break
            cf.append(v // w)
        if not ok: continue
        # integer roots via sympy
        import sympy
        xs = sympy.Symbol("x")
        poly = sum(c * xs**k for k, c in enumerate(cf) if c)
        if poly == 0: continue
        try:
            for rv in sympy.nroots(sympy.Poly(poly, xs), n=40, maxsteps=60):
                cr = complex(rv)
                if abs(cr.imag) < 1e-8 and abs(cr.real) <= X:
                    roots.add(int(round(cr.real)))
        except Exception:
            pass
    for L in roots:
        g = math.gcd(C + L, N)
        if 1 < g < N and g * (N // g) == N:
            return g, L
    return None

if __name__ == "__main__":
    random.seed(1)
    key = RSA.generate(2048)
    p, q, n = key.p, key.q, key.n
    z = random.randrange(1 << 1000, 1 << 1020)
    L0 = random.randrange(0, X)
    A = (z * p - L0) % n
    C = A
    print("target L =", L0)
    results = []
    for kind in ("std", "fhkls"):
        for m in range(2, 10 if kind == "std" else 12):
            polys = build_family(kind, m, C, n)
            if not polys: continue
            rows = make_matrix(polys, X)
            t = len(rows)
            if t > 120: continue
            r = try_solve(rows, n, C, X)
            print(kind, "m=", m, "dim=", t, "->", "HIT L=" + str(r[1]) if r else "miss")
            if r:
                results.append((kind, m))
                break
        if results: break
    print("working configs:", results)
