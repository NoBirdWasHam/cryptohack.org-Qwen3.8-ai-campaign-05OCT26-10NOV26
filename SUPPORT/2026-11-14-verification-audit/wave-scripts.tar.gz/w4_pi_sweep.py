import re, hashlib, json
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
txt = open('pi_B_flow.log').read()
miv = re.search(r'"iv": "([0-9a-f]+)"', txt); mct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt)
ivb, ctb = bytes.fromhex(miv.group(1)), bytes.fromhex(mct.group(1))
ma = re.search(r'"A": "0x([0-9a-f]+)"', txt)
A = int(ma.group(1), 16)
p = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
cands = {'A2': pow(A,2,p), 'A': A, '0':0, '1':1, 'pm1':p-1}
for nm, sv in cands.items():
    variants = {
        'str': str(sv).encode(),
        'hex': format(sv,'x').encode(),
        'bytes': sv.to_bytes(max(1,(sv.bit_length()+7)//8),'big'),
    }
    for vn, inp in variants.items():
        for hn, H in [('sha1',hashlib.sha1),('md5',hashlib.md5),('sha256',hashlib.sha256)]:
            for kname, key in [('d16',H(inp).digest()[:16]), ('full',H(inp).digest()),
                               ('hex16',H(inp).hexdigest()[:16].encode())]:
                try:
                    pt = AES.new(key[:16] if len(key)==32 else key, AES.MODE_CBC, ivb).decrypt(ctb)
                except Exception:
                    continue
                if b'crypto' in pt:
                    print("HIT", nm, vn, hn, kname, pt)
print("sweep done")
