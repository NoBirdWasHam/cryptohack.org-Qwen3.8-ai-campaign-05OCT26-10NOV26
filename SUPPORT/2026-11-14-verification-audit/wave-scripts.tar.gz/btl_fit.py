import random, json, sys
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch")
src = open(r"~/AppData/Local/hermes/cache/scratch/btl_velu_check.py").read()
ns = {}
exec(src.split("random.seed(7)")[0], ns)
EC = ns['EC']; F2 = ns['F2']

def instance(p, l, seed):
    random.seed(seed)
    ec = EC(p)
    f = ec.f
    while True:
        R = ec.rand()
        Kc = ec.mul((p + 1) // l, R)
        if Kc is not None and ec.mul(l, Kc) is None:
            K = Kc; break
    G = [K]
    for i in range(1, l): G.append(ec.add(G[-1], K))
    assert G[l-1] is None
    Gstar = G[:l-1]
    def phi(Pt):
        x, y = Pt
        sx = sy = (0, 0)
        for R in Gstar:
            S = ec.add(Pt, R)
            if S is None: return 'KERNEL'
            sx = f.add(sx, f.sub(S[0], R[0]))
            sy = f.add(sy, f.sub(S[1], R[1]))
        return (f.add(x, sx), f.add(y, sy))
    A, B = ec.rand(), ec.rand()
    imgs = []
    T = A; guard = 0
    while len(imgs) < 6 and guard < 200:
        pT = phi(T)
        if pT != 'KERNEL': imgs.append(pT)
        T = ec.add(T, B); guard += 1
    def solve3(M, b):
        n = 3
        Aa = [row[:] + [b[i]] for i, row in enumerate(M)]
        for c in range(n):
            piv = next(r for r in range(c, n) if Aa[r][c] != (0, 0))
            Aa[c], Aa[piv] = Aa[piv], Aa[c]
            ic = f.inv(Aa[c][c])
            Aa[c] = [f.mul(x, ic) for x in Aa[c]]
            for r in range(n):
                if r != c and Aa[r][c] != (0, 0):
                    fa = Aa[r][c]
                    Aa[r] = [f.sub(x, f.mul(fa, y)) for x, y in zip(Aa[r], Aa[c])]
        return [Aa[i][3] for i in range(n)]
    M = [[f.sq(u), u, (1, 0)] for (u, v) in imgs[:3]]
    b = [f.sub(f.sq(v), f.mul(f.sq(u), u)) for (u, v) in imgs[:3]]
    a2p, a4p, a6p = solve3(M, b)
    xs = [R[0] for R in Gstar]
    s = {}
    for k in range(1, 11):
        acc = (0, 0)
        for x in xs:
            v = (1, 0)
            for _ in range(k): v = f.mul(v, x)
            acc = f.add(acc, v)
        s[k] = acc
    return f, dict(s=s, a2=a2p, a4=a4p, a6=a6p, p=p, l=l)

# collect instances
insts = []
cases = []
for l in (5, 7, 13, 17, 19, 37, 41):
    q = 4*l
    found = 0
    while found < 2:
        cand = q - 1
        if all(cand % d for d in range(2, int(cand**0.5)+1)) and cand > 4*l:
            cases.append((cand, l)); found += 1
        q += 4*l
for (p, l) in cases:
    f, d = instance(p, l, seed=p*l)
    insts.append((f, d))
print("instances:", [(d['p'], d['l']) for _, d in insts])

# candidate monomial basis in sums s1..s6 (weights: s_k has weight k+1 with x^k ~ weight... ; classical: x has wt 2 (deg 2 map), s_k wt? just fit all reasonable)
def monomials(s):
    f = None
    # basis: linear terms s_k (k=1..6) and quadratic s_i s_j (i+j<=6? allow up to weight 12)
    out = {}
    for k in range(1, 7):
        out[f"s{k}"] = s[k]
    for i in range(1, 7):
        for j in range(i, 7):
            out[f"s{i}*s{j}"] = None
    return out

# fit a2': find sparsest integer-coeff combination = a2'
def fit(target, S, f, basis):
    # basis: list of (name, value); greedy exact fit over Fp2: brute small integer coeffs over subset sums? use linear algebra over Fp2 by real/imag split into Fp
    import itertools
    vals = []
    for name, val in basis:
        vals.append(val)
    # represent over Fp: target and vals as (re, im). Solve over rationals?? coefficients are integers mod p.
    # do mod-p linear algebra with Fp2 -> Fp^2 stacking
    p = f.p
    rows = []
    tgt = []
    def flat(v): return [v[0] % p, v[1] % p]
    tgt = flat(target)
    cols = [flat(v) for v in vals]
    # find minimal-support solution: try singletons, pairs, triples
    n = len(cols)
    for r in (1, 2, 3):
        for comb in itertools.combinations(range(n), r):
            # solve sum c_i v_i = t over Fp2: 2 eqs x r unknowns: need unique sol + verify on remaining instances
            pass
    return None

# simpler: print raw relations for manual solve. For each instance print s1..s6, a2,a4,a6 as (re,im).
for f, d in insts[:3]:
    print(d['p'], d['l'], {k: v for k, v in d['s'].items()}, d['a2'], d['a4'], d['a6'])
