import random, math
from fractions import Fraction
from Crypto.PublicKey import RSA
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from mega_sim2 import Client, safe_u_blocks, cf_factor, blob_layout

random.seed(5)
key = RSA.generate(2048)
C = Client(key)
n, e = key.n, key.e
p, q = key.p, key.q
blocks = safe_u_blocks(key, len(C.blob))
print("blocks", blocks, "bloblen", len(C.blob), "u-reg", blob_layout(key)["u"])
X0 = random.getrandbits(890) | (1 << 897)
x = X0 << 128
ct = long_to_bytes(pow(x, e, n))
fb = random.choice(blocks)
flipval = get_random_bytes(16)
sid = C.login_step2(ct, C.blob, C.mke, flip_block=fb, flipval=flipval)
print("sid len", len(sid))
H = bytes_to_long(sid) * (1 << 128)
# ground truth m'
blob = bytearray(C.blob); blob[fb*16:(fb+1)*16] = flipval
# recompute m' directly: replicate with flipped u
share_key = unpad(AES.new(C.master, AES.MODE_ECB).decrypt(bytes(blob)), 16)
index=0; els=[]
while index < len(share_key):
    ln = bytes_to_long(share_key[index:index+2]); index+=2
    els.append(bytes_to_long(share_key[index:index+ln])); index+=ln
pp,qq,dd,uu = els
ctint = bytes_to_long(ct)
mp = pow(ctint, dd%(pp-1), pp); mq = pow(ctint, dd%(qq-1), qq)
h = ((mq-mp)%qq*uu)%qq
m_true = h*pp+mp
L = m_true % (1<<128)
print("m_true>>128 == H:", m_true >> 128 == H)
print("m_true % p == x % p:", m_true % p == x % p)
if (m_true - x) % p == 0:
    z = (m_true - x)//p
    print("z bits:", z.bit_length(), "q bits:", q.bit_length(), "p==pp:", pp==p)
    A = (H - x) % n
    print("A == z*p - L:", A == (z*p - L) % n)
    # convergents of N/A
    fr = Fraction(N if False else n, A)
    cf = []
    nn, dd2 = fr.numerator, fr.denominator
    convs = []
    pnm2, pnm1 = 0, 1
    qnm2, qnm1 = 1, 0
    for i in range(200):
        if dd2 == 0: break
        a = nn//dd2
        pn = a*pnm1+pnm2; qn = a*qnm1+qnm2
        convs.append((pn, qn, a))
        pnm2,pnm1 = pnm1,pn; qnm2,qnm1 = qnm1,qn
        nn,dd2 = dd2, nn-a*dd2
    hit = [i for i,(pn,qn,a) in enumerate(convs) if pn == q]
    print("convergent count", len(convs), "q as numerator at", hit)
    # where does z/q error sit
    err = abs(Fraction(n, A) - Fraction(q, z))
    print("err*log2", math.log2(float(err)), "need <", math.log2(1/(2*q*q)))
    # check error* q^2
    print("err*q^2 =", float(err)*q*q)
else:
    print("Bellcore FAILED: m' not congruent to x mod p")
    print("m_true%p", m_true % p == x % p, "pp==p?", pp==p, "qq==q", qq==q)
