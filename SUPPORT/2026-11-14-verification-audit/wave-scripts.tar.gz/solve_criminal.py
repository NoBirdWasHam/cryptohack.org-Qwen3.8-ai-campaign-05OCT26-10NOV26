import sys, json, hashlib
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
from eclib import Curve, point_order
from ecdlp2 import ph, rho, bsgs
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def dec(S, iv, ct):
    key = hashlib.sha1(str(S).encode('ascii')).digest()[:16]
    pt = AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct))
    return unpad(pt, 16).decode()

# --- self test on small curve ---
E = Curve(497, 1768, 9739)
P = (5274, 2841)
assert E.mul(P, 2) == (7284, 2107)
# brute order of P on small curve
x = P; k = 1
while x is not None:
    x = E.add(x, P); k += 1
ordP = k
fac = {}
t = ordP; d = 2
while d*d <= t:
    while t % d == 0: fac[d] = fac.get(d,0)+1; t//=d
    d += 1
if t > 1: fac[t] = fac.get(t,0)+1
Q = E.mul(P, 12345)
got = ph(E, P, Q, ordP, fac)
assert got % ordP == 12345 % ordP, (got, 12345 % ordP)
print("selftest PH ok, ordP=", ordP)

# --- criminal ---
pc = 310717010502520989590157367261876774703
Ec = Curve(2, 3, pc)
G = (179210853392303317793440285562762725654, 105268671499942631758568591033409611165)
pub = (280810182131414898730378982766101210916, 291506490768054478159835604632710368904)
B = (272640099140026426377756188075937988094, 51062462309521034358726608268084433317)
assert Ec.on(G) and Ec.on(pub) and Ec.on(B), "point not on curve"
facE = {2:2, 3:7, 139:1, 165229:1, 31850531:1, 270778799:1, 179317983307:1}
ordG = point_order(Ec, G, facE)
print("criminal ordG =", ordG)
assert Ec.mul(pub, ordG) is None and Ec.mul(B, ordG) is None, "pub/B outside <G>"
n = ph(Ec, G, pub, ordG, {q:0 for q in []} or facE) if ordG % 1 == 0 else None
# recompute v_q properly inside ph using ordG
S = Ec.mul(B, n)
assert S is not None and Ec.on(S)
flagc = dec(S[0], '07e2628b590095a5e332d397b8a59aa7', '8220b7c47b36777a737f5ef9caa2814cf20c1c1ef496ec21a9b4833da24a008d0870d3ac3a6ad80065c138a2ed6136af')
print("criminal n =", n)
print("criminal flag:", flagc)
json.dump({'n': str(n), 'flag': flagc}, open(r'~/AppData/Local/hermes/cache/scratch/criminal.json','w'))
