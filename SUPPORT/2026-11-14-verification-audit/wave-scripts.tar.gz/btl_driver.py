import subprocess, sys, struct, os
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch")
src = open(r"~/AppData/Local/hermes/cache/scratch/btl_velu_check.py").read()
ns = {}
exec(src.split("random.seed(7)")[0], ns)
EC = ns['EC']
import random

SC = r"~/AppData/Local/hermes/cache/scratch"

def setup(p, l, seed=1):
    random.seed(seed)
    ec = EC(p); f = ec.f
    while True:
        R = ec.rand()
        Kc = ec.mul((p + 1) // l, R)
        if Kc is not None and ec.mul(l, Kc) is None:
            K = Kc; break
    sqrt2 = f.sqrt((2, 0))
    A = f.sm(f.inv(sqrt2), 3)
    usq = f.sqrt(f.sm(f.inv((2, 0)), -1))
    inv3 = pow(3, p-2, p)
    A3 = f.sm(A, inv3)
    x1 = f.sub(f.mul(usq, K[0]), A3)
    # validity: y_m^2 = usq^3*y^2 equals rhs_m(x1)
    y2m = f.mul(f.mul(usq, usq), f.mul(usq, f.sq(K[1])))
    rhs = f.mul(x1, f.add(f.add(f.sq(x1), f.mul(A, x1)), (1, 0)))
    assert y2m == rhs, "x1 invalid"
    return f, ec, K, A, x1

def gt_j(f, ec, K, l):
    G = [K]
    for i in range(1, l): G.append(ec.add(G[-1], K))
    assert G[l-1] is None
    Gstar = G[:l-1]
    def phi(Pt):
        x, y = Pt
        sx = sy = (0, 0)
        for Rg in Gstar:
            S = ec.add(Pt, Rg)
            if S is None: return 'KERNEL'
            sx = f.add(sx, f.sub(S[0], Rg[0]))
            sy = f.add(sy, f.sub(S[1], Rg[1]))
        return (f.add(x, sx), f.add(y, sy))
    imgs = []
    tries = 0
    while len(imgs) < 12 and tries < 200:
        T = ec.rand(); pT = phi(T); tries += 1
        if pT != 'KERNEL': imgs.append(pT)
    def solve3(M, b):
        n = 3
        Aa = [row[:] + [b[i]] for i, row in enumerate(M)]
        for c in range(n):
            piv = next(r for r in range(c, n) if Aa[r][c] != (0, 0))
            Aa[c], Aa[piv] = Aa[piv], Aa[c]
            ic = f.inv(Aa[c][c])
            Aa[c] = [f.mul(x, ic) for x in Aa[c]]
            for r in range(n):
                if r != c and Aa[r][c] != (0, 0):
                    fa = Aa[r][c]
                    Aa[r] = [f.sub(x, f.mul(fa, y)) for x, y in zip(Aa[r], Aa[c])]
        return [Aa[i][3] for i in range(n)]
    import itertools
    M = [[f.sq(u), u, (1, 0)] for (u, v) in imgs]
    b = [f.sub(f.sq(v), f.mul(f.sq(u), u)) for (u, v) in imgs]
    for comb in itertools.combinations(range(len(imgs)), 3):
        try:
            a2p, a4p, a6p = solve3([M[i] for i in comb], [b[i] for i in comb])
            if all(f.sq(v) == f.add(f.mul(f.sq(u), u), f.add(f.mul(a2p, f.sq(u)), f.add(f.mul(a4p, u), a6p))) for (u, v) in imgs):
                break
        except StopIteration:
            continue
    b2 = f.sm(a2p, 4); b4 = f.sm(a4p, 2); b6 = f.sm(a6p, 4)
    b8 = f.sub(f.sm(f.mul(a2p, a6p), 4), f.sq(a4p))
    c4 = f.sub(f.sq(b2), f.sm(b4, 24))
    D = f.add(f.add(f.sm(f.mul(f.sq(b2), b8), -1), f.sm(f.mul(f.sq(b4), b4), -8)),
              f.add(f.sm(f.sq(b6), -27), f.sm(f.mul(b2, f.mul(b4, b6)), 9)))
    return f.mul(f.mul(c4, c4), f.mul(c4, f.inv(D)))

def run_scan(exe, p, l, A, x1, N):
    outs = []
    procs = []
    for t in range(N):
        outf = os.path.join(SC, f"part_{p}_{l}_{t}.bin")
        cmd = [exe, str(t), str(N), str(l), outf,
               str(A[0]), str(A[1]), str(x1[0]), str(x1[1])]
        procs.append(subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE))
        outs.append(outf)
    for pr in procs:
        o, e = pr.communicate(timeout=1200)
        if pr.returncode != 0:
            raise RuntimeError("scan failed: " + e.decode()[:400])
    f = ns['F2'](p)
    Sx = (0, 0); Si = (0, 0); P0 = (1, 0); H1 = (1, 0); Hm1 = (1, 0)
    for outf in outs:
        data = open(outf, "rb").read()
        vals = struct.unpack("<12Q", data[:96])
        Sxp = (vals[0], vals[1]); P0p = (vals[2], vals[3]); H1p = (vals[4], vals[5])
        Hm1p = (vals[6], vals[7]); hp_ = (vals[8], vals[9]); hpp = (vals[10], vals[11])
        Sx = f.add(Sx, Sxp); P0 = f.mul(P0, P0p); H1 = f.mul(H1, H1p); Hm1 = f.mul(Hm1, Hm1p)
        Si = f.sub(Si, f.mul(hpp, f.inv(hp_)))
    return Sx, Si, P0, H1, Hm1

def jmont(f, Ap):
    A2 = f.sq(Ap); q = f.sub(A2, (3, 0))
    num = f.sm(f.mul(f.mul(q, q), q), 256)
    return f.mul(num, f.inv(f.sub(A2, (4, 0)))), 0

def full(p, l, exe, N, seed=1):
    f, ec, K, A, x1 = setup(p, l, seed)
    Sx, Si, P0, H1, Hm1 = run_scan(exe, p, l, A, x1, N)
    sigma = f.sub(Sx, Si)
    ApCH = f.mul(P0, f.sub(A, f.sm(sigma, 3)))
    jCH, _ = jmont(f, ApCH)
    base = f.mul(f.sub(A, (2, 0)), f.inv(f.add(A, (2, 0))))
    dl = f.pow(base, l)
    ratio = f.mul(H1, f.inv(Hm1))
    dval = f.mul(dl, f.mul(f.sq(ratio), f.sq(ratio)))
    ApED = f.mul((2, 0), f.mul(f.add((1, 0), dval), f.inv(f.sub((1, 0), dval))))
    jED, _ = jmont(f, ApED)
    jgt = gt_j(f, ec, K, l)
    print(f"p={p} l={l}: jgt={jgt} jCH={jCH} {'OK' if jCH==jgt else 'BAD'} jED={jED} {'OK' if jED==jgt else 'BAD'}")
    return jCH == jgt and jED == jgt

if __name__ == "__main__":
    import subprocess as sp
    for (pp, ll) in [(19, 5), (83, 7)]:
        exe = os.path.join(SC, f"scan{pp}.exe")
        r = sp.run(["gcc", "-O2", f"-DPP={pp}", "-o", exe, os.path.join(SC, "scan.c")], capture_output=True)
        if r.returncode != 0:
            print(r.stderr.decode()[:1000]); sys.exit(1)
    ok = True
    ok &= full(19, 5, os.path.join(SC, "scan19.exe"), 3)
    ok &= full(83, 7, os.path.join(SC, "scan83.exe"), 16)
    print("ALL:", ok)
