"""CryptoHack HTTP helper (host-local; session cookie in ch_session.txt)."""
import re, time, requests

BASE = "https://cryptohack.org"
COOKIE = open(r"~/AppData/Local/hermes/cache/scratch/ch_session.txt").read().strip()
S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (host solver)", "Cookie": COOKIE})

def get(path):
    x = S.get(BASE + path, timeout=30)
    x.raise_for_status()
    return x.text

def cat(slug):
    """Return HTML for the category page containing slug (we just try all pages)."""
    for c in ["introduction","general","aes","maths","rsa","diffie-hellman","ecc",
              "hashes","web","post-quantum","isogenies","zkp","misc","ctf-archive"]:
        h = get("/challenges/" + c + "/")
        if ('data-challenge="%s"' % slug) in h:
            return c, h
    return None, None

def statement(slug, html=None):
    if html is None:
        _, html = cat(slug)
    i = html.find('data-challenge="%s"' % slug)
    j = html.find("collapsible-body", i)
    k = html.find("collapsible-header", j)
    k2 = html.find('<li class="challenge"', j)
    end = min(x for x in [k if k > 0 else 10**9, k2 if k2 > 0 else 10**9, i + 20000])
    block = html[j:end]
    text = re.sub(r"<[^>]+>", " ", block)
    text = re.sub(r"\s+", " ", text).replace("&middot;", "·").replace("&nbsp;", " ").replace("&amp;", "&")
    links = re.findall(r'href="(/static/challenges/[^"]+)"', block)
    return text, [BASE + l for l in links]

def csrf_for(slug, html=None):
    if html is None:
        _, html = cat(slug)
    # csrf input inside this challenge's form (fallback: first on page)
    i = html.find('action="/submit/%s/"' % slug)
    seg = html[i:i+2000] if i >= 0 else html
    m = re.search(r'name="_csrf_token" value="([^"]+)"', seg)
    return m.group(1) if m else None

def submit(slug, flag, sleep=15):
    """POST flag; returns (credited_bool, note). Handles rate-limit retry."""
    for attempt in range(6):
        c, h = cat(slug)
        tok = csrf_for(slug, h)
        x = S.post(BASE + "/submit/%s/" % slug,
                   data={"flag": flag, "_csrf_token": tok},
                   headers={"x-csrf-token": tok}, timeout=30)
        body = re.sub(r"<[^>]+>", " ", x.text)
        if "too fast" in body.lower():
            time.sleep(45); continue
        solved = ('id="check-%s" class="fas fa-star' % slug) in h and \
                 ('id="uncheck-%s"' % slug) not in h
        return solved, ("credited" if solved else "not-credited: " + re.sub(r"\s+", " ", body)[:80])
    return False, "rate-limited-out"

def solved(slug):
    _, h = cat(slug)
    return ('id="check-%s" class="fas fa-star' % slug) in h and ('id="uncheck-%s"' % slug) not in h
