import random, sys
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch")
src = open(r"~/AppData/Local/hermes/cache/scratch/btl_velu_check.py").read()
ns = {}
exec(src.split("random.seed(7)")[0], ns)
EC = ns['EC']; F2 = ns['F2']

def j_weier(f, a2, a4, a6):
    b2 = f.sm(a2, 4); b4 = f.sm(a4, 2); b6 = f.sm(a6, 4)
    b8 = f.sub(f.sm(f.mul(a2, a6), 4), f.sq(a4))
    c4 = f.sub(f.sq(b2), f.sm(b4, 24))
    c6 = f.add(f.add(f.sm(f.mul(f.sq(b2), b2), -1), f.sm(f.mul(b2, b4), 36)), f.sm(b6, -216))
    D = f.add(f.add(f.sm(f.mul(f.sq(b2), b8), -1), f.sm(f.mul(f.sq(b4), b4), -8)), f.add(f.sm(f.sq(b6), -27), f.sm(f.mul(b2, f.mul(b4, b6)), 9)))
    Dinv = f.inv(D)
    return f.mul(f.mul(c4, c4), f.mul(c4, Dinv)), D

def j_mont(f, Ap):
    A2 = f.sq(Ap)
    q3 = f.mul(f.sub(A2, (3, 0)), f.sub(A2, (3, 0)))
    q3 = f.mul(q3, f.sub(A2, (3, 0)))
    return f.sm(f.mul(q3, f.inv(f.sub(A2, (4, 0)))), 256)

def test(p, l, seed=1):
    random.seed(seed)
    ec = EC(p); f = ec.f
    # ground truth kernel on E_f: y^2 = x^3 + x
    while True:
        R = ec.rand()
        Kc = ec.mul((p + 1) // l, R)
        if Kc is not None and ec.mul(l, Kc) is None:
            K = Kc; break
    # ---- ground truth codomain by brute-force Velu sum + interpolation ----
    G = [K]
    for i in range(1, l): G.append(ec.add(G[-1], K))
    assert G[l-1] is None
    Gstar = G[:l-1]
    def phi(Pt):
        x, y = Pt
        sx = sy = (0, 0)
        for Rg in Gstar:
            S = ec.add(Pt, Rg)
            if S is None: return 'KERNEL'
            sx = f.add(sx, f.sub(S[0], Rg[0]))
            sy = f.add(sy, f.sub(S[1], Rg[1]))
        return (f.add(x, sx), f.add(y, sy))
    A, B = ec.rand(), ec.rand()
    imgs = []
    for _ in range(16):
        T = ec.rand()
        pT = phi(T)
        if pT != 'KERNEL': imgs.append(pT)
    us = set(u for (u, v) in imgs)
    assert len(us) >= 3
    def solve3(M, b):
        n = 3
        Aa = [row[:] + [b[i]] for i, row in enumerate(M)]
        for c in range(n):
            piv = next(r for r in range(c, n) if Aa[r][c] != (0, 0))
            Aa[c], Aa[piv] = Aa[piv], Aa[c]
            try:
                ic = f.inv(Aa[c][c])
            except Exception:
                raise StopIteration
            Aa[c] = [f.mul(x, ic) for x in Aa[c]]
            for r in range(n):
                if r != c and Aa[r][c] != (0, 0):
                    fa = Aa[r][c]
                    Aa[r] = [f.sub(x, f.mul(fa, y)) for x, y in zip(Aa[r], Aa[c])]
        return [Aa[i][3] for i in range(n)]
    M = [[f.sq(u), u, (1, 0)] for (u, v) in imgs]
    b = [f.sub(f.sq(v), f.mul(f.sq(u), u)) for (u, v) in imgs]
    import itertools
    a2p = a4p = a6p = None
    for comb in itertools.combinations(range(len(imgs)), 3):
        try:
            a2p, a4p, a6p = solve3([M[i] for i in comb], [b[i] for i in comb])
            break
        except (StopIteration, ZeroDivisionError):
            continue
    assert (a2p, a4p, a6p) != (None, None, None)
    for (u, v) in imgs:
        assert f.sq(v) == f.add(f.mul(f.sq(u), u), f.add(f.mul(a2p, f.sq(u)), f.add(f.mul(a4p, u), a6p))), "images off curve"
    jgt, Dgt = j_weier(f, a2p, a4p, a6p)

    # ---- BDLS Montgomery route ----
    sqrt2 = f.sqrt((2, 0))
    Acoef = f.sm(f.inv(sqrt2), 3)      # A = 3/sqrt(2), A^2 = 9/2
    u4 = f.sm(f.inv((2, 0)), -1)       # -1/2
    usq = f.sqrt(u4)                   # u^2 with (u^2)^2 = -1/2
    # (no u needed: verify map via y^2 scaling: y_m^2 = u6 * y_f^2 = usq^3 * y_f^2)
    # E_m: y^2 = x(x^2 + A x + 1); map x_m = usq * x_f - A/3
    inv3 = pow(3, p-2, p)
    A3 = f.sm(Acoef, inv3)
    def to_mont(Pf):
        x, y = Pf
        xm = f.sub(f.mul(usq, x), A3)
        return (xm, y)
    # check on curve on E_m (using y^2 = usq^3 * y_f^2)
    def on_mont(Pf):
        x, y = Pf
        xm = f.sub(f.mul(usq, x), A3)
        y2m = f.mul(f.mul(usq, usq), f.mul(usq, f.sq(y)))
        return y2m == f.mul(xm, f.add(f.add(f.sq(xm), f.mul(Acoef, xm)), (1, 0)))
    Pm = to_mont(K)
    assert on_mont(K), "map to Montgomery invalid"
    # Montgomery x-only addition chain for x([s]Pm)
    def mont_step(xprev, xcur):
        # xnext = (xcur^2-1)^2 / (4 xcur (xcur^2 + A xcur + 1) xprev)
        v = f.sub(f.sq(xcur), (1, 0))
        num = f.sq(v)
        w = f.add(f.add(f.sq(xcur), f.mul(Acoef, xcur)), (1, 0))
        den = f.mul(f.mul(f.sm(f.mul(xcur, w), 4), xprev), (1, 0))
        return f.mul(num, f.inv(den))
    xs = []
    x1 = Pm[0]
    x2 = f.mul(f.sq(f.sub(f.sq(x1), (1, 0))), f.inv(f.sm(f.mul(x1, f.add(f.add(f.sq(x1), f.mul(Acoef, x1)), (1,0))), 4)))
    xs.append(x1); xs.append(x2)
    for s in range(3, l):
        xprev, xcur = xs[-2], xs[-1]
        xn = f.mul(f.sq(f.sub(f.mul(xcur, x1), (1, 0))), f.inv(f.mul(xprev, f.sq(f.sub(xcur, x1)))))
        xs.append(xn)
    assert len(xs) == l - 1
    # sums/products
    Sx = (0, 0); Sinv = (0, 0); P0 = (1, 0); H1 = (1, 0); Hm1 = (1, 0)
    for x in xs:
        Sx = f.add(Sx, x)
        Sinv = f.add(Sinv, f.inv(x))
        P0 = f.mul(P0, x)
        H1 = f.mul(H1, f.sub((1, 0), x))
        Hm1 = f.mul(Hm1, f.sub(f.sm((1, 0), -1), x))
    sigma = f.sub(Sx, Sinv)
    Ap_CH = f.mul(P0, f.sub(Acoef, f.sm(sigma, 3)))
    jCH = j_mont(f, Ap_CH)
    # Edwards route: d = ((A-2)/(A+2))^l * (H1/Hm1)^4 ; A' = 2(1+d)/(1-d)
    base = f.mul(f.sub(Acoef, (2,0)), f.inv(f.add(Acoef, (2,0))))
    dl = f.pow(base, l)
    ratio = f.mul(H1, f.inv(Hm1))
    dval = f.mul(dl, f.mul(f.sq(ratio), f.sq(ratio)))
    Ap_ED = f.mul((2,0), f.mul(f.add((1,0), dval), f.inv(f.sub((1,0), dval))))
    jED = j_mont(f, Ap_ED)
    print(f"p={p} l={l}: jGT={jgt}  jCH={jCH} {'OK' if jCH==jgt else 'MISMATCH'}  jED={jED} {'OK' if jED==jgt else 'MISMATCH'}")
    return jCH == jgt and jED == jgt

ok = True
for (p, l) in [(19,5),(83,7),(103,13),(67,17),(151,19)]:
    ok &= test(p, l)
print("ALL:", ok)
