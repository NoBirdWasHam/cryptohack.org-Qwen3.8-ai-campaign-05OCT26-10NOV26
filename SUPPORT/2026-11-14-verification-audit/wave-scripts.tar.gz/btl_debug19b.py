import random, sys
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch")
src = open(r"~/AppData/Local/hermes/cache/scratch/btl_velu_check.py").read()
ns = {}
exec(src.split("random.seed(7)")[0], ns)
EC = ns['EC']
random.seed(1)
p, l = 19, 5
ec = EC(p); f = ec.f
K = None
while True:
    R = ec.rand()
    Kc = ec.mul((p + 1) // l, R)
    if Kc is not None and ec.mul(l, Kc) is None:
        K = Kc; break
print("K:", K)
sqrt2 = f.sqrt((2, 0))
Acoef = f.sm(f.inv(sqrt2), 3)
u4 = f.sm(f.inv((2, 0)), -1)
usq = f.sqrt(u4)
u = f.sqrt(usq)
inv3 = pow(3, p-2, p)
A3 = f.sm(Acoef, inv3)
x, y = K
xm = f.sub(f.mul(usq, x), A3)
ym = f.mul(f.pow(u, 3), y)
Pm = (xm, ym)
def on_m(P):
    xx, yy = P
    return f.sq(yy) == f.mul(xx, f.add(f.add(f.sq(xx), f.mul(Acoef, xx)), (1, 0)))
print("Pm on E_m:", on_m(Pm))
def addm(P, Q):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P; x2, y2 = Q
    if x1 == x2:
        if f.add(y1, y2) == (0, 0): return None
        m = f.mul(f.add(f.add(f.sm(f.sq(x1), 3), f.mul(f.sm(x1, 2), Acoef)), (1, 0)), f.inv(f.add(y1, y1)))
    else:
        m = f.mul(f.sub(y2, y1), f.inv(f.sub(x2, x1)))
    x3 = f.sub(f.sub(f.sub(f.sq(m), Acoef), x1), x2)
    y3 = f.sub(f.mul(m, f.sub(x1, x3)), y1)
    return (x3, y3)
def dbl_x(xc):
    return f.mul(f.sq(f.sub(f.sq(xc), (1,0))), f.inv(f.sm(f.mul(xc, f.add(f.add(f.sq(xc), f.mul(Acoef, xc)), (1,0))), 4)))
xs_scan = [Pm[0], dbl_x(Pm[0])]
x1m = Pm[0]
for s in range(3, l):
    xprev, xcur = xs_scan[-2], xs_scan[-1]
    xn = f.mul(f.sq(f.sub(f.mul(xcur, x1m), (1, 0))),
               f.inv(f.mul(xprev, f.sq(f.sub(xcur, x1m)))))
    xs_scan.append(xn)
Pt = Pm
xs_full = []
for s in range(1, l):
    xs_full.append(Pt[0])
    Pt = addm(Pt, Pm)
print("scan==full:", xs_scan == xs_full)
print("scan:", xs_scan)
print("full:", xs_full)

# alpha trick over R = Fq[t]/(t^2 + A t + 1): A' = -(a' + 1/a') with a' = phi_x(alpha)
def rsub(o1, o2): return (f.sub(o1[0], o2[0]), f.sub(o1[1], o2[1]))
def radd(o1, o2): return (f.add(o1[0], o2[0]), f.add(o1[1], o2[1]))
def rmul(o1, o2):
    c0 = f.sub(f.mul(o1[0], o2[0]), f.mul(o1[1], o2[1]))
    c1 = f.add(f.add(f.mul(o1[0], o2[1]), f.mul(o1[1], o2[0])),
               f.mul(f.sm(f.mul(o1[1], o2[1]), -1), Acoef))
    return (c0, c1)
def rinv(o1):
    n = f.add(f.add(f.sq(o1[0]), f.sq(o1[1])), f.mul(f.sm(f.mul(o1[0], o1[1]), -1), Acoef))
    ni = f.inv(n)
    return (f.mul(f.sub(o1[0], f.mul(o1[1], Acoef)), ni), f.mul(f.sm(o1[1], -1), ni))
alpha = ((0,0), (1,0))
oneR = ((1,0), (0,0))
zeroR = ((0,0), (0,0))
num = oneR; den = oneR
for xs in xs_scan:
    xsR = (xs, (0, 0))
    num = rmul(num, rsub(rmul(xsR, alpha), oneR))
    den = rmul(den, rsub(oneR, xsR))
alphap = rmul(alpha, rmul(num, rinv(den)))
ApGT = rsub(zeroR, radd(alphap, rinv(alphap)))
print("A' (alpha trick) =", ApGT)
AprimeGT = ApGT[0]
Sx = (0,0); Sinv = (0,0); P0 = (1,0)
for xs in xs_scan:
    Sx = f.add(Sx, xs); Sinv = f.add(Sinv, f.inv(xs)); P0 = f.mul(P0, xs)
sigma = f.sub(Sx, Sinv)
ApCH = f.mul(P0, f.sub(Acoef, f.sm(sigma, 3)))
print("A' (CH sums) =", ApCH, "match:", ApCH == AprimeGT)
def jmont(Ap):
    A2 = f.sq(Ap)
    return f.sm(f.mul(f.sq(f.sub(A2, (3,0))), f.inv(f.sub(A2, (4,0)))), 256)
print("j(A'GT) =", jmont(AprimeGT), " j(A'CH) =", jmont(ApCH), " j(A source) =", jmont(Acoef))
