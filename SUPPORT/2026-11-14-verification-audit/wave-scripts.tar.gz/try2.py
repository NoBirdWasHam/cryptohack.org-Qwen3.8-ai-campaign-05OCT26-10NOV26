import socket, json, sys
host, port = 'socket.cryptohack.org', 13371
AVAL = sys.argv[1] if len(sys.argv)>1 else '0x0'
s = socket.create_connection((host, port), timeout=15)
s.settimeout(10)
buf = b''
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:100]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
first = rd()
print("LINES:", [l[:60] for l in first])
amsg = json.loads(first[0].split('Intercepted from Alice:',1)[1])
p = amsg['p']; g = amsg['g']
inj = json.dumps({"p": p, "g": g, "A": AVAL})
s.sendall((inj + '\n').encode())
print("sent A =", AVAL)
for i in range(4):
    r = rd()
    print("RESP%d:" % i, [l[:500] for l in r])
    if not r or any('<EOF>' in l or '<TIMEOUT' in l for l in r): break
    if any('Send to Alice' in l for l in r):
        for l in r:
            if 'Send to Alice' in l:
                body = l.split('Send to Alice:',1)[1].strip()
                s.sendall((body + '\n').encode())
                print("relayed to Alice")
    if any('Send to Bob' in l for l in r):
        for l in r:
            if 'Send to Bob' in l and l.strip() != 'Send to Bob:':
                pass
s.close()
