import sys, json, hashlib, re
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

d = json.load(open(r'~/AppData/Local/hermes/cache/scratch/ch_tasks.json'))
t3 = d['dh-starter-3']['text']; t4 = d['dh-starter-4']['text']; t5 = d['dh-starter-5']['text']
def grab(t, key, nxt=None):
    m = re.search(key + r':\s*(\d+)', t)
    return int(m.group(1))
P3 = grab(t3, 'p'); a3 = grab(t3, 'a')
print("bits p3:", P3.bit_length(), "bits a3:", a3.bit_length())
A4 = grab(t4, 'A'); b4 = grab(t4, 'b'); P4 = grab(t4, 'p')
A5 = grab(t5, 'A'); b5 = grab(t5, 'b'); P5 = grab(t5, 'p')
print("bits A5,b5:", A5.bit_length(), b5.bit_length(), "p same:", P5 == P3 == P4)
out = {}
out['dh-starter-3'] = str(pow(2, a3, P3))
out['dh-starter-4'] = str(pow(A4, b4, P3))
S5 = pow(A5, b5, P5)
key = hashlib.sha1(str(S5).encode('ascii')).digest()[:16]
iv = bytes.fromhex(re.search(r"'iv': '([0-9a-f]+)'", t5).group(1))
ct = bytes.fromhex(re.search(r"'encrypted_flag': '([0-9a-f]+)'", t5).group(1))
pt = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(ct), 16).decode()
out['dh-starter-5'] = pt
json.dump(out, open(r'~/AppData/Local/hermes/cache/scratch/w4_dh.json','w'), indent=1)
for k,v in out.items(): print(k,'=',v[:120])
