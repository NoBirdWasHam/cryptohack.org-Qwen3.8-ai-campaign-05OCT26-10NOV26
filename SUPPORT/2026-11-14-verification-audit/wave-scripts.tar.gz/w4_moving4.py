# Moving problems: solve a=log_G P1 mod r via 16-way distinguished-point rho,
# PH for the smooth part, then S=[a]P2 -> AES.
import sys, json, hashlib, random, multiprocessing as mp
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
import sympy
from eclib import Curve, PohligHellman
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

p = 1331169830894825846283645180581
a = (-35) % p
b = 98
G = (479691812266187139164535778017, 568535594075310466177352868412)
P1 = (1110072782478160369250829345256, 800079550745409318906383650948)
P2 = (1290982289093010194550717223760, 762857612860564354370535420319)
iv = 'eac58c26203c04f68d63dc2c58d79aca'
ct = 'bb9ecbd3662d0671fd222ccb07e27b5500f304e3621a6f8e9c815bc8e4e6ee6ebc718ce9ca115cb4e41acb90dbcabb0d'
nE = 1331169830894823538756977170156
ordG = 103686954799254136375814
r = 1153763334005213
SMALL = ordG // r
E = Curve(a, b, p)

Gr = E.mul(G, ordG // r)
Hr = E.mul(P1, ordG // r)
assert Gr is not None and E.mul(Gr, r) is None
if Hr is None:
    a_r = 0
else:
    assert E.mul(Hr, r) is None

MASK = (1 << 14) - 1

def addp(P, Q):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P; x2, y2 = Q
    if x1 == x2:
        if (y1 + y2) % p == 0: return None
        lam = (3 * x1 * x1 + a) * pow(2 * y1, -1, p) % p
    else:
        lam = (y2 - y1) * pow(x2 - x1, -1, p) % p
    x3 = (lam * lam - x1 - x2) % p
    return (x3, (lam * (x1 - x3) - y1) % p)

def rho_worker(seed):
    rnd = random.Random(seed)
    s0 = rnd.randrange(1, r)
    t0 = rnd.randrange(1, r)
    P = addp(E.mul(Gr, s0), E.mul(Hr, t0))
    al, be = s0 % r, t0 % r
    dps = {}
    steps = 0
    budget = 4_000_000
    while steps < budget:
        steps += 1
        x = P[0] % 3 if P is not None else 0
        if P is None:
            s0 = rnd.randrange(1, r); t0 = rnd.randrange(1, r)
            P = addp(E.mul(Gr, s0), E.mul(Hr, t0)); al, be = s0, t0
            continue
        if P[0] % 3 == 0:
            P = addp(P, Gr); al = (al + 1) % r
        elif P[0] % 3 == 1:
            P = addp(P, P); al = 2 * al % r; be = 2 * be % r
        else:
            P = addp(P, Hr); be = (be + 1) % r
        if P is not None and (P[0] & MASK) == 0:
            key = P[0]
            if key in dps:
                al2, be2 = dps[key]
                if be != be2:
                    try:
                        cand = (al - al2) * pow(be2 - be, -1, r) % r
                    except ValueError:
                        continue
                    if E.mul(Gr, cand) == Hr:
                        return ('SOLVED', cand)
            else:
                dps[key] = (al, be)
    return ('DP', dps)

def main():
    fac_small = [2, 7, 271, 23687]
    # ordG squarefree: plain per-prime logs + CRT
    a_s = 0; mod_s = 1
    for q in fac_small:
        Gq = E.mul(G, ordG // q)
        Hq = E.mul(P1, ordG // q)
        assert E.mul(Gq, q) is None and Gq is not None
        from eclib import bsgs as _bsgs
        dk = _bsgs(E, Gq, Hq, q)
        assert dk is not None, "bsgs failed q=%d" % q
        assert E.mul(Gq, dk) == Hq
        a_s = sympy.ntheory.modular.crt([mod_s, q], [a_s, dk])[0]
        mod_s *= q
    a_s %= SMALL
    print("a mod SMALL =", a_s, flush=True)
    Gsm = E.mul(G, r); Hsm = E.mul(P1, r)
    assert E.mul(Gsm, a_s % SMALL) == Hsm, "PH small part failed"
    a_r = None
    global_dps = {}
    def solve_from(k, v1, v2):
        al, be = v1; al2, be2 = v2
        if be == be2: return None
        try:
            cand = (al - al2) * pow(be2 - be, -1, r) % r
        except ValueError:
            return None
        return cand if E.mul(Gr, cand) == Hr else None
    with mp.Pool(16) as pool:
        jobs = list(range(1000, 1000 + 64))
        for tag, val in pool.imap_unordered(rho_worker, jobs):
            if tag == 'SOLVED':
                a_r = val
                pool.terminate()
                break
            for k, v in val.items():
                if k in global_dps and global_dps[k] != v:
                    cand = solve_from(k, global_dps[k], v)
                    if cand is not None:
                        a_r = cand; pool.terminate(); break
                else:
                    global_dps[k] = v
            if a_r is not None: break
            print("  worker done; total DPs %d" % len(global_dps), flush=True)
    if a_r is None:
        print("rho did not solve in first batch", flush=True)
        sys.exit(1)
    print("a mod r =", a_r, flush=True)
    assert E.mul(Gr, a_r) == Hr
    a_full = sympy.ntheory.modular.crt([SMALL, r], [a_s % SMALL, a_r])
    a_full = a_full[0] % ordG
    assert E.mul(G, a_full) == P1, "full a failed"
    print("a =", a_full, flush=True)
    S = E.mul(P2, a_full)
    assert S is not None and E.on(S)
    key = hashlib.sha1(str(S[0]).encode('ascii')).digest()[:16]
    pt = unpad(AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct)), 16)
    print("MOVING FLAG:", pt.decode())
    json.dump({'a': str(a_full), 'Sx': str(S[0]), 'flag': pt.decode()},
              open(r'~/AppData/Local/hermes/cache/scratch/w4_moving.json', 'w'))

if __name__ == '__main__':
    main()
