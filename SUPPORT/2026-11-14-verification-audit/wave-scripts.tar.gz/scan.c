// scan.c : accumulate sum x_s, sum 1/x_s (via H'/H), prod x_s, H(1), H(-1) over
// s in chain t (s = t+1 mod N) for Montgomery x-only chain on y^2 = x(x^2+Ax+1).
// Usage: scan <t> <N> <l> <outfile> A_a A_b x1_a x1_b   (l = kernel order)
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifndef PP
#define PP 92935740571ULL
#endif
static const uint64_t MODP = PP;
typedef unsigned long long u64;
typedef unsigned __int128 u128;
typedef struct { u64 a, b; } E;

static inline u64 mmod(u128 x){ return (u64)(x % MODP); }
static inline u64 eadd_(u64 a, u64 b){ u64 v = a + b; if (v >= MODP) v -= MODP; return v; }
static inline u64 esub_(u64 a, u64 b){ u64 v = a + (MODP - b); if (v >= MODP) v -= MODP; return v; }
static inline E eadd(E x, E y){ E r; r.a = eadd_(x.a, y.a); r.b = eadd_(x.b, y.b); return r; }
static inline E esub(E x, E y){ E r; r.a = esub_(x.a, y.a); r.b = esub_(x.b, y.b); return r; }
static inline E emul(E x, E y){
    u64 z0 = mmod((u128)x.a * y.a);
    u64 z2 = mmod((u128)x.b * y.b);
    u64 sa = x.a + x.b; if (sa >= MODP) sa -= MODP;
    u64 sb = y.a + y.b; if (sb >= MODP) sb -= MODP;
    u64 z1 = esub_(mmod((u128)sa * sb), eadd_(z0, z2));
    E r; r.a = esub_(z0, z2); r.b = z1; return r;
}
static inline E esq(E x){ return emul(x, x); }
static inline E esm(E x, uint64_t k){ E r; r.a = mmod((u128)x.a * k); r.b = mmod((u128)x.b * k); return r; }
static inline E eneg(E x){ E r; r.a = x.a ? MODP - x.a : 0; r.b = x.b ? MODP - x.b : 0; return r; }
static uint64_t powm(uint64_t b, uint64_t e){
    uint64_t r = 1; b %= MODP;
    while (e){ if (e & 1) r = mmod((u128)r * b); b = mmod((u128)b * b); e >>= 1; }
    return r;
}
static E einv(E x){
    uint64_t n = eadd_(mmod((u128)x.a * x.a), mmod((u128)x.b * x.b));
    uint64_t ni = powm(n, MODP - 2);
    E r; r.a = mmod((u128)x.a * ni); r.b = x.b ? MODP - mmod((u128)x.b * ni) : 0; return r;
}
static E ONE = {1, 0};

static E dbl_x(E xc, E A){ // (xc^2-1)^2 / (4 xc (xc^2 + A xc + 1))
    E v = esub(esq(xc), ONE);
    E w = eadd(eadd(esq(xc), emul(A, xc)), ONE);
    E den = esm(emul(xc, w), 4);
    return emul(esq(v), einv(den));
}
static E dadd_x(E xp, E xc, E x1){ // (xc*x1-1)^2 / (xp*(xc-x1)^2)
    E t = esub(emul(xc, x1), ONE);
    E d = emul(xp, esq(esub(xc, x1)));
    return emul(esq(t), einv(d));
}

int main(int argc, char** argv){
    if (argc < 9){ fprintf(stderr, "usage: scan t N l out Aa Ab x1a x1b\n"); return 1; }
    long t = atol(argv[1]); long N = atol(argv[2]);
    uint64_t l = strtoull(argv[3], NULL, 10);
    E A; A.a = strtoull(argv[5], NULL, 10); A.b = strtoull(argv[6], NULL, 10);
    E x1; x1.a = strtoull(argv[7], NULL, 10); x1.b = strtoull(argv[8], NULL, 10);

    // seed chain x_1 .. x_{2N+2} (affine)
    E *xs = (E*)malloc(sizeof(E) * (2 * N + 3));
    xs[1] = x1; xs[2] = dbl_x(x1, A);
    for (int k = 3; k <= 2 * N + 2; k++) xs[k] = dadd_x(xs[k-2], xs[k-1], x1);
    E xN = xs[N];

    // accumulators
    E Sx = {0,0}, P0 = ONE, H1 = ONE, Hm1 = ONE, h = ONE, hp = {0,0};
    E neg1 = eneg(ONE);

    long s0 = t + 1;
    int have_first = (s0 <= l - 1);
    int have_second = (s0 + N <= l - 1);
    E prevX = xs[s0], prevZ = ONE;           // x_{s0}
    E curX  = xs[s0 + N], curZ = ONE;        // x_{s0+N}
    long s = s0 + N;

    // accumulate affine seeds xs[s0], xs[s0+N] (only if within range)
    {
        E vals[2] = { xs[s0], xs[s0 + N] };
        for (int i = 0; i < 2; i++){
            if ((i == 0 && !have_first) || (i == 1 && !have_second)) continue;
            E x = vals[i];
            Sx = eadd(Sx, x); P0 = emul(P0, x);
            H1 = emul(H1, esub(ONE, x)); Hm1 = emul(Hm1, esub(neg1, x));
            E mx = eneg(x); E hold = h; h = emul(h, mx);
            hp = eadd(emul(hp, mx), hold);
        }
    }

    const int W = 1 << 20;
    E *bufX = (E*)malloc(sizeof(E) * W);
    E *bufZ = (E*)malloc(sizeof(E) * W);
    E *bufI = (E*)malloc(sizeof(E) * W);

#define ACC(AFF) { Sx = eadd(Sx, AFF); P0 = emul(P0, AFF); \
    H1 = emul(H1, esub(ONE, AFF)); Hm1 = emul(Hm1, esub(neg1, AFF)); \
    { E mx = eneg(AFF); E hold = h; h = emul(h, mx); hp = eadd(emul(hp, mx), hold); } }

    int n = 0;
    for (;;){
        // next = (cur*xN - 1)^2 * prevZ / (prevX * (cur - xN*curZ)^2)   [projective]
        E cxNz = emul(xN, curZ);
        E u = esub(emul(curX, xN), curZ);
        E w = esub(curX, cxNz);
        E nextX = emul(esq(u), prevZ);
        E nextZ = emul(prevX, esq(w));
        s += N;
        if ((uint64_t)s > l - 1) break;
        bufX[n] = nextX; bufZ[n] = nextZ; n++;
        prevX = curX; prevZ = curZ; curX = nextX; curZ = nextZ;
        if (n == W){
            // batch invert Z: prefix
            E acc = ONE;
            for (int i = 0; i < n; i++){ bufI[i] = acc; acc = emul(acc, bufZ[i]); }
            acc = einv(acc);
            for (int i = n - 1; i >= 0; i--){ E zi = emul(bufI[i], acc); bufI[i] = zi; acc = emul(acc, bufZ[i]); }
            for (int i = 0; i < n; i++){ ACC(emul(bufX[i], bufI[i])); }
            n = 0;
        }
    }
    // flush
    if (n > 0){
        E acc = ONE;
        for (int i = 0; i < n; i++){ bufI[i] = acc; acc = emul(acc, bufZ[i]); }
        acc = einv(acc);
        for (int i = n - 1; i >= 0; i--){ E zi = emul(bufI[i], acc); bufI[i] = zi; acc = emul(acc, bufZ[i]); }
        for (int i = 0; i < n; i++){ ACC(emul(bufX[i], bufI[i])); }
    }
    FILE *fp = fopen(argv[4], "wb");
    E out[6] = { Sx, P0, H1, Hm1, h, hp };
    fwrite(out, sizeof(E), 6, fp);
    fclose(fp);
    return 0;
}
