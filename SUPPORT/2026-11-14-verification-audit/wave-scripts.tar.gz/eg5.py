import socket, json, sys, re
supported = json.loads(sys.argv[1])
s = socket.create_connection(('socket.cryptohack.org', 13379), timeout=20)
s.settimeout(30)
buf = b''
def rdlines():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT>'); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
log = []
first = rdlines(); log += first
s.sendall((json.dumps({"supported": supported}) + '\n').encode())
last_from_bob = None
last_from_alice = None
def scan(lines):
    global last_from_bob, last_from_alice
    for x in lines:
        for m in re.finditer(r'Intercepted from (Alice|Bob): (\{.*\})', x):
            if m.group(1) == 'Alice': last_from_alice = m.group(2)
            else: last_from_bob = m.group(2)
for i in range(8):
    r = rdlines(); log += r
    scan(r)
    prompt = buf.decode(errors='replace')
    print('=== RESP%d' % i, [x[:1500] for x in r], '|| prompt:', prompt[:40])
    if any('<EOF>' in x for x in r): break
    if 'Send to Alice' in prompt and last_from_bob:
        s.sendall((last_from_bob + '\n').encode()); last_from_bob = None; print('>> relaying to Alice')
    elif 'Send to Bob' in prompt and last_from_alice:
        s.sendall((last_from_alice + '\n').encode()); last_from_alice = None; print('>> relaying to Bob')
open('eg_relay_%s.txt' % supported[0], 'w').write('\n'.join(log))
