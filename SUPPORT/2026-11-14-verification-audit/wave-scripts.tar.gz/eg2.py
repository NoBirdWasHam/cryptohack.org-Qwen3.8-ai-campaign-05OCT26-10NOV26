import socket, json, sys
CHOICE = json.loads(sys.argv[1]) if len(sys.argv)>1 else '["DH64"]'
s = socket.create_connection(('socket.cryptohack.org', 13379), timeout=20)
s.settimeout(25)
buf = b''
def rdlines():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:200]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
log = []
first = rdlines(); log += first
print('\n'.join(x[:300] for x in first))
s.sendall((CHOICE + '\n').encode() if CHOICE.startswith('{"') else (json.dumps({"supported": json.loads(CHOICE)})+'\n').encode())
for i in range(6):
    r = rdlines(); log += r
    print('---', [x[:800] for x in r])
    if any('<EOF>' in x for x in r): break
open('eg_flow.txt','w').write('\n'.join(log))
