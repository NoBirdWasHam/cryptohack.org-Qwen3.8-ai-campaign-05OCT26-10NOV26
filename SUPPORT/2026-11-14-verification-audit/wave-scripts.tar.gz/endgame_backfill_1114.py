import json,os,shutil
ROOT="~/Practice_runs/cryptohack_org"
S="~/AppData/Local/hermes/cache/scratch/"
w6e=json.load(open(S+"ch_results_w6e.json",encoding="utf-8"))
w7b=json.load(open(S+"ch_results_w7b.json",encoding="utf-8"))
w7c=json.load(open(S+"ch_results_w7c.json",encoding="utf-8"))
fisch=w7b["fischlins_transformation-cryp"]; unb=w7c["unbalanced-icc_athens2022"]
auth=w6e["authenticator-firebird_intern"]
os.chdir(ROOT)

def cpfiles(src_dir,names,dst):
    os.makedirs(dst,exist_ok=True); out=[]
    for n in names:
        p=os.path.join(src_dir,n)
        if os.path.isfile(p): shutil.copy2(p,os.path.join(dst,n)); out.append(n)
    return out

# --- 1. fischlin folder
F="challenge-260-cryptohack-fischlins_transformation-cryp"
os.makedirs(F,exist_ok=True)
open(F+"/flag_fischlins_transformation-cryp.txt","w").write(fisch["flag"]+"\n")
cop=cpfiles(S+"w6e",["fis_diag.py","fis_dist.py","fis_dp_check.py","fis_play.py","fis_relay.py","fis_diag.log"],F+"/artifacts_2026-11-14")
cop+=cpfiles(S+"w6e/fisd",["fischlin_chal.py","fischlin_lib.py","params.py"],F+"/artifacts_2026-11-14")
open(F+"/site.md","w",encoding="utf-8").write("""# fischlins_transformation (CSC Belgium archive twin of sigma-fischlin)
Archive service: archive.cryptohack.org:3583 (64-round Fischlin-OR game).
Points: 0 (archive). Solved 2026-11-14 (post-clear), submit receipt solved 314->315.
Own derivation (worker w7b) supersedes the 2026-10-25 twin-fold credit (errata E8).
""")
open(F+"/AAR.md","w",encoding="utf-8").write(f"""# AAR - fischlins_transformation (CSC Belgium, archive twin of sigma-fischlin)

STATUS: SOLVED 2026-11-14 - own live-service derivation; submit receipt: solved 314 -> 315.

## Problem
Fischlin OR-proof game over service archive.cryptohack.org:3583, 64 rounds. Each round
leaks w0 (response to input 0); prover runs a Fischlin-OR transform with hidden bit b;
solver must determine b (16 attempts/round; the guess applies to the last attempt).

## Attack - b=0 replay
Under the b=0 hypothesis, side 0 is real: e_sim = e1, r_b = (z0 - e0*w0) mod q, and
a0,a1,z1 are constant across the prover e-loop, so for every e-prime <= e_cur recompute
e0-prime = e-prime^e1, z0-prime = r_b + e0-prime*w0 mod q, and check
RO(a0,a1,e-prime,e0-prime,e1,z0-prime,z1) < 2^506. Replaying the server search path:
exact reproduction (no hit below e_cur, hit at e_cur) = consistent with b=0 (posterior
error (63/64)^(e_cur+1)); ANY deviation = CERTAIN b=1 signal.
64/64 rounds decided without contradiction; flag released by service.

## Flag
{fisch["flag"]}

Identical to the sigma-fischlin flag (same challenge, archive twin). This row was
independently re-derived against the live archive service, not copied: the prior credit
had NO own derivation (errata E8); this one does.

## Artifacts
artifacts_2026-11-14/ - solver fis_play.py / fis_relay.py; diagnostics fis_diag.log,
fis_dist.py, fis_dp_check.py; server semantics fischlin_chal.py, fischlin_lib.py, params.py.
Full derivation record: scratch ch_results_w7b.json; transcript deleg_c452499c/task-0.

## Limitations
Per-round soft evidence when the replay reproduces exactly (posterior above); a full-game
contradiction-free run plus service flag release is the end-to-end verification.
Flag format: FLAG-REDACTED-SEE-FLAGS-MIRROR} containing a URL - submit verbatim.
""")
print("F260:",cop)

# --- 2. authenticator folder
F="challenge-13396-cryptohack-authenticator-firebird_intern"
cop=cpfiles(S+"w6e",["rb2.c","auth_live2.py","auth_flag.txt","auth_local_fixed.py","auth_local_serve.py"],F+"/artifacts_2026-11-14")
open(F+"/AAR.md","a",encoding="utf-8").write(f"""
---

## RE-SOLVED post-clear 2026-11-14 - rainbow-table route (independent of 2026-10-28 GPU brute)

Badge lost in owner account clear; re-earned with a DIFFERENT algorithm. Service-given
flag; submit receipt: solved 313 -> 314.

Method: rainbow tables over 62P6 = 44,261,653,680 six-distinct-char passwords (the 10 s
alarm forces offline precompute). Chains L=K=2048 with position-dependent salted
reductions R_i(h) = unrank(le64(T(pw)) ^ salt_i); T fixed =
blake3(pw || HANDSHAKE_FROM_SERVER || cc). Full-covering table N=M/L = 21,612,135 chains
built in ~12 min on 16 cores (rb2.c); rank-keyed endpoints + open-addressed integer
index. Online: cc = 16 zero bytes, walk K=2048 rounds x L steps, verify T(cand)==t0,
answer HANDSHAKE_FROM_CLIENT. Per-connection success ~40% (coverage 63% x chain survival
65%); recovered on attempt 3, 0.80 s connection-to-flag.

Flag: {auth["flag"]}

Artifacts: artifacts_2026-11-14/ (rb2.c table builder, auth_live2.py client).
rb3.bin (330 MB table) NOT archived - regenerates from rb2.c in ~12 min/16 cores.
""")
print("F247:",cop)

# --- 3. unbalanced folder
F="challenge-13401-cryptohack-unbalanced-icc_athens2022"
open(F+"/flag_unbalanced-icc_athens2022.txt","w").write(unb["flag"]+"\n")
cop=cpfiles(S+"unbal",["solver.py","realsolve.py","finalize.py","resultant_extract.py","region.py","variants.py","check.py","extract.py","realsolve.log","output.txt"],F+"/artifacts_2026-11-14")
aar=open(F+"/AAR.md",encoding="utf-8").read()
hdr=f"""# AAR - unbalanced (ICC Athens 2022)

STATUS: **SOLVED 2026-11-14** - Durfee-Nguyen trivariate Coppersmith; submit receipt solved 315 -> 316.

## Resolution (2026-11-14)
Sun-Yang-Laih AC99 Scheme I instantiation (p 256-bit, q 768-bit, d 300-bit, e~N,
ed=1+k*phi). Solve 2 + x*(A - y - z) = 0 (mod e), A=N+1, at root (2k, p, q) with yz=N
substituted so f(root)=2+2k*phi=2ed=0 mod e. DN ASIACRYPT-2000 shifts
g_(k,i,b)=e^(m-k) x^i y^a z^b f^k and h_(k,j)=e^(m-k) y^(a+j) f^k with m=8, t=5, a=1,
bounds (2^301, 2^256, 2^768): rank-126 lattice, determinant margin ~ +46 bits/dim;
fpylll LLL (delta=0.99); short rows vanish at (2k,p,q); p extracted via fraction-free
Bareiss resultant in x after z=N/y substitution, integer roots, p|N verified.
p={unb["p"]}
d={unb["d"]}
Flag: {unb["flag"]}
Artifacts: artifacts_2026-11-14/ (solver.py, realsolve.py, finalize.py,
resultant_extract.py + logs).
The historical evidenced-negative sections below remain valid FOR THE BIVARIATE ROUTE
ONLY - superseded by the trivariate DN construction (run2 SOLVE-READY note, 2026-11-01).

"""
open(F+"/AAR.md","w",encoding="utf-8").write(hdr+aar)
print("F304:",cop)

# --- 4. ledger rows
pj=json.load(open("progress.json",encoding="utf-8"))
q=pj["queue"] if isinstance(pj,dict) and "queue" in pj else pj
n=0
for r in q:
    sl=str(r.get("slug") or "")
    if r.get("nn")==260:
        r["flag"]=fisch["flag"]; r["solved_date"]="2026-11-14"
        r["notes"]=(r.get("notes") or "")+" || 2026-11-14 RESOLVED with OWN live-service replay derivation (w7b; folder created + AAR + artifacts_2026-11-14); twin-fold E8 SUPERSEDED; submit receipt solved 314->315"
        n+=1
    elif r.get("nn")==247:
        r["folder"]="challenge-13396-cryptohack-authenticator-firebird_intern"
        r["notes"]=(r.get("notes") or "")+" || 2026-11-14 post-clear re-solve by INDEPENDENT method (rainbow tables, rb2.c ~12min/16cores, flag on attempt 3, 0.80s); folder field corrected (was blind-ecsc legacy misname); submit receipt solved 313->314"
        n+=1
    elif r.get("nn")==304:
        r["flag"]=unb["flag"]; r["solved_date"]="2026-11-14"
        r["notes"]=(r.get("notes") or "")+" || 2026-11-14 SOLVED: DN trivariate m=8 t=5 rank-126, margin +46b/dim, Bareiss-resultant extraction, p|N verified; negative sections stand for bivariate only; submit receipt solved 315->316; AAR header + artifacts_2026-11-14"
        n+=1
    elif sl in ("zkpintro","letsproveit"):
        r["notes"]=(r.get("notes") or "")+" || 2026-11-14 badge re-earned post owner-clear; live API + category board verify 316/316"
        n+=1
json.dump(pj,open("progress.json","w",encoding="utf-8"),indent=1,ensure_ascii=False)
print("rows updated:",n)

# --- 5. verify folder-vs-ledger zero-missing
miss=[]
for r in q:
    s=str(r.get("state_v2") or r.get("status") or "").lower()
    fd=r.get("folder")
    if "solved" in s and fd and not os.path.isdir(fd): miss.append((r.get("nn"),fd))
print("credited rows with missing folder:",len(miss),miss[:5])
EOF_MARKER_NOT_NEEDED = True
