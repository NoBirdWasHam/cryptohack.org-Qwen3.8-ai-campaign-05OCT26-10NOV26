import requests
from test_ghash import gmul, i2b, b2i, ghash, pad16

BASE = "https://aes.cryptohack.org/forbidden_fruit"
s = requests.Session()
def enc(pt):
    return s.get(f"{BASE}/encrypt/{pt.hex()}/", timeout=25).json()

A = b"CryptoHack"
r1 = enc(b"A" * 16); r2 = enc(b"B" * 16)
C1 = bytes.fromhex(r1["ciphertext"]); T1 = bytes.fromhex(r1["tag"])
C2 = bytes.fromhex(r2["ciphertext"]); T2 = bytes.fromhex(r2["tag"])
print("nonce1", r1["nonce"], "nonce2", r2["nonce"], "ad", r1["associated_data"])
Cdiff = bytes(a ^ b for a, b in zip(C1, C2))
Tdiff = bytes(a ^ b for a, b in zip(T1, T2))

def ginv(X):
    r = 1; x = gmul(X, X)
    for i in range(1, 128):
        r = gmul(r, x); x = gmul(x, x)
    return r

H2 = gmul(b2i(Tdiff), ginv(b2i(Cdiff)))
Hint = H2
for _ in range(127):
    Hint = gmul(Hint, Hint)
# sanity: Hint^2 == H2
print("sqrt ok:", gmul(Hint, Hint) == H2)

def model_tag(Hint, S, C):
    Y = [pad16(A)] + [pad16(C[i:i + 16]) for i in range(0, len(C), 16)]
    Y.append((8 * len(A)).to_bytes(8, "big") + (8 * len(C)).to_bytes(8, "big"))
    return ghash(Hint, Y) ^ S

S = b2i(T1) ^ model_tag(Hint, 0, C1)
print("T2 match:", i2b(model_tag(Hint, S, C2)) == T2)
for pt in [b"D" * 16, b"E" * 32, b"C" * 20, b"F" * 4]:
    r = enc(pt)
    C = bytes.fromhex(r["ciphertext"]); T = bytes.fromhex(r["tag"])
    print("len", len(pt), "match:", i2b(model_tag(Hint, S, C)) == T, "nonce same:", r["nonce"] == r1["nonce"])
