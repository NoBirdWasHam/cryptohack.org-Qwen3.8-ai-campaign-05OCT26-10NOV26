# good_pad_ugly (socket.cryptohack.org:13422): like pad_thai but the oracle is
# {"result": good | (rng.random() > 0.4)} -> invalid padding says True 60% of the
# time (False is definitive), max 12000 oracle queries per connection.
# Strategy: hex-charset candidates per byte; re-query every still-True candidate
# each pass (bad ones die on their first False, E=2.5 queries); accept the last
# survivor after CONFIRM consecutive Trues.
import socket, json, sys, random

HEX = b"0123456789abcdef"
BUDGET = 11000
CONFIRM = 22

class Srv:
    def __init__(self, port=13422):
        self.s = socket.create_connection(("socket.cryptohack.org", port), timeout=30)
        self.s.settimeout(30)
        self.buf = b""
        self.q = 0
    def greet(self):
        while not self.buf.endswith(b"\n"):
            d = self.s.recv(65536)
            if not d:
                raise EOFError
            self.buf += d
    def sendj(self, obj):
        self.s.sendall(json.dumps(obj).encode() + b"\n")
    def recvj(self):
        while True:
            i = self.buf.find(b"{")
            if i >= 0:
                try:
                    obj, j = json.JSONDecoder().raw_decode(self.buf[i:].decode())
                    self.buf = self.buf[i+j:]
                    return obj
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
            d = self.s.recv(65536)
            if not d:
                raise EOFError
            self.buf += d

def solve():
    sv = Srv()
    sv.greet()
    sv.sendj({"option": "encrypt"})
    ct = bytes.fromhex(sv.recvj()["ct"])
    iv, c1, c2 = ct[:16], ct[16:32], ct[32:48]

    def oracle(F, B):
        sv.q += 1
        if sv.q > BUDGET:
            raise RuntimeError("budget")
        sv.sendj({"option": "unpad", "ct": (F + B).hex()})
        r = sv.recvj()
        if "result" not in r:
            raise RuntimeError(str(r))
        return r["result"]

    def recover(B, prev):
        D = [None] * 16
        for p in range(15, -1, -1):
            v = 16 - p
            base = bytearray(16)
            for q in range(p + 1, 16):
                base[q] = D[q] ^ v
            alive = {}
            for ch in HEX:
                g = ch ^ prev[p]
                F = bytearray(base); F[p] = g ^ v
                alive[g] = 1 if oracle(bytes(F), B) else 0
            alive = {g: c for g, c in alive.items() if c}
            while True:
                if not alive:
                    raise RuntimeError(f"all dead p={p}")
                if len(alive) == 1 and next(iter(alive.values())) >= CONFIRM:
                    break
                for g in list(alive):
                    F = bytearray(base); F[p] = g ^ v
                    if oracle(bytes(F), B):
                        alive[g] += 1
                    else:
                        del alive[g]
            D[p] = next(iter(alive))
        return bytes(D[i] ^ prev[i] for i in range(16))

    p2 = recover(c2, c1)
    p1 = recover(c1, iv)
    msg = p1 + p2
    print("queries", sv.q, file=sys.stderr)
    assert all(c in HEX for c in msg), msg
    sv.sendj({"option": "check", "message": msg.decode()})
    r = sv.recvj()
    sv.s.close()
    if "flag" in r:
        return r["flag"]
    raise RuntimeError(str(r))

for tries in range(3):
    try:
        print(solve())
        break
    except Exception as e:
        print("attempt failed:", e, file=sys.stderr)
