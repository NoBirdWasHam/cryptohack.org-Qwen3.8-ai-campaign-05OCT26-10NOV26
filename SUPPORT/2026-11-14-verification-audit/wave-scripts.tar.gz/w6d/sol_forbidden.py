# forbidden_fruit: GCM with FIXED server nonce. Nonce-reuse GHASH key recovery
# (cryptopals #63 / toadstyle 63.txt). Two known 1-block plaintexts:
#   Tag1 xor Tag2 = (C1 xor C2) * H^2   (AAD and len blocks identical, S cancels)
# => H^2 = Tdiff/Cdiff, H = sqrt (unique in char 2), S = Tag xor GHASH(A,C).
# Then forge a 1-block ct decrypting to "give me the flag" under the same nonce.
import requests, sys

BASE = "https://aes.cryptohack.org/forbidden_fruit"
s = requests.Session()
R = 0xE1 << 120
MASK = (1 << 128) - 1

def gmul(X, Y):
    Z = 0
    for i in range(128):
        if (Y >> (127 - i)) & 1:
            Z ^= X
        if X & 1:
            X = (X >> 1) ^ R
        else:
            X >>= 1
    return Z

def gpow2(X, n):
    for _ in range(n):
        X = gmul(X, X)
    return X

def ginv(X):
    # X^(2^128-2) = prod_{i=1..127} X^(2^i); no identity constant needed
    x = gmul(X, X)
    r = x
    for _ in range(2, 128):
        x = gmul(x, x)
        r = gmul(r, x)
    return r

def i2b(x): return x.to_bytes(16, "big")
def b2i(b): return int.from_bytes(b, "big")

def ghash(Hint, Yblocks):
    acc = 0
    for y in Yblocks:
        acc = gmul(acc ^ b2i(y), Hint)
    return acc

def pad16(b):
    return b + b"\x00" * ((16 - len(b) % 16) % 16)

def encrypt(pt: bytes):
    r = s.get(f"{BASE}/encrypt/{pt.hex()}/", timeout=25)
    return r.json()

def P16(tag): return tag.encode().ljust(16, b"?")

A = b"CryptoHack"
r1 = encrypt(b"A" * 16)
r2 = encrypt(b"B" * 16)
nonce = bytes.fromhex(r1["nonce"]); ad = bytes.fromhex(r1["associated_data"])
assert ad == A and r2["nonce"] == nonce.hex()
C1 = bytes.fromhex(r1["ciphertext"]); T1 = bytes.fromhex(r1["tag"])
C2 = bytes.fromhex(r2["ciphertext"]); T2 = bytes.fromhex(r2["tag"])
Cdiff = bytes(a ^ b for a, b in zip(C1, C2))
Tdiff = bytes(a ^ b for a, b in zip(T1, T2))
H2 = gmul(b2i(Tdiff), ginv(b2i(Cdiff)))
Hint = gpow2(H2, 127)  # sqrt: H = H2^(2^127)

lenblk = (8 * len(A)).to_bytes(8, "big") + (8 * 16).to_bytes(8, "big")
Y = [pad16(A), C1, lenblk]
S = b2i(T1) ^ ghash(Hint, Y)

# validate on a third plaintext of different length
P3 = b"C" * 20
r3 = encrypt(P3)
C3 = bytes.fromhex(r3["ciphertext"]); T3 = bytes.fromhex(r3["tag"])
lb3 = (8 * len(A)).to_bytes(8, "big") + (8 * len(C3)).to_bytes(8, "big")
y3 = [pad16(A)] + [pad16(C3[i:i+16]) for i in range(0, len(C3), 16)] + [lb3]
T3p = i2b(ghash(Hint, y3) ^ S)
if T3p != T3:
    print("GHASH model mismatch", file=sys.stderr); sys.exit(1)

# keystream block 1 from a known 1-block plaintext
r4 = encrypt(b"D" * 16)
ks1 = bytes(a ^ b for a, b in zip(bytes.fromhex(r4["ciphertext"]), b"D" * 16))
M = b"give me the flag"
assert len(M) == 16
Cs = bytes(a ^ b for a, b in zip(M, ks1))
lb = (8 * len(A)).to_bytes(8, "big") + (8 * 16).to_bytes(8, "big")
Ts = i2b(ghash(Hint, [pad16(A), Cs, lb]) ^ S)
r = s.get(f"{BASE}/decrypt/{nonce.hex()}/{Cs.hex()}/{Ts.hex()}/{A.hex()}/", timeout=25)
out = r.json()
if "plaintext" in out:
    print(bytes.fromhex(out["plaintext"]).decode())
else:
    print(out, file=sys.stderr); sys.exit(1)
