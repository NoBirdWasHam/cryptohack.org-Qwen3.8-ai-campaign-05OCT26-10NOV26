from Crypto.Cipher import AES

R = 0xE1 << 120
def gmul(X, Y):
    Z = 0
    for i in range(128):
        if (Y >> (127 - i)) & 1:
            Z ^= X
        X = (X >> 1) ^ R if X & 1 else X >> 1
    return Z
def i2b(x): return x.to_bytes(16, "big")
def b2i(b): return int.from_bytes(b, "big")
def ghash(Hint, Y):
    acc = 0
    for y in Y:
        acc = gmul(acc ^ b2i(y), Hint)
    return acc
def pad16(b): return b + b"\x00" * ((16 - len(b) % 16) % 16)

key = bytes(range(16))
A = b"CryptoHack"
for noncelen in (12, 16):
    nonce = bytes(range(noncelen))
    pts = [b"", b"A" * 16, b"C" * 20, b"give me the flag"]
    tags, cts = [], []
    for pt in pts:
        c = AES.new(key, AES.MODE_GCM, nonce=nonce)
        c.update(A)
        ct, tag = c.encrypt_and_digest(pt)
        cts.append(ct); tags.append(tag)
    Hint = b2i(AES.new(key, AES.MODE_ECB).encrypt(b"\x00" * 16))
    ok = True
    S = None
    for pt, ct, tag in zip(pts, cts, tags):
        Y = [pad16(A)]
        if ct:
            Y += [pad16(ct[i:i + 16]) for i in range(0, len(ct), 16)]
        Y.append((8 * len(A)).to_bytes(8, "big") + (8 * len(ct)).to_bytes(8, "big"))
        s = b2i(tag) ^ ghash(Hint, Y)
        if S is None:
            S = s
        elif s != S:
            ok = False
    print("noncelen", noncelen, "consistent GHASH+one S:", ok)
