# paper_plane: IGE padding oracle. send_msg(ct, m0, c0) decrypts IGE and reports
# whether PKCS7 unpad succeeds. Truncate the flag ciphertext to a SINGLE block
# C_k and feed it with chosen m0 (becomes the D-XOR-IN) and c0 (D-XOR-OUT):
#   P = D(C_k ^ m0) ^ c0
# Keep m0 fixed => intermediate Y = D(C_k ^ m0) fixed; c0 fully ours => classic
# byte-at-a-time CBC-style padding oracle on the c0 XOR-out.
#   block 1: m0 = m0_orig          -> P1 = Y ^ c0_orig
#   block k: m0 = recovered P_{k-1} -> Pk = Y ^ C_{k-1}
import requests, json, sys, os

BASE = "https://aes.cryptohack.org/paper_plane"
CKPT = os.path.join(os.path.dirname(__file__), "paperplane_ckpt.json")
s = requests.Session()

def get(url):
    for _ in range(6):
        try:
            r = s.get(url, timeout=25)
            try:
                return r.json()
            except Exception:
                continue
        except Exception:
            import time; time.sleep(1)
    raise RuntimeError("net")

r = get(f"{BASE}/encrypt_flag/")
CT = bytes.fromhex(r["ciphertext"]); m0o = bytes.fromhex(r["m0"]); c0o = bytes.fromhex(r["c0"])
nblk = len(CT) // 16
print("ct blocks:", nblk, file=sys.stderr)

state = {"D": [[None]*16 for _ in range(nblk)], "done": [False]*nblk}
if os.path.exists(CKPT):
    try:
        loaded = json.load(open(CKPT))
        state["D"] = loaded["D"]; state["done"] = loaded["done"]
    except Exception:
        pass

q = 0
def probe(ck, m0p, c0p):
    global q
    out = get(f"{BASE}/send_msg/{ck.hex()}/{m0p.hex()}/{c0p.hex()}/")
    q += 1
    return out.get("msg") == "Message received"

def recover(k):
    ck = CT[16*k:16*(k+1)]
    m0p = m0o if k == 0 else P[k-1]
    last = (k == nblk - 1)
    D = state["D"][k]
    for p in range(15, -1, -1):
        if D[p] is not None:
            continue
        v = 16 - p
        base = bytearray(16)
        for qq in range(p + 1, 16):
            base[qq] = D[qq] ^ v
        if last or p == 15:
            cand = range(256)
        else:
            prev = CT[16*(k-1):16*k] if k > 0 else c0o
            cand = [c ^ prev[p] for c in range(0x20, 0x7f)]  # D[p] giving printable P[p]
        survivors = []
        for g in cand:
            F = bytearray(base); F[p] = g ^ v
            if probe(ck, m0p, bytes(F)):
                survivors.append(g)
                if p < 15:
                    break  # passing candidate is unique for p<15 (pad_len forced by P[15])
        if not survivors:
            raise RuntimeError(f"no survivor blk{k} p{p}")
        if len(survivors) > 1:
            import random
            for _ in range(4):
                filler = [random.randrange(256) for _ in range(p)]
                surv2 = []
                for g in survivors:
                    F = bytearray(base); F[p] = g ^ v
                    for i in range(p):
                        F[i] = filler[i]
                    if probe(ck, m0p, bytes(F)):
                        surv2.append(g)
                survivors = surv2
                if len(survivors) <= 1:
                    break
        if len(survivors) != 1:
            raise RuntimeError(f"ambiguous blk{k} p{p}: {survivors}")
        D[p] = survivors[0]
        json.dump(state, open(CKPT, "w"))
        print(f"blk{k} p{p} -> {bytes([D[p]^v])!r} (q={q})", file=sys.stderr)

P = [None] * nblk
for k in range(nblk):
    recover(k)
    prev = c0o if k == 0 else CT[16*(k-1):16*k]
    P[k] = bytes(state["D"][k][i] ^ prev[i] for i in range(16))
    print("P%d =" % (k+1), P[k], file=sys.stderr)

msg = b"".join(P)
flag = msg[: len(msg) - msg[-1]]
print("queries:", q, file=sys.stderr)
print(flag.decode(errors="replace"))
