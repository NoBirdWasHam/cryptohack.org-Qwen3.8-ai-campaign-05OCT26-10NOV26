# logon-zero (socket.cryptohack.org:13399): ZeroLogon-style AES-CFB8.
# decrypt(token): IV = token[:16], state=IV; per byte pt[i]=E(state)[0]^ct[i],
# state = state[1:]+ct[i]. A token of ONE repeated byte keeps the state constant,
# so every pt byte equals v = E_K(pad*16)[0]^pad (key-dependent, 1/256 chance v==0).
# If v==0 the decrypted token is all zero bytes -> last 4 bytes give password
# length 0 -> password b"". Then authenticate with empty password -> flag.
# Loop pads 0..255 per key; reset_connection for a fresh random key; repeat.
import socket, json, sys, time

def recvline_with_buf(s, buf):
    while b"\n" not in buf:
        d = s.recv(65536)
        if not d:
            raise EOFError
        buf += d
    i = buf.index(b"\n")
    return buf[:i], buf[i+1:]

def attempt():
    s = socket.create_connection(("socket.cryptohack.org", 13399), timeout=30)
    s.settimeout(30)
    buf = b""
    greeting, buf = recvline_with_buf(s, buf)
    print("greeting:", greeting[:80], file=sys.stderr)
    def sendj(obj):
        s.sendall(json.dumps(obj).encode() + b"\n")
    def recvj():
        nonlocal buf
        line, buf = recvline_with_buf(s, buf)
        return json.loads(line)
    rounds = 0
    while True:
        rounds += 1
        for pad in range(256):
            token = bytes([pad]) * 96
            sendj({"option": "reset_password", "token": token.hex()})
            r = recvj()
            if "reset" not in r.get("msg", ""):
                print("unexpected reset resp:", r, file=sys.stderr)
                raise RuntimeError
            sendj({"option": "authenticate", "password": ""})
            r = recvj()
            msg = r.get("msg", "")
            if "Welcome" in msg or "flag" in msg:
                s.close()
                return msg
        # no pad worked for this key: new key
        sendj({"option": "reset_connection"})
        r = recvj()
        print("round", rounds, "reset:", r, file=sys.stderr)
        if rounds > 20:
            raise RuntimeError("too many rounds")

for tries in range(10):
    try:
        msg = attempt()
        print(msg)
        break
    except Exception as e:
        print("attempt failed:", e, file=sys.stderr)
        time.sleep(2)
else:
    sys.exit(1)
