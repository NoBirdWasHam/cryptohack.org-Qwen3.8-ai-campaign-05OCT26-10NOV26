# pad_thai (socket.cryptohack.org:13421): CBC padding oracle, honest result.
# message = urandom(16).hex()  (32 ASCII hex chars -> 2 CBC blocks, no pad block).
# Recover D(C2) then D(C1) byte-at-a-time (16 hex-charset candidates each, shifted
# by the true prev block), unchain, submit the message.
import socket, json, sys

HEX = b"0123456789abcdef"

class Srv:
    def __init__(self):
        self.s = socket.create_connection(("socket.cryptohack.org", 13421), timeout=30)
        self.s.settimeout(30)
        self.buf = b""
    def greet(self):
        # greeting is a plain text line ending with \n; the JSON reply to our
        # first command arrives only after we send
        while not self.buf.endswith(b"\n"):
            d = self.s.recv(65536)
            if not d:
                raise EOFError
            self.buf += d
    def sendj(self, obj):
        self.s.sendall(json.dumps(obj).encode() + b"\n")
    def recvj(self):
        while True:
            i = self.buf.find(b"{")
            if i >= 0:
                try:
                    obj, j = json.JSONDecoder().raw_decode(self.buf[i:].decode())
                    self.buf = self.buf[i+j:]
                    return obj
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
            d = self.s.recv(65536)
            if not d:
                raise EOFError
            self.buf += d

def solve():
    sv = Srv()
    sv.greet()
    sv.sendj({"option": "encrypt"})
    ct = bytes.fromhex(sv.recvj()["ct"])
    iv, c1, c2 = ct[:16], ct[16:32], ct[32:48]
    assert len(ct) == 48, len(ct)

    def oracle(F, B):
        sv.sendj({"option": "unpad", "ct": (F + B).hex()})
        return sv.recvj()["result"]

    def recover(B, prev):
        D = [None] * 16
        p = 15
        while p >= 0:
            v = 16 - p
            base = bytearray(16)
            for q in range(p + 1, 16):
                base[q] = D[q] ^ v
            survivors = []
            for ch in HEX:
                g = ch ^ prev[p]           # D[p] candidate
                F = bytearray(base); F[p] = g ^ v
                if oracle(bytes(F), B):
                    survivors.append(g)
            if not survivors:
                # a previously recovered byte was wrong -> restart the whole solve
                raise RuntimeError(f"no survivor at p={p}")
            # disambiguate with a second random filler (spurious pads depend on
            # the q<p filler bytes, the true byte passes with any filler)
            import random
            for _ in range(3):
                filler = bytearray(random.randrange(256) for _ in range(p))
                surv2 = []
                for g in survivors:
                    F = bytearray(base); F[p] = g ^ v
                    F[:p] = filler
                    if oracle(bytes(F), B):
                        surv2.append(g)
                survivors = surv2
                if len(survivors) <= 1:
                    break
            if len(survivors) != 1:
                raise RuntimeError(f"ambiguous at p={p}: {survivors}")
            D[p] = survivors[0]
            p -= 1
        return bytes(D[i] ^ prev[i] for i in range(16))

    msg = b""
    # block order in CBC: P1 = D(c1)^iv, P2 = D(c2)^c1
    p2 = recover(c2, c1)
    p1 = recover(c1, iv)
    msg = p1 + p2
    assert all(c in HEX for c in msg), msg
    sv.sendj({"option": "check", "message": msg.decode()})
    r = sv.recvj()
    sv.s.close()
    if "flag" in r:
        return r["flag"]
    raise RuntimeError(str(r))

for tries in range(3):
    try:
        print(solve())
        break
    except Exception as e:
        print("attempt failed:", e, file=sys.stderr)
