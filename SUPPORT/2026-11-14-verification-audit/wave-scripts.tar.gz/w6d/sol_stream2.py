# stream_consciousness v2: same keystream every call (CTR counter starts at 0,
# fixed KEY). Many-time pad: per-keystream-byte printable intersection + English
# letter-frequency scoring; decrypt distinct lines; the one matching FLAG-REDACTED-SEE-FLAGS-MIRROR
# is the FLAG.
import requests, re, sys, math

BASE = "https://aes.cryptohack.org/stream_consciousness/encrypt/"
s = requests.Session()

def enc():
    for _ in range(5):
        try:
            return bytes.fromhex(s.get(BASE, timeout=25).json()["ciphertext"])
        except Exception:
            pass
    raise RuntimeError("net")

cts = []
for i in range(160):
    cts.append(enc())
    if i % 40 == 39:
        print("samples", len(cts), file=sys.stderr)

maxlen = max(len(c) for c in cts)
PRINT = {p for p in range(0x20, 0x7f)}
FREQ = {}
for ch, f in [(" ", 0.18), ("e", 0.11), ("t", 0.08), ("a", 0.068), ("o", 0.07),
              ("i", 0.065), ("n", 0.067), ("s", 0.06), ("r", 0.06), ("h", 0.055),
              ("l", 0.035), ("d", 0.035), ("c", 0.028), ("u", 0.025), ("m", 0.02),
              ("f", 0.018), ("g", 0.02), ("p", 0.018), ("b", 0.014), ("y", 0.017),
              ("w", 0.012), ("v", 0.009), ("k", 0.007), ("x", 0.0015), ("j", 0.001),
              ("q", 0.0009), ("z", 0.0007)]:
    FREQ[ord(ch)] = f
    FREQ[ord(ch.upper())] = f * 0.25
for ch in ".,;:!?'\"()-\n0123456789{}_/&%$#@*[]":
    FREQ.setdefault(ord(ch), 0.003)

def score(k, vals):
    return sum(math.log(FREQ.get(b ^ k, 1e-4)) for b in vals)

ks = []
for pos in range(maxlen):
    vals = [c[pos] for c in cts if len(c) > pos]
    allowed = set(range(256))
    for b in vals:
        allowed &= {b ^ p for p in PRINT}
    ks.append(max(allowed, key=lambda k: score(k, vals)))

lines = {}
for c in cts:
    lines[c] = bytes(b ^ ks[i] for i, b in enumerate(c))
flag_re = re.compile(rb"crypto\{[^{}]*\}")
for c, d in sorted(lines.items(), key=lambda kv: len(kv[0])):
    print(len(c), d, file=sys.stderr)
    if flag_re.fullmatch(d):
        print(d.decode())
        sys.exit(0)
print("no clean flag line", file=sys.stderr)
sys.exit(1)
