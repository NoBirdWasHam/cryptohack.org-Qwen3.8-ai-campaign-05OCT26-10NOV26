# ctrime: CRIME-style compression oracle. encrypt(pt) = CTR(zlib.compress(pt + FLAG)).
# Guess flag prefix G; query (G+c)*5 for each candidate c: the correct c extends the
# repeated pattern / match into the real FLAG prefix => shortest compressed length.
# Checkpointed; resume-safe.
import requests, json, sys, os, time

BASE = "https://aes.cryptohack.org/ctrime/encrypt/"
CKPT = os.path.join(os.path.dirname(__file__), "ctrime_ckpt.json")
s = requests.Session()
CHARS = b"abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_-.!?" + b"{}"

def enc_len(pt: bytes):
    for _ in range(8):
        try:
            r = s.get(BASE + pt.hex() + "/", timeout=25)
            return len(bytes.fromhex(r.json()["ciphertext"]))
        except Exception:
            time.sleep(1.0)
    raise RuntimeError("net")

flag = b"crypto{"
done = False
if os.path.exists(CKPT):
    try:
        d = json.load(open(CKPT))
        flag = bytes.fromhex(d["flag"]); done = d.get("done", False)
    except Exception:
        pass

if not done:
    while True:
        def best(mult):
            scores = {}
            for c in CHARS:
                scores[c] = enc_len((flag + bytes([c])) * mult)
                time.sleep(0.03)
            m = min(scores.values())
            return [c for c, v in scores.items() if v == m]
        surv = best(5)
        if len(surv) > 1:
            surv2 = best(3)
            inter = [c for c in surv if c in surv2]
            surv = inter if inter else surv2
        c = surv[0]
        flag += bytes([c])
        print(flag, len(surv), file=sys.stderr)
        json.dump({"flag": flag.hex(), "done": c == ord("}")}, open(CKPT, "w"))
        if c == ord("}"):
            done = True
            break
        if len(flag) > 80:
            raise RuntimeError("too long")

print(flag.decode())
