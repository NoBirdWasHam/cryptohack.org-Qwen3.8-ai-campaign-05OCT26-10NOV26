# stream_consciousness: AES-CTR with Counter.new(128) (counter always starts 0,
# fixed KEY) => identical keystream for every encrypt(). Many-time-pad: intersect
# printable-ASCII constraints over many ciphertexts to recover the keystream,
# then decrypt the line that is the FLAG.
import requests, re, sys, json

BASE = "https://aes.cryptohack.org/stream_consciousness/encrypt/"
s = requests.Session()

def enc():
    for _ in range(5):
        try:
            r = s.get(BASE, timeout=25)
            return bytes.fromhex(r.json()["ciphertext"])
        except Exception:
            pass
    raise RuntimeError("net")

PRINT = [k in range(0x20, 0x7f) for k in range(256)]
cts = []
maxlen = 0
cands = None  # list of sets

def rebuild():
    global cands
    cands = [set(range(256)) for _ in range(maxlen)]
    for c in cts:
        for i in range(len(c)):
            b = c[i]
            cands[i] &= {b ^ p for p in range(256) if PRINT[p]}
            if not cands[i]:
                cands[i] = {b ^ p for p in range(256) if PRINT[p]}  # shouldn't happen

def ambiguous():
    return [i for i in range(maxlen) if len(cands[i]) != 1]

for batch in range(25):
    cts.append(enc())
    maxlen = max(maxlen, len(cts[-1]))
    rebuild()
    amb = ambiguous()
    if not amb and len(cts) >= 40:
        break

print("samples", len(cts), "maxlen", maxlen, "ambiguous", len(ambiguous()), file=sys.stderr)
amb = ambiguous()

# tighten charset with sentence-like set if needed
TIGHT = [chr(k) for k in range(0x20, 0x7f) if chr(k) in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,;:!?-'\"()"]
TIGHTSET = {ord(c) for c in TIGHT}
def rebuild_tight():
    global cands
    for i in range(maxlen):
        if len(cands[i]) > 1:
            nc = set()
            for k in cands[i]:
                if all(((c[i] ^ k) in TIGHTSET) for c in cts if len(c) > i):
                    nc.add(k)
            if nc:
                cands[i] = nc

rebuild_tight()
print("tight ambiguous", len(ambiguous()), file=sys.stderr)

# try to decrypt a flag-looking line via brute over ambiguous positions
amb = ambiguous()
uniq_lines = set()
def decrypt(c, ks):
    return bytes(c[i] ^ ks[i] for i in range(len(c)))

base_ks = [next(iter(cands[i])) for i in range(maxlen)]
flag_re = re.compile(rb"crypto\{[^}]*\}")

if not amb:
    seen = {}
    for c in cts:
        seen.setdefault(len(c), decrypt(c, base_ks))
    for L, line in sorted(seen.items()):
        print(L, line, file=sys.stderr)
    flags = [line for line in seen.values() if flag_re.fullmatch(line)]
    if flags:
        print(flags[0].decode())
        sys.exit(0)
else:
    # candidate flag ciphertexts: decrypt with base ks, find those near regex
    import itertools
    for c in {len(cts[i]): cts[i] for i in range(len(cts))}.values():
        # enumerate combos over ambiguous positions within this ciphertext
        positions = [i for i in amb if i < len(c)]
        if len(positions) > 12:
            continue
        combos = itertools.product(*[sorted(cands[i]) for i in positions])
        cur = bytearray(decrypt(c, base_ks))
        for combo in combos:
            for i, v in zip(positions, combo):
                cur[i] = c[i] ^ v
            b = bytes(cur)
            if flag_re.fullmatch(b):
                print(b.decode())
                sys.exit(0)
print("FAILED", file=sys.stderr)
sys.exit(1)
