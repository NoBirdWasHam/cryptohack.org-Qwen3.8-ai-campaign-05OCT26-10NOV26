import json, hashlib, re, sympy
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
txt = open('eg_relay_DH64.txt').read()
# capture the DH64 exchange lines
p  = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
g  = int(re.search(r'"g": "0x([0-9a-f]+)"', txt).group(1), 16)
A  = int(re.search(r'"A": "0x([0-9a-f]+)"', txt).group(1), 16)
B  = int(re.search(r'"B": "0x([0-9a-f]+)"', txt).group(1), 16)
iv = re.search(r'"iv": "([0-9a-f]+)"', txt).group(1)
ct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt).group(1)
print("p =", p, sympy.isprime(p))
print("g,A,B =", g, A, B)
f = sympy.factorint(p-1)
print("p-1 =", f)
