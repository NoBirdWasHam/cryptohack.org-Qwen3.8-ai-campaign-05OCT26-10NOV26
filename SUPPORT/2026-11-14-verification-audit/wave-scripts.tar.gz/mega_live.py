import socket, json, random, math, os, sys
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import pad, unpad
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from mega_vh import solve_L

HOST = "socket.cryptohack.org"
PORT = 13409

def recv_line(sock, fp):
    data = b""
    while b"\n" not in data:
        chunk = sock.recv(4096)
        if not chunk:
            raise EOFError("connection closed: " + repr(data[:200]))
        data += chunk
    line, rest = data.split(b"\n", 1)
    if rest:
        fp.buffer = rest + getattr(fp, "buffer", b"")
    return line

class Fp:
    buffer = b""
    def line(self, sock):
        while b"\n" not in self.buffer:
            chunk = sock.recv(4096)
            if not chunk: raise EOFError("closed " + repr(self.buffer[:200]))
            self.buffer += chunk
        line, self.buffer = self.buffer.split(b"\n", 1)
        return line

def send_msg(sock, msg):
    sock.sendall((json.dumps(msg) + "\n").encode())

def recv_json(fp, s):
    while True:
        t = fp.line(s).decode(errors="replace").strip()
        if t.startswith("{"):
            try:
                return json.loads(t)
            except Exception:
                continue

def try_connection(attempt):
    s = socket.create_connection((HOST, PORT), timeout=30)
    fp = Fp()
    material = None
    for _ in range(10):
        line = fp.line(s)
        t = line.decode(errors="replace").strip()
        if t.startswith("{"):
            try:
                material = json.loads(t); break
            except Exception: pass
    assert material and "share_key_pub" in material, material
    n, e = material["share_key_pub"]
    blob = bytes.fromhex(material["share_key_enc"])
    mke = material["master_key_enc"]
    print(f"[{attempt}] n bits={n.bit_length()} blob={len(blob)}")
    nblocks = len(blob) // 16
    ustart = 130 * 2 + 258 + 2   # 520
    safe_hi = len(blob) - 16 - 8 # leave final block + slack; conservative
    blocks = [b for b in range(nblocks) if b * 16 >= ustart and (b + 1) * 16 <= min(648, len(blob) - 8)]
    print("candidate u blocks:", blocks)
    X0 = random.getrandbits(890) | (1 << 897)
    x = X0 << 128
    if x >= n: 
        x = (X0 >> 1) << 128; X0 >>= 1
    ct = long_to_bytes(pow(x, e, n))
    # sanity login (consumes 1 of 4 logins)
    send_msg(s, {"action": "wait_login"}); r = recv_json(fp, s); print("wait1:", r)
    send_msg(s, {"action": "send_challenge", "SID_enc": ct.hex(), "share_key_enc": material["share_key_enc"], "master_key_enc": mke})
    r = recv_json(fp, s); print("clean:", str(r)[:80])
    ok_clean = r.get("SID") == long_to_bytes(X0).hex()
    print("clean sanity:", ok_clean)
    for fb in random.sample(blocks, min(3, len(blocks))):
        send_msg(s, {"action": "wait_login"}); r = recv_json(fp, s)
        if "error" in r: print("wait err", r); break
        send_msg(s, {"action": "send_challenge", "SID_enc": ct.hex(),
                     "share_key_enc": bytes(blob[:fb*16] + os.urandom(16) + blob[(fb+1)*16:]).hex(),
                     "master_key_enc": mke})
        r = recv_json(fp, s)
        if "SID" not in r:
            print(f"fault fb={fb} -> {r}"); continue
        sid = bytes.fromhex(r["SID"])
        H = bytes_to_long(sid) << 128
        A = (H - x) % n
        res = solve_L(n, A, 1 << 128, b=1) or solve_L(n, A, 1 << 128, b=2)
        if not res:
            print(f"fault fb={fb}: sid ok len={len(sid)}, lattice miss"); continue
        f1 = res[0]
        p, q = (f1, n // f1) if f1 < n // f1 else (n // f1, f1)
        print(f"fault fb={fb}: FACTORED ✓")
        for (pp, qq) in ((p, q), (q, p)):
            send_msg(s, {"action": "get_encrypted_flag"})
            r = recv_json(fp, s)
            ef = bytes.fromhex(r["encrypted_flag"])
            secret = SHA256.new(long_to_bytes(pp) + long_to_bytes(qq)).digest()
            try:
                flag = unpad(AES.new(secret, AES.MODE_ECB).decrypt(ef), 16)
            except Exception:
                continue
            if flag.startswith(b"crypto"):
                print("FLAG:", flag.decode())
                s.close()
                return flag.decode()
        print("factored but flag decrypt failed both orders")
        return None
    s.close()
    return None

if __name__ == "__main__":
    random.seed(os.urandom(8))
    for attempt in range(6):
        try:
            f = try_connection(attempt)
            if f:
                print("FLAG FOUND:", f)
                break
        except Exception as ex:
            print("conn error:", type(ex).__name__, ex)
