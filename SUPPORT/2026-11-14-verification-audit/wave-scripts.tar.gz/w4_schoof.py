"""Schoof's algorithm: #E for y^2 = x^3 + a x + b over F_p (pure python)."""
import sys, json
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')

# ---------- poly mod p helpers (lists low->high) ----------
def padd(A,B,p):
    n=max(len(A),len(B)); R=[0]*n
    for i in range(n):
        R[i]=((A[i] if i<len(A) else 0)+(B[i] if i<len(B) else 0))%p
    return trim(R,p)
def psub(A,B,p):
    n=max(len(A),len(B)); R=[0]*n
    for i in range(n):
        R[i]=((A[i] if i<len(A) else 0)-(B[i] if i<len(B) else 0))%p
    return trim(R,p)
def pmul(A,B,p):
    if not A or not B: return []
    R=[0]*(len(A)+len(B)-1)
    for i,ai in enumerate(A):
        if ai:
            for j,bj in enumerate(B):
                R[i+j]=(R[i+j]+ai*bj)%p
    return trim(R,p)
def trim(A,p):
    while A and A[-1]%p==0: A.pop()
    return [a%p for a in A]
def pmod(A,M,p):
    if len(A)<len(M): return A[:]
    Mi=pow(M[-1],-1,p)
    R=A[:]
    while len(R)>=len(M) and R:
        if R[-1]==0: R.pop(); continue
        c=R[-1]*Mi%p
        for i,m in enumerate(M):
            R[len(R)-len(M)+i]=(R[len(R)-len(M)+i]-c*m)%p
        R.pop()
    return trim(R,p)
def ppowmod(A,e,M,p):
    R=[1]; B=pmod(A,M,p)
    while e:
        if e&1: R=pmod(pmul(R,B,p),M,p)
        B=pmod(pmul(B,B,p),M,p); e>>=1
    return R
def pgcd(A,B,p):
    A=trim(A[:],p); B=trim(B[:],p)
    while B:
        A,B=B,pmod(A,B,p)
    if not A: return [1]
    c=pow(A[-1],-1,p)
    return [(a*c)%p for a in A]

# ---------- ring R = F_p[x]/(psi), element = poly; y represented pair (u0,u1): u0+u1*y ----------
def yinv_g(p, g):  # represent 1/(u0+u1 y): norm = u0^2 - u1^2*g
    pass
class R:
    """quadratic algebra over F_p[x]/(psi): a + b*y, y^2 = g(x)."""
    def __init__(self, psi, p):
        self.psi=psi; self.p=p
        self.g=trim([ (0 if 0<len('x') else 0) for _ in range(0)], p)
    def modm(self, A): return pmod(A, self.psi, self.p)
    def mul(self, U, V):
        p=self.p
        u0,u1=U; v0,v1=V
        # (u0+u1y)(v0+v1y)= u0v0 + u1v1 g + (u0v1+u1v0) y
        c0=padd(pmul(u0,v0,p), pmul(pmul(u1,v1,p), self.g, p), p)
        c1=padd(pmul(u0,v1,p), pmul(u1,v0,p), p)
        return (self.modm(c0), self.modm(c1))
    def add(self, U, V):
        p=self.p
        return (self.modm(padd(U[0],V[0],p)), self.modm(padd(U[1],V[1],p)))
    def neg(self, U):
        p=self.p
        return (self.modm(psub([],U[0],p)), self.modm(psub([],U[1],p)))
    def inv(self, U):
        p=self.p
        u0,u1=U
        nrm=self.modm(psub(pmul(u0,u0,p), pmul(pmul(u1,u1,p), self.g, p), p))
        # inverse of nrm in F_p[x]/psi
        ni=pow(int(poly_gcd_inv(nrm, self.psi, p)),1,p) if False else self.inv_poly(nrm)
        return (self.modm(pmul(ni,u0,p)), self.modm(psub([],pmul(ni,u1,p),p)))
    def inv_poly(self, A):
        # extended euclid for 1/A mod psi
        p=self.p
        old_r, r = trim(A[:],p), self.psi[:]
        old_s, s = [1], [0]
        while r:
            q, rr = pdivmod(old_r, r, p)
            old_r, r = r, rr
            old_s, s = s, psub(old_s, pmul(q,s,p), p)
        c=pow(old_r[-1],-1,p)
        return [(x*c)%p for x in old_s]
def pdivmod(A,M,p):
    R=A[:]
    Q=[0]*(max(0,len(A)-len(M))+1)
    Mi=pow(M[-1],-1,p)
    while len(R)>=len(M) and R:
        if R[-1]==0: R.pop(); continue
        d=len(R)-len(M)
        c=R[-1]*Mi%p
        Q[d]=(Q[d]+c)%p
        for i,m in enumerate(M):
            R[d+i]=(R[d+i]-c*m)%p
        R.pop()
    return trim(Q,p), trim(R,p)

def curve_add(P, Q, Rr):
    O = None
    if P is None: return Q
    if Q is None: return P
    x1,y1=P; x2,y2=Q
    if x1==x2:
        if Rr.add(y1, Rr.neg(y2))==(Rr.modm([]),Rr.modm([])):
            # same y -> double
            pass
        else:
            return None
    # slope
    num=Rr.sub(y2,y1) if hasattr(Rr,'sub') else (Rr.modm(psub(y2[0],y1[0],Rr.p)), Rr.modm(psub(y2[1],y1[1],Rr.p)))
    den=(Rr.modm(psub(x2[0],x1[0],Rr.p)), Rr.modm(psub(x2[1],x1[1],Rr.p)))
    # check den invertible; if x1==x2 fallback doubling
    try:
        dinv=Rr.inv(den)
    except ZeroDivisionError:
        # doubling: den = 2 y1
        den=(Rr.modm([]), Rr.modm([2]))
        dx1=(x1,x1)
        # num = (3x1^2 + a)
        three=(Rr.modm([3]),Rr.modm([]))
        xsq=Rr.mul(x1,x1)
        num=Rr.add(Rr.mul(three,xsq), (Rr.modm([Rr.a]),Rr.modm([])))
        dinv=Rr.inv(den)
        lam=Rr.mul(num,dinv)
        x3=Rr.sub3(Rr.mul(lam,lam), x1, x1)
        y3=Rr.subx(Rr.mul(lam,Rr.sub3(x1,x3,(Rr.modm([]),Rr.modm([])))), y1)
        return (x3,y3)
    lam=Rr.mul(num,dinv)
    x3=Rr.sub3(Rr.mul(lam,lam), x1, x2)
    y3=Rr.subx(Rr.mul(lam,Rr.sub3(x1,x3,(Rr.modm([]),Rr.modm([])))), y1)
    return (x3,y3)

# extend R with sub helpers
def rsub(self,U,V):
    p=self.p
    return (self.modm(psub(U[0],V[0],p)), self.modm(psub(U[1],V[1],p)))
def rsub3(self,U,V,W):
    return self.sub(self.sub(U,V),W)
def rsubx(self,U,V):
    return self.sub(U,V)
R.sub=rsub; R.sub3=rsub3; R.subx=rsubx

def psi_l(l, p, a, b):
    """l-th division polynomial for y^2=x^3+ax+b, odd l, as poly list mod p."""
    g=[b, a, 0, 1]  # x^3 + a x + b
    psi=[None]* (l+3)
    psi[1]=([1],Rr_none) if False else None
    # represent as (u0,u1) pairs in (u0 + u1 y)
    P1=(( [1],[] ),([ ],[]))  # placeholder
    # Use pair-of-polys: psi_k = (u0,u1) with u1=0 for odd k
    def addp(P,Q):
        return (trim([(P[0][i] if i<len(P[0]) else 0)+(Q[0][i] if i<len(Q[0]) else 0) for i in range(max(len(P[0]),len(Q[0])))],p),
                trim([(P[1][i] if i<len(P[1]) else 0)+(Q[1][i] if i<len(Q[1]) else 0) for i in range(max(len(P[1]),len(Q[1])))],p))
    def mulp(P,Q):
        return (pmul(P[0],Q[0],p), pmul(P[1],Q[1],p)) if (P[1]==[] or Q[1]==[]) and (P[0]==[] or Q[0]==[]) else _mul_full(P,Q)
    def _mul_full(P,Q):
        c0=padd(pmul(P[0],Q[0],p), pmul(pmul(P[1],Q[1],p), g, p),p)
        c1=padd(pmul(P[0],Q[1],p), pmul(P[1],Q[0],p),p)
        return (c0,c1)
    def divy2(P):  # P divisible by 2y in Z[x,y]: P=(0,W) -> W/(2g)
        assert P[0]==[]
        W=P[1]
        two_g=[ (2*x)%p for x in g ]
        q,r=pdivmod(W,two_g,p)
        assert r==[] or r==None and True or r in ([], None), "inexact"
        return ([],q)
    ps={}
    ps[1]=([1],[])
    ps[2]=([],[2])
    ps[3]=([ -pow(3,-0,p) if False else 3, 0, 6*a%p, 0, 0],[]) # wait 3x^4+6a x^2 +12 b x - a^2
    ps[3]=([-a*a%p, 12*b%p, 6*a%p, 0, 3],[])
    ps[4]= divy2(([],pmul([4],[1],p))) # not used; compute via recurrence
    # recurrence
    def get(k):
        if k in ps: return ps[k]
        if k%2==1:
            m=(k-1)//2
            A=get(m+2); B=get(m); C=get(m-1); D=get(m+1)
            v1=_mul_full(A, mulp3(B)); v2=_mul_full(C, mulp3(D))
            ps[k]=addp(v1, [ (p-x)%p for x in v2[0]] and ([ (0-x)%p for x in v2[0]],[ (0-x)%p for x in v2[1]]))
            return ps[k]
        else:
            m=k//2
            A=get(m)
            v=(_mul_full(get(m+2), pmul_square(get(m-1))), None)
            s1=_mul_full(get(m+2), _mul_full(get(m-1),get(m-1)))
            s2=_mul_full(get(m-2) if m-2>=1 else ([1],[]), _mul_full(get(m+1),get(m+1))) if m>=2 else (([],[]),)
            ps[k]=_mul_full(A, addp(s1, ([ (p-x)%p for x in s2[0]],[ (p-x)%p for x in s2[1]])))
            return ps[k]
    def mulp3(B): return _mul_full(_mul_full(B,B),B)
    def pmul_square(A,B): return _mul_full(A,B)
    # NOTE: even ps[0] needed for even branch when m=2 uses get(0): psi0=0 -> handle
    ps[0]=([],[])
    res=get(l)
    assert res[1]==[] or res[1]==None, "psi_l should be x-only for odd l"
    return res[0]

def t_mod_l(l, p, a, b):
    psi=psi_l(l,p,a,b)
    Rr=R(psi,p); Rr.a=a; Rr.g=[b,a,0,1]
    X=(( [0,1] ),[])  # x as element: (poly x, empty)
    x=( [0,1],[] )
    y=( [],[1] )
    # frobenius: x^l, y^l = y * g^{(l-1)/2}
    xl=ppowmod([0,1],l,psi,p)
    gl=pow_([b,a,0,1],(l-1)//2,psi,p)
    yl=([],[ ] if False else gl)  # y^l = gl * y -> (0, gl)
    yl=([], gl)
    def frob(P):
        xp,yp=P
        # substitute x -> xl for poly xp ; and element (u0,u1y) -> (u0(xl), u1(xl)*gl)
        u0=compose_mod(xp, xl, psi, p)
        u1=compose_mod(yp[1], xl, psi, p)
        return (u0, pmul(u1, gl, p))
    # wait need x^l as ELEMENT substitution: x^{l^2}=(x^l)^l: compose poly x^l with x^l.
    x2=compose_mod(xl, xl, psi, p)
    y2=([], pmul(pmod(pmul(gl, yl[1], p), psi, p), [], p) )
    # y^{l^2} = y * g^{(l^2-1)/2}
    g2=pow_([b,a,0,1],(l*l-1)//2,psi,p)
    y2=([], g2)
    # x^{l^2} via pow direct:
    x2=ppowmod([0,1],l*l,psi,p)
    phi2=(x2,y2)
    # [p] P
    def cmul(n, P):
        Rr_=Rr; Q=P; S=None
        while n:
            if n&1: S=curve_add(S,Q,Rr_)
            Q=curve_add(Q,Q,Rr_); n>>=1
        return S
    lhs=curve_add(phi2, cmul(p, (x,y)), Rr)
    # find r: lhs == [r]phi where phi=(xl,(0,gl))
    phi=(([0,1] if False else xl, yl))
    # check lhs equals [r] phi for r in 0..l-1
    acc=None
    for r in range(l):
        if acc is not None:
            if acc[0]==lhs[0] and acc[1]==lhs[1]:
                return r
            acc=curve_add(acc, phi, Rr)
        else:
            if lhs is None: return r
            if lhs[0]==acc if False else False: pass
        # compare None cases
        if acc is None and lhs is None: return r
    # redo cleanly
    acc=None
    for r in range(l):
        eq = (acc is None and lhs is None) or (acc is not None and lhs is not None and acc[0]==lhs[0] and acc[1]==lhs[1])
        if eq: return r
        acc=curve_add(acc, phi, Rr)
    raise RuntimeError("no match l=%d"%l)

def pow_(A,e,M,p):
    return ppowmod(A,e,M,p)
def compose_mod(A, B, M, p):
    # A(B(x)) mod M
    Rr_=[1]; X=[0,1]
    res=[]
    for c in reversed(A):
        res=padd(pmul(res,B,p),[c],p)
    return pmod(res,M,p)

def schoof(p,a,b):
    import math
    primes=[2,3,5,7,11,13,17,19,23]
    mods=[]; res=[]
    # t mod 2
    psi=[b,a,0,1]
    xp=ppowmod([0,1],p,psi,p)
    d=pgcd(pmod(psub(xp,[0,1],p), psi, p), psi, p)
    tmod2 = 0 if len(d)==len(psi) else 1
    mods.append(2); res.append(tmod2)
    for l in primes[1:]:
        mods.append(l); res.append(t_mod_l(l,p,a,b))
    # CRT
    t=0; M=1
    for m,r in zip(mods,res):
        t=(t + M*((r-t)*pow(M,-1,m)%m))%(M*m); M*=m
    lim=2*isqrt(p)+1
    tt=t if t<=lim else t-M
    # both candidates near Hasse: verify via random point
    return tt, M

def isqrt(n):
    import math
    return math.isqrt(n)

if __name__=='__main__':
    import random
    p = 1331169830894825846283645180581
    a = -35 % p; b = 98
    tt, M = schoof(p,a,b)
    print("t candidate:", tt, " M=", M)
    # verify n = p+1-t kills random points
    from eclib import Curve
    E=Curve(a,b,p)
    n=p+1-tt
    if n%2: n_alt=p+1+tt
    else: n_alt=p+1+tt
    for trial in range(3):
        x=random.randrange(2,p)
        rhs=(x*x*x+a*x+b)%p
        import sympy
        from sympy.ntheory.residue_ntheory import sqrt_mod
        y=sqrt_mod(rhs,p)
        if y is None: continue
        P=(x,int(y))
        ok1=E.mul(P,n) is None
        ok2=E.mul(P,n_alt) is None
        print("t=%d -> %s ; t=%d -> %s" % (-tt if False else tt, ok1, tt, ok2))
        if ok1: print("#E =", n); json.dump({'t':-tt if False else -tt, 'nE':n}, open('w4_schoof.json','w')); break
        if ok2: print("#E =", n_alt); json.dump({'t': tt, 'nE':n_alt}, open('w4_schoof.json','w')); break
        break
