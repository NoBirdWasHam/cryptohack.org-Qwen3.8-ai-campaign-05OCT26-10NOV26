import re, hashlib, sympy
from math import isqrt
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def bsgs_fp(gq, hq, q):
    """x in [0,q): gq^x = hq mod p, q prime"""
    m = isqrt(q) + 1
    table = {}
    e = 1
    for j in range(m):
        table.setdefault(e, j)
        e = e * gq % p
    gm = pow(gq, m, p)
    cur = hq
    for i in range(m + 1):
        if cur in table:
            x = (table[cur] - i*m) % q
            if pow(gq, x, p) == hq: return x
        cur = cur * gm % p
    raise RuntimeError("fp bsgs fail")

txt = open('eg_relay_DH64.txt').read()
p  = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
g  = int(re.search(r'"g": "0x([0-9a-f]+)"', txt).group(1), 16)
A  = int(re.search(r'"A": "0x([0-9a-f]+)"', txt).group(1), 16)
B  = int(re.search(r'"B": "0x([0-9a-f]+)"', txt).group(1), 16)
iv = re.search(r'"iv": "([0-9a-f]+)"', txt).group(1)
ct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt).group(1)
fac = sympy.factorint(p-1)
xs, mods = [], []
for q, e in fac.items():
    pe = q**e
    gq = pow(g, (p-1)//pe, p)
    hq = pow(A, (p-1)//pe, p)
    xi = 0
    gqq = pow(gq, pe//q, p)  # order q
    for k in range(e):
        rem = hq * pow(gq, -xi, p) % p
        hk = pow(rem, pe//(q**(k+1)), p)
        dk = bsgs_fp(gqq, hk, q)
        xi += dk * (q**k)
    xs.append(xi); mods.append(pe)
# CRT
a, m = 0, 1
for xi, pe in zip(xs, mods):
    a = (a + m * ((xi - a) * pow(m, -1, pe) % pe)) % (m * pe)
    m *= pe
assert pow(g, a, p) == A, "dlog verify failed"
S = pow(B, a, p)
print("a =", a, "S =", S)
key = hashlib.sha1(str(S).encode('ascii')).digest()[:16]
pt = AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct))
flag = unpad(pt, 16).decode()
print("FLAG:", flag)
open('eg_flag.txt','w').write(flag)
