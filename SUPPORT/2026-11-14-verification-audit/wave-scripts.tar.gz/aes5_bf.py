import itertools
base = r'~/AppData/Local/hermes/cache/scratch/aes_att'
exec(open(base+r'/aes4_sbox.py').read().split('def sub_bytes')[0])  # s_box, inv_s_box
src = open(base+r'/aes5_diffusion.py').read().split('state =')[0].replace('???', 'pass')
exec(src)  # shift_rows, mix_columns, inv_mix_columns
def shift_rows(s):
    s[0][1], s[1][1], s[2][1], s[3][1] = s[1][1], s[2][1], s[3][1], s[0][1]
    s[0][2], s[1][2], s[2][2], s[3][2] = s[2][2], s[3][2], s[0][2], s[1][2]
    s[0][3], s[1][3], s[2][3], s[3][3] = s[3][3], s[0][3], s[1][3], s[2][3]
def inv_shift_rows(s):
    s[0][1], s[1][1], s[2][1], s[3][1] = s[3][1], s[0][1], s[1][1], s[2][1]
    s[0][2], s[1][2], s[2][2], s[3][2] = s[2][2], s[3][2], s[0][2], s[1][2]
    s[0][3], s[1][3], s[2][3], s[3][3] = s[1][3], s[2][3], s[3][3], s[0][3]
def cp(s): return [r[:] for r in s]
def subf(sb):
    def f(s):
        for i in range(4):
            for j in range(4): s[i][j] = sb[s[i][j]]
    return f
ops = {'id': lambda s: None, 'shift': shift_rows, 'ishift': inv_shift_rows,
       'mix': mix_columns, 'imix': inv_mix_columns,
       'isub': subf(inv_s_box), 'sub': subf(s_box)}
state5 = [[108,106,71,86],[96,62,38,72],[42,184,92,209],[94,79,8,54]]
def m2b(m): return bytes(v for row in m for v in row)
found = []
for n in (1,2,3,4):
    for combo in itertools.product(ops, repeat=n):
        s = cp(state5)
        for name in combo: ops[name](s)
        b = m2b(s)
        if b'crypto{' in b:
            found.append((combo, b))
seen = set()
for c, b in found:
    if b not in seen:
        seen.add(b); print(c, b)
print('total', len(found))
