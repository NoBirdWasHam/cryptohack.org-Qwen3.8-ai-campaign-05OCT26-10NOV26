import socket, json, sys
from Crypto.Util.number import bytes_to_long, long_to_bytes

def readline(s, acc=b""):
    while b"\n" not in acc:
        d = s.recv(65536)
        if not d: return acc.decode(errors="replace")
        acc += d
    line, rest = acc.split(b"\n", 1)
    return line.decode(), rest

def send(s, obj):
    s.sendall((json.dumps(obj) + "\n").encode())

def recv(s):
    line, _ = readline(s)
    try:
        return json.loads(line)
    except Exception:
        return {"raw": line}

def read_json_obj(s):
    buf = b""
    while True:
        try:
            line, buf2 = readline(s, buf)
        except Exception:
            raise
        if isinstance(line, bytes):  # EOF path
            print("RAW:", line); raise RuntimeError("eof")
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                return json.loads(line), buf2
            except Exception:
                pass
        else:
            print("TEXT:", line[:200])
            # keep remaining buffer
            res = readline(s, buf)
            if isinstance(res, tuple):
                _, buf = res[1], res[1]
        # simpler: just loop reading next line
        buf = b""

def main():
    s = socket.create_connection(("socket.cryptohack.org", 13409), timeout=60)
    material, _ = read_json_obj(s)
    print("MATERIAL KEYS:", list(material.keys()))
    print("n bits:", material["share_key_pub"][0].bit_length(), "e:", material["share_key_pub"][1])
    json.dump(material, open(r"~/AppData/Local/hermes/cache/scratch/mega_material.json", "w"))
    send(s, {"action": "wait_login"})
    r1 = recv(s)
    print("wait_login ->", r1)
    n, e = material["share_key_pub"]
    ct = n - 1
    payload = {
        "action": "send_challenge",
        "SID_enc": long_to_bytes(ct).hex(),
        "share_key_enc": material["share_key_enc"],
        "master_key_enc": material["master_key_enc"],
    }
    send(s, payload)
    r2 = recv(s)
    print("send_challenge ->", json.dumps(r2)[:1200])
    if "SID" in r2 and r2["SID"]:
        sid = bytes.fromhex(r2["SID"])
        print("SID len bytes:", len(sid))
        # fault check: correct decryption of n-1 is n-1; top bytes would be all 0xff
        exp_top = long_to_bytes(n - 1)[:-16]
        print("SID == correct-decrypt-minus-pad?", sid == exp_top)
        json.dump({"SID_hex": r2["SID"]}, open(r"~/AppData/Local/hermes/cache/scratch/mega_fault1.json", "w"))
    send(s, {"action": "get_encrypted_flag"})
    r3 = recv(s)
    print("flag enc ->", json.dumps(r3)[:400])
    json.dump(r3, open(r"~/AppData/Local/hermes/cache/scratch/mega_flagenc.json", "w"))
    s.close()

main()
