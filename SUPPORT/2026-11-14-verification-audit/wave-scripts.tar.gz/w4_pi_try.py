import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
iv = bytes.fromhex('94fd87ea2b9236ce0532138c677acde2')
ct = bytes.fromhex('968928b0b6e0e63e1d4a94c9ffa0f9e58afeb97f5f79a4f662d842d040280fdf')
def try_key(name, key):
    try:
        pt = AES.new(key, AES.MODE_CBC, iv).decrypt(ct)
        pad = pt[-pt[-1]:]
        if len(pad) in range(1,17) and all(c == pt[-1] for c in pad) and b'crypto' in pt:
            print("HIT", name, "->", pt)
            return True
        print("no", name, "->", pt[:32])
    except Exception as e:
        print("err", name, e)
    return False
for s in [0, 1, -1, 2]:
    ss = str(s % (2**3072)) if s != -1 else str(-1)
    for h in ['sha1','md5','sha256']:
        pass
for s in ['0','1']:
    try_key('sha1(%s)'%s, hashlib.sha1(s.encode()).digest()[:16])
    try_key('md5(%s)'%s, hashlib.md5(s.encode()).digest())
    try_key('sha256(%s)'%s, hashlib.sha256(s.encode()).digest()[:16])
try_key('sha1(-1)', hashlib.sha1(b'-1').digest()[:16])
