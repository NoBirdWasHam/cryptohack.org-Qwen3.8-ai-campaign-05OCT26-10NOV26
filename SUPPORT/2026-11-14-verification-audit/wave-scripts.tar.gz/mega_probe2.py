import socket, json, sys
from Crypto.Util.number import bytes_to_long, long_to_bytes

class Stream:
    def __init__(self, s):
        self.s = s
        self.buf = b""
    def line(self):
        while b"\n" not in self.buf:
            d = self.s.recv(65536)
            if not d:
                return None
            self.buf += d
        ln, self.buf = self.buf.split(b"\n", 1)
        return ln.decode(errors="replace")
    def json(self, verbose=True):
        while True:
            ln = self.line()
            if ln is None:
                raise RuntimeError("EOF, leftover=%r" % self.buf[:300])
            t = ln.strip()
            if t.startswith("{") and t.endswith("}"):
                try:
                    return json.loads(t)
                except Exception:
                    pass
            elif t and verbose:
                print("TEXT:", t[:300])
    def send(self, obj):
        self.s.sendall((json.dumps(obj) + "\n").encode())

def main():
    s = socket.create_connection(("socket.cryptohack.org", 13409), timeout=60)
    st = Stream(s)
    material = st.json()
    print("MATERIAL KEYS:", list(material.keys()))
    n, e = material["share_key_pub"]
    print("n bits:", n.bit_length(), "e:", e)
    json.dump(material, open(r"~/AppData/Local/hermes/cache/scratch/mega_material.json", "w"))
    st.send({"action": "wait_login"})
    print("wait_login ->", st.json())
    ct = n - 1
    st.send({
        "action": "send_challenge",
        "SID_enc": long_to_bytes(ct).hex(),
        "share_key_enc": material["share_key_enc"],
        "master_key_enc": material["master_key_enc"],
    })
    r2 = st.json()
    print("send_challenge ->", json.dumps(r2)[:1500])
    if "SID" in r2 and r2["SID"]:
        sid = bytes.fromhex(r2["SID"])
        print("SID len bytes:", len(sid))
        print("SID == correct-decrypt-minus-pad?", sid == long_to_bytes(n - 1)[:-16])
        print("SID head:", sid[:24].hex())
        json.dump({"SID_hex": r2["SID"]}, open(r"~/AppData/Local/hermes/cache/scratch/mega_fault1.json", "w"))
    st.send({"action": "get_encrypted_flag"})
    r3 = st.json()
    print("flag enc ->", json.dumps(r3)[:300])
    json.dump(r3, open(r"~/AppData/Local/hermes/cache/scratch/mega_flagenc.json", "w"))
    s.close()

main()
