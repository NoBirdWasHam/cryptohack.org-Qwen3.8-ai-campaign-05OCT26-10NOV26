import sys, json
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch/aes_att')
from Crypto.Cipher import AES

def m2b(m): return bytes(v for row in m for v in row)
def b2m(t): return [list(t[i:i+4]) for i in range(0,len(t),4)]

res = {}

# ---------- aes2 ----------
matrix = [[99,114,121,112],[116,111,123,105],[110,109,97,116],[114,105,120,125]]
res['aes2'] = m2b(matrix).decode()

# ---------- aes3 ----------
state  = [[206,243,61,34],[171,11,93,31],[16,200,91,108],[150,3,194,51]]
rkey   = [[173,129,68,82],[223,100,38,109],[32,189,53,8],[253,48,187,78]]
s3 = [[state[r][c]^rkey[r][c] for c in range(4)] for r in range(4)]
res['aes3'] = m2b(s3).decode(errors='replace')

# ---------- aes4 ----------
exec(open(r'~/AppData/Local/hermes/cache/scratch/aes_att/aes4_sbox.py').read().split('def sub_bytes')[0])  # gets s_box, inv_s_box, state
s4 = [[inv_s_box[v] for v in row] for row in state]
res['aes4'] = m2b(s4).decode(errors='replace')

# ---------- aes5 ----------
state5 = [[108,106,71,86],[96,62,38,72],[42,184,92,209],[94,79,8,54]]
def inv_shift_rows(s):
    s = [row[:] for row in s]
    for c in (1,2,3):
        s[0][c],s[1][c],s[2][c],s[3][c] = s[3][c],s[0][c],s[1][c],s[2][c]
    return s
res['aes5'] = m2b(inv_shift_rows(state5)).decode(errors='replace')

# ---------- aes6: own AES-128 decrypt from spec ----------
sbox = s_box  # from aes4 file exec
def decrypt_aes128(key, ct):
    # key expansion
    words = [list(key[4*i:4*i+4]) for i in range(4)]
    rcon = 1
    while len(words) < 44:
        w = words[-1][:]
        if len(words) % 4 == 0:
            w = w[1:]+w[:1]
            w = [sbox[b] for b in w]
            w[0] ^= rcon; rcon = ((rcon<<1) ^ (0x1B if rcon & 0x80 else 0)) & 0xFF
        words.append([a^b for a,b in zip(w, words[-4])])
    rk = [words[4*i:4*i+4] for i in range(11)]
    # note: challenge code treats columns as rows via bytes2matrix; standard:
    # state[row][col] = ct[col*4+row]; here follow FIPS-197 byte-to-state mapping
    st = [[ct[c*4+r] for c in range(4)] for r in range(4)]
    def addrk(r):
        for c in range(4):
            for r_ in range(4): st[r_][c] ^= rk[r][c][r_]
    xtime = lambda a: ((a<<1)^0x1B)&0xFF if a&0x80 else (a<<1)&0xFF
    gmul = lambda a,b: __import__('functools').reduce(lambda x,y: x^xtime(x) if False else x, [0]) # unused
    def gmul(a,b):
        p=0
        for _ in range(8):
            if b&1: p^=a
            hi=a&0x80; a=(a<<1)&0xFF
            if hi: a^=0x1B
            b>>=1
        return p
    def inv_sb():
        for r in range(4):
            for c in range(4): st[r][c]=inv_s_box[st[r][c]]
    def inv_sr():
        st[1]=[st[1][3],st[1][0],st[1][1],st[1][2]]
        st[2]=[st[2][2],st[2][3],st[2][0],st[2][1]]
        st[3]=[st[3][1],st[3][2],st[3][3],st[3][0]]
    def inv_mc():
        for c in range(4):
            a=[st[r][c] for r in range(4)]
            st[0][c]=gmul(a[0],14)^gmul(a[1],11)^gmul(a[2],13)^gmul(a[3],9)
            st[1][c]=gmul(a[0],9)^gmul(a[1],14)^gmul(a[2],11)^gmul(a[3],13)
            st[2][c]=gmul(a[0],13)^gmul(a[1],9)^gmul(a[2],14)^gmul(a[3],11)
            st[3][c]=gmul(a[0],11)^gmul(a[1],13)^gmul(a[2],9)^gmul(a[3],14)
    key6 = b'\xc3,\x5c\xa6\xb5\x80\x5e\x0c\xdb\x8d\xa5\x7a\x2a\xb6\xfe\x5c'
    addrk(10)
    for i in range(9,0,-1):
        inv_sr(); inv_sb(); addrk(i); inv_mc()
    inv_sr(); inv_sb(); addrk(0)
    return bytes(st[r][c] for c in range(4) for r in range(4))

key = b'\xc3,\\\xa6\xb5\x80^\x0c\xdb\x8d\xa5z*\xb6\xfe\\'
ct  = b'\xd1O\x14j\xa4+O\xb6\xa1\xc4\x08B)\x8f\x12\xdd'
own = decrypt_aes128(key, ct)
ref = AES.new(key, AES.MODE_ECB).decrypt(ct)
assert own == ref, (own, ref)
res['aes6'] = own.decode(errors='replace')

# ---------- dancing-queen ----------
M = 0xffffffff
def rotl(x,n): return ((x<<n)|(x>>(32-n)))&M
def rotr(x,n): return ((x>>n)|(x<<(32-n)))&M
def iqr(x,a,b,c,d):  # inverse quarter round of the implementation's QR
    # undo 4th line: c+=d; b^=c; b=rot(b,7)
    x[b]=rotr(x[b],7); x[b]^=x[c]; x[c]=word_sub(x[c],x[d])
    # undo 3rd: a+=b; d^=a; d=rot(d,8)
    x[d]=rotr(x[d],8); x[d]^=x[a]; x[a]=word_sub(x[a],x[b])
    # undo 2nd: c+=d; b^=c; b=rot(b,12)
    x[b]=rotr(x[b],12); x[b]^=x[c]; x[c]=word_sub(x[c],x[d])
    # undo 1st: a+=b; d^=a; d=rot(d,16)
    x[d]=rotr(x[d],16); x[d]^=x[a]; x[a]=word_sub(x[a],x[b])
def word_sub(a,b): return (a-b)&M
def inner(x):  # same as impl
    for t in ((0,4,8,12),(1,5,9,13),(2,6,10,14),(3,7,11,15),
              (0,5,10,15),(1,6,11,12),(2,7,8,13),(3,4,9,14)):
        a,b,c,d=t
        x[a]=(x[a]+x[b])&M; x[d]^=x[a]; x[d]=rotl(x[d],16)
        x[c]=(x[c]+x[d])&M; x[b]^=x[c]; x[b]=rotl(x[b],12)
        x[a]=(x[a]+x[b])&M; x[d]^=x[a]; x[d]=rotl(x[d],8)
        x[c]=(x[c]+x[d])&M; x[b]^=x[c]; x[b]=rotl(x[b],7)
def iinner(x):
    for t in reversed([(0,4,8,12),(1,5,9,13),(2,6,10,14),(3,7,11,15),
              (0,5,10,15),(1,6,11,12),(2,7,8,13),(3,4,9,14)]):
        iqr(x,*t)
def b2w(b): return [int.from_bytes(b[i:i+4],'little') for i in range(0,len(b),4)]
def w2b(w): return b''.join(i.to_bytes(4,'little') for i in w)
def xor(a,b): return bytes(x^y for x,y in zip(a,b))

iv1=bytes.fromhex('e42758d6d218013ea63e3c49')
iv2=bytes.fromhex('a99f9a7d097daabd2aa2a235')
msg_enc=bytes.fromhex('f3afbada8237af6e94c7d2065ee0e221a1748b8c7b11105a8cc8a1c74253611c94fe7ea6fa8a9133505772ef619f04b05d2e2b0732cc483df72ccebb09a92c211ef5a52628094f09a30fc692cb25647f')
flag_enc=bytes.fromhex('b6327e9a2253034096344ad5694a2040b114753e24ea9c1af17c10263281fb0fe622b32732')
msg = b'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula.'
assert len(msg)==len(msg_enc)
ks = xor(msg_enc[:64], msg[:64])
st = b2w(ks)          # final state of block (ctr=1, iv1) since NO feedforward add
for _ in range(10): iinner(st)
# st should be initial: constants, key, counter=1, iv1
const = [0x61707865,0x3320646e,0x79622d32,0x6b206574]
assert st[0:4]==const, st[0:4]
assert st[12]==1
assert w2b(st[13:16])==iv1
key_dq = w2b(st[4:12])
def keystream(counter, iv, nblocks=1):
    s0 = const + b2w(key_dq) + [counter] + b2w(iv)
    s = s0[:]
    for _ in range(10): inner(s)
    return w2b(s)  # no feedforward, matches buggy impl
# verify against msg_enc block0 and block1
assert xor(keystream(1,iv1), msg[:64]) == msg_enc[:64]
assert xor(keystream(2,iv1), msg[64:]) == msg_enc[64:]
flag = xor(keystream(1,iv2)[:len(flag_enc)], flag_enc)
res['dancing-queen'] = flag.decode(errors='replace')

print(json.dumps(res, indent=1))
