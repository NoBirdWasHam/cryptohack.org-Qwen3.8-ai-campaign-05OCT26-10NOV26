import socket, json, sys
host, port = 'socket.cryptohack.org', 13371
AVAL = sys.argv[1] if len(sys.argv)>1 else '0x0'
s = socket.create_connection((host, port), timeout=15)
s.settimeout(10)
buf = b''
def rdlines():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:100]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
first = rdlines()
amsg = json.loads(first[0].split('Intercepted from Alice:',1)[1])
inj = json.dumps({"p": amsg['p'], "g": amsg['g'], "A": AVAL})
s.sendall((inj + '\n').encode())
r = rdlines()
txt = '\n'.join(r)
bob = txt.split('Intercepted from Bob:',1)[1].split('<')[0].strip()
s.sendall((bob + '\n').encode())
print("relayed Bob msg")
allr = []
for i in range(3):
    rr = rdlines(); allr += rr
    print("RESP%d:" % i, [l[:700] for l in rr])
    if any('<EOF>' in l for l in rr): break
open('pi_13371_A0.log','w').write('\n'.join(first+allr))
s.close()
