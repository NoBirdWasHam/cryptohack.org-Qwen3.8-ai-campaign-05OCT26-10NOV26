# Vanishing-polynomial lattice: find L with p | (A+L). Rows: N*x^j ; (x+A)*x^i (scaled by X^k)
import math, random
from Crypto.PublicKey import RSA
from fpylll import IntegerMatrix
from fpylll.fplll.lll import lll_reduction
import sympy

def solve_L(N, A, X, b=1, verbose=False):
    a = b + 1
    cols = a + b + 2
    rows = []
    for j in range(a + 1):
        r = [0] * cols
        r[j] = N * pow(X, j)
        rows.append(r)
    for i in range(b + 1):
        r = [0] * cols
        r[i] = A * pow(X, i)
        r[i + 1] = pow(X, i + 1)
        rows.append(r)
    M = IntegerMatrix.from_matrix(rows)
    M = lll_reduction(M)
    xs = sympy.Symbol("x")
    cands = set()
    for row in M:
        cf = []
        ok = True
        for k in range(cols):
            v = int(row[k]); w = pow(X, k)
            if v % w: ok = False; break
            cf.append(v // w)
        if not ok: continue
        while cf and cf[-1] == 0: cf.pop()
        if len(cf) < 2: continue
        if len(cf) == 2:
            if cf[0] % cf[1] == 0:
                cands.add(-cf[0] // cf[1])
        elif len(cf) == 3:
            aa, bb, cc = cf[2], cf[1], cf[0]
            disc = bb * bb - 4 * aa * cc
            if disc >= 0:
                s = math.isqrt(disc)
                if s * s == disc:
                    for num in (-bb + s, -bb - s):
                        if aa != 0 and num % (2 * aa) == 0:
                            cands.add(num // (2 * aa))
        else:
            try:
                poly = sympy.Poly(sum(c * xs**k for k, c in enumerate(cf)), xs)
                for rv in sympy.nroots(poly, n=60, maxsteps=80):
                    cr = complex(rv)
                    if abs(cr.imag) < 1e-10 and abs(cr.real) <= X:
                        cands.add(int(round(cr.real)))
            except Exception:
                pass
    for L in cands:
        if abs(L) > X: continue
        g = math.gcd(A + L, N)
        if 1 < g < N and g * (N // g) == N:
            return g, L
    return None

if __name__ == "__main__":
    random.seed(7)
    key = RSA.generate(2048)
    p, q, n = key.p, key.q, key.n
    X = 1 << 128
    hits = 0
    for trial in range(5):
        z = random.randrange(1 << 900, q)
        L0 = random.randrange(0, X)
        A = (z * p - L0) % n
        r = solve_L(n, A, X, b=1)
        ok = r and (r[0] == p or r[0] == q)
        hits += ok
        print("trial", trial, "b=1", "HIT" if ok else "miss", (r[1] == -L0 % (1<<128)) if r else "")
        if not r:
            r = solve_L(n, A, X, b=2)
            ok2 = r and (r[0] == p or r[0] == q)
            hits += ok2
            print("   b=2", "HIT" if ok2 else "miss")
    print("hits", hits, "/5")
