import socket, json, sys
supported = json.loads(sys.argv[1])
s = socket.create_connection(('socket.cryptohack.org', 13379), timeout=20)
s.settimeout(30)
buf = b''
def rdlines():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:200]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out
log = []
first = rdlines(); log += first
print('\n'.join(x[:300] for x in first))
s.sendall((json.dumps({"supported": supported}) + '\n').encode())
# generic honest relay loop
for i in range(8):
    r = rdlines(); log += r
    txt = '\n'.join(r)
    print('=== RESP%d' % i, [x[:1500] for x in r])
    if any('<EOF>' in x for x in r): break
    for x in r:
        if 'Send to Alice:' in x and 'Intercepted from Bob:' in x:
            body = x.split('Intercepted from Bob:',1)[1].strip()
            s.sendall((body + '\n').encode()); print('>> relayed to Alice')
        elif 'Send to Bob:' in x and 'Intercepted from Alice:' in x:
            body = x.split('Intercepted from Alice:',1)[1].strip()
            s.sendall((body + '\n').encode()); print('>> relayed to Bob')
open('eg_honest_%s.txt' % supported[0], 'w').write('\n'.join(log))
