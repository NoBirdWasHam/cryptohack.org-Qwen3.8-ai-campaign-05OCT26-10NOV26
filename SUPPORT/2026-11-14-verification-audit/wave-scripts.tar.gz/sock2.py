import socket, sys, time
host, port = 'socket.cryptohack.org', int(sys.argv[1])
lines = sys.argv[2] if len(sys.argv) > 2 else ''
s = socket.create_connection((host, port), timeout=15)
s.settimeout(12)
buf = b''
log = []
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1)
            out.append(ln.decode(errors='replace'))
            continue
        try:
            d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:80])
            break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''
            out.append('<EOF>')
            break
        buf += d
    t = '\n'.join(out)
    if out: log.append('<<< ' + t)
    return t
print(rd())
for ln in filter(None, lines.split('\x1f')):
    if ln == 'SLEEP':
        time.sleep(8); print(rd()); continue
    print('>>> ' + ln[:120] + ('...' if len(ln) > 120 else ''))
    s.sendall((ln + '\n').encode())
    print(rd())
open(sys.argv[3], 'w').write('\n'.join(log))
s.close()
