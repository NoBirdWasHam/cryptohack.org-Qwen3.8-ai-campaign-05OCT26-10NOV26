import socket, json, time, hashlib, sys
from ecdsa.ecdsa import Public_key, Private_key, Signature, generator_192
from ecdsa.numbertheory import inverse_mod
from Crypto.Util.number import bytes_to_long, long_to_bytes

g = generator_192
n = g.order()

def sha1(data):
    return hashlib.sha1(data).digest()

host, port = 'socket.cryptohack.org', 13381
s = socket.create_connection((host, port), timeout=20)
s.settimeout(25)
buf = b''
def rdline():
    global buf
    while b'\n' not in buf:
        d = s.recv(65536)
        if not d: raise EOFError(buf)
        buf += d
    ln, buf = buf.split(b'\n', 1)
    return ln.decode(errors='replace')

def req(obj):
    s.sendall((json.dumps(obj) + '\n').encode())
    # read lines until we get something that parses as JSON (skip prompt lines)
    while True:
        ln = rdline()
        ln = ln.strip()
        if not ln: continue
        try:
            return json.loads(ln)
        except Exception:
            # prompt may be concatenated; find first {
            i = ln.find('{')
            if i >= 0:
                try: return json.loads(ln[i:])
                except Exception: pass
            print("skip:", ln[:100], file=sys.stderr)

def sign_time():
    r = req({"option": "sign_time"})
    if 'msg' not in r:
        raise RuntimeError(r)
    return r

# collect two signatures on DIFFERENT messages
sigs = []
deadline = time.time() + 120
seen = set()
while len(sigs) < 2 and time.time() < deadline:
    try:
        r = sign_time()
    except Exception as e:
        print("sign err", e, file=sys.stderr); time.sleep(1); continue
    if r['msg'] in seen:
        time.sleep(1.2); continue
    seen.add(r['msg'])
    sigs.append(r)
    print("got:", r)
assert len(sigs) == 2, "need two distinct-message sigs"

def log_candidates(sg):
    h = bytes_to_long(sha1(sg['msg'].encode()))
    r = int(sg['r'], 16); sv = int(sg['s'], 16)
    out = {}
    for k in range(1, 60):
        try:
            rk = inverse_mod(r, n)
        except Exception:
            continue
        d = (sv * k - h) % n * rk % n
        if d:
            out[d] = k
    return out

c1 = log_candidates(sigs[0])
h2 = bytes_to_long(sha1(sigs[1]['msg'].encode()))
r2 = int(sigs[1]['r'], 16); s2 = int(sigs[1]['s'], 16)
ok = []
for d, k1 in c1.items():
    Q = d * g
    try:
        w = inverse_mod(s2, n)
    except Exception:
        continue
    u1 = h2 * w % n; u2 = r2 * w % n
    X = u1 * g + u2 * Q
    if X is not None and X.x() % n == r2:
        ok.append((d, k1))
print("key candidates:", len(ok))
assert len(ok) >= 1
d, k1 = ok[0]
print("recovered private key d =", hex(d), "(from k1=%d)" % k1)
Q = d * g
# sanity: does it also reproduce sig0?
w = inverse_mod(int(sigs[0]['s'],16), n)
X = bytes_to_long(sha1(sigs[0]['msg'].encode())) * w % n * g + int(sigs[0]['r'],16) * w % n * Q
assert X.x() % n == int(sigs[0]['r'],16)

# forge "unlock"
priv = Private_key(Public_key(g, Q), d)
h_u = bytes_to_long(sha1(b'unlock'))
for k in (0xc0ffee, 12345, 987654321):
    sig = priv.sign(h_u, k)
    r = req({"option": "verify", "msg": "unlock", "r": hex(sig.r), "s": hex(sig.s)})
    print("verify ->", r)
    if 'flag' in r:
        print("PS3 FLAG:", r['flag'])
        json.dump(r['flag'], open(r'~/AppData/Local/hermes/cache/scratch/w4_ps3.json','w'))
        break
s.close()
