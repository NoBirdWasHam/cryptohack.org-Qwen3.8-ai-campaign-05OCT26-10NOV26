# Full local replica of Megalomaniac-2 server logic + CF-factor attack
import random, math
from Crypto.PublicKey import RSA
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import pad, unpad
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

class Client:
    def __init__(self, key):
        self.key = key
        self.master = get_random_bytes(16)
        data = b""
        for num in (key.p, key.q, key.d, key.u):
            nb = long_to_bytes(num)
            data += long_to_bytes(len(nb), 2) + nb
        self.blob = AES.new(self.master, AES.MODE_ECB).encrypt(pad(data, 16))
        self.enc_key = get_random_bytes(16)
        self.mke = AES.new(self.enc_key, AES.MODE_ECB).encrypt(self.master)
        self.flag = b"FLAG-REDACTED-SEE-FLAGS-MIRROR"
    def login_step2(self, SID_enc, share_key_enc, master_key_enc, flip_block=None, flipval=None):
        cm = AES.new(self.master, AES.MODE_ECB)
        blob = bytearray(share_key_enc)
        if flip_block is not None:
            blob[flip_block*16:(flip_block+1)*16] = flipval if flipval is not None else os_urand(16)
        try:
            share_key = unpad(cm.decrypt(bytes(blob)), 16)
        except Exception:
            return None
        index = 0; els = []
        while index < len(share_key):
            ln = bytes_to_long(share_key[index:index+2]); index += 2
            els.append(bytes_to_long(share_key[index:index+ln])); index += ln
        if len(els) != 4: return None
        p, q, d, u = els
        ct = bytes_to_long(SID_enc)
        if ct == 0: ct = self.key.n
        mp = pow(ct, d % (p-1), p); mq = pow(ct, d % (q-1), q)
        h = ((mq - mp) % q * u) % q
        m = h * p + mp
        return long_to_bytes(m)[:-16]
    def enc_flag(self):
        secret = SHA256.new(long_to_bytes(self.key.p) + long_to_bytes(self.key.q)).digest()
        return AES.new(secret, AES.MODE_ECB).encrypt(pad(self.flag, 16))

def os_urand(n):
    import os; return os.urandom(n)

def blob_layout(key):
    offs = 0; reg = {}
    for name, num in (("p", key.p), ("q", key.q), ("d", key.d), ("u", key.u)):
        ln = len(long_to_bytes(num))
        reg[name] = (offs, offs + 2 + ln); offs += 2 + ln
    return reg

def safe_u_blocks(key, blob_len):
    reg = blob_layout(key)
    u0, u1 = reg["u"]
    ud0, ud1 = u0 + 2, u1 - 1   # u data byte range
    out = []
    for b in range(blob_len // 16):
        s, e = b * 16, b * 16 + 16
        if s >= ud0 and e <= ud1 + 1:
            out.append(b)
    return out

def cf_factor(N, A, lo=1 << 900, hi=1 << 1150, semicap=4_000_000):
    A %= N
    if A == 0: return None
    g = math.gcd(A, N)
    if 1 < g < N: return g
    p_nm2, p_nm1 = 0, 1
    nn, dd = N, A
    for steps in range(4000):
        if dd == 0: break
        a = nn // dd
        p_n = a * p_nm1 + p_nm2
        if 1 < p_n < N and N % p_n == 0:
            return p_n
        # semiconvergents c*p_nm1 + p_nm2, c=1..a
        if p_nm1 > 0 and a >= 1:
            cmin = max(1, (lo - p_nm2 + p_nm1 - 1) // p_nm1)
            cmax = min(a, (hi - p_nm2) // p_nm1)
            if cmax - cmin > semicap: cmin = cmax - semicap
            for c in range(cmin, cmax + 1):
                cand = c * p_nm1 + p_nm2
                if cand > 1 and N % cand == 0:
                    return cand
        p_nm2, p_nm1 = p_nm1, p_n
        nn, dd = dd, nn - a * dd
    return None

def attack_one_connection(trial):
    key = RSA.generate(2048)
    C = Client(key)
    n, e = key.n, key.e
    blocks = safe_u_blocks(key, len(C.blob))
    assert blocks, (blob_layout(key), len(C.blob))
    X0 = random.getrandbits(890) | (1 << 897)
    x = X0 << 128
    ct = long_to_bytes(pow(x, e, n))
    sid_clean = C.login_step2(ct, C.blob, C.mke)
    assert sid_clean == long_to_bytes(x)[:-16], "clean semantics broke"
    fb = random.choice(blocks)
    sid = C.login_step2(ct, C.blob, C.mke, flip_block=fb)
    if sid is None: return "fault broke parse", None
    H = bytes_to_long(sid + b"\x00" * 16)
    A = (H - x) % n
    f = cf_factor(n, A)
    if not f: return "no factor", None
    p, q = (f, n // f)
    ok = (p == key.p and q == key.q) or (p == key.q and q == key.p)
    secret = SHA256.new(long_to_bytes(p) + long_to_bytes(q)).digest()
    dec = unpad(AES.new(secret, AES.MODE_ECB).decrypt(C.enc_flag()), 16)
    return ("OK" if ok else "wrong factor") , dec

if __name__ == "__main__":
    random.seed(11)
    for t in range(3):
        r, dec = attack_one_connection(t)
        print("trial", t, r, dec)
