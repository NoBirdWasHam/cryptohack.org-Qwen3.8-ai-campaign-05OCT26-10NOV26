import sys, os, json, random
from Crypto.PublicKey import RSA
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import pad, unpad
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

def build_client():
    key = RSA.generate(2048)
    master = get_random_bytes(16)
    cm = AES.new(master, AES.MODE_ECB)
    data = b""
    for num in (key.p, key.q, key.d, key.u):
        nb = long_to_bytes(num)
        data += long_to_bytes(len(nb), 2) + nb
    blob = cm.encrypt(pad(data, 16))
    enc = get_random_bytes(16)
    ce = AES.new(enc, AES.MODE_ECB)
    mke = ce.encrypt(master)
    return key, master, blob, mke

def u_regions(key,):
    pass

def blob_layout(key):
    offs = 0
    reg = {}
    for name, num in (("p", key.p), ("q", key.q), ("d", key.d), ("u", key.u)):
        ln = len(long_to_bytes(num))
        reg[name] = (offs, offs + 2 + ln)
        offs += 2 + ln
    total = offs
    padded = (total // 16 + 1) * 16
    return reg, padded

def safe_u_blocks(key):
    reg, padded = blob_layout(key)
    u0, u1 = reg["u"]
    udata0, udata1 = u0 + 2, u1 - 1
    blocks = []
    for b in range(padded // 16):
        s, e = b * 16, b * 16 + 16
        if e <= padded and s >= udata0 and e <= udata1 + 1:
            # also must not include final pad block region start
            if e <= reg["u"][1] + 8 and not (e == padded and s < udata1 + 1):
                blocks.append(b)
    # final block contains pad if u1 < padded; exclude blocks whose range crosses padded end beyond u data
    blocks = [b for b in blocks if (b + 1) * 16 <= udata1 + 1]
    return blocks

def login_step2(SID_enc, share_key_enc, master_key, key, flip_block=None, flipval=b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"):
    blob = bytearray(share_key_enc)
    if flip_block is not None:
        blob[flip_block*16:(flip_block+1)*16] = flipval
    try:
        share_key = unpad(AES.new(master_key, AES.MODE_ECB).decrypt(bytes(blob)), 16)
    except Exception:
        return "ERR"
    index = 0
    els = []
    while index < len(share_key):
        ln = bytes_to_long(share_key[index:index+2]); index += 2
        els.append(bytes_to_long(share_key[index:index+ln])); index += ln
    if len(els) != 4: return "ERR"
    p, q, d, u = els
    ct = bytes_to_long(SID_enc)
    dp, dq = d % (p-1), d % (q-1)
    mp = pow(ct, dp, p); mq = pow(ct, dq, q)
    t = (mq - mp) % q
    h = (t * u) % q
    m = h * p + mp
    return long_to_bytes(m)[:-16]

def coppersmith_linear(C, N, X, m=None, D=None, nroots_max=8):
    # find |L| <= X with p | (C+L) for some prime p >= N^0.5 dividing N
    from fpylll import IntegerMatrix, LLL
    m = m or 4
    D = D or m
    polys = []
    for j in range(m + 1):
        for i in range(D + 1 - j):
            polys.append((i, j))
    def poly_coeffs(i, j):
        # x^i * (x+C)^j * N^(m-j)
        import itertools
        coeff = [0] * (i + j + 1)
        base = [0]*(j+1)
        from math import comb
        for b in range(j+1):
            base[b] = comb(j, b) * pow(C, j - b)
        for b in range(j + 1):
            coeff[i + b] = base[b]
        Nm = pow(N, m - j)
        return [c * Nm for c in coeff]
    maxdeg = max(i + j for (i, j) in polys)
    rows = []
    for (i, j) in polys:
        cf = poly_coeffs(i, j)
        rows.append([cf[k] * pow(X, k) for k in range(maxdeg + 1)])
    M = IntegerMatrix.from_matrix(rows)
    LLL(M)
    import sympy
    cands = set()
    x = sympy.Symbol("x")
    for row in M:
        cf = []
        for k in range(maxdeg + 1):
            v = int(row[k])
            w = pow(X, k)
            if v % w: cf = None; break
            cf.append(v // w)
        if not cf: continue
        poly = sympy.Poly(sympy.Add(*[c * x**k for k, c in enumerate(cf)]), x)
        try:
            for r, mult in poly.nroots().items() if isinstance(poly.nroots(), dict) else []:
                pass
        except Exception:
            pass
        try:
            roots = sympy.nroots(poly, n=30, maxsteps=50)
        except Exception:
            continue
        for rv in roots:
            cr = complex(rv)
            if abs(cr.imag) < 1e-6 and abs(cr.real) <= X:
                L = int(round(cr.real))
                cands.add(L)
        # integer roots from divisors of constant term (fallback for small constant)
        try:
            ct0 = cf[0]
            if 0 < abs(ct0) < 10**12:
                for dv in sympy.divisors(abs(ct0)):
                    for s in (dv, -dv):
                        if poly.eval(s) == 0: cands.add(int(s))
        except Exception:
            pass
    out = []
    for L in cands:
        g = __import__("math").gcd(C + L, N)
        if 1 < g < N and g * (N // g) == N:
            out.append((g, L))
    return out

def attack(n, e, blob, mke, verbose=True):
    X0 = random.getrandbits(880) | (1 << 887)
    x = X0 * (1 << 128)
    ct = pow(x, e, n)
    sid0 = login_step2(long_to_bytes(ct), blob, None, None, None)  # placeholder
    return None

if __name__ == "__main__":
    # local simulation
    key, master, blob, mke = build_client()
    n, e = key.n, key.e
    blocks = safe_u_blocks(key)
    print("safe u blocks:", blocks, "blob len:", len(blob))
    X0 = random.getrandbits(700) | (1 << 711)
    x = X0 * (1 << 128)
    ct = long_to_bytes(pow(x, e, n))
    sid_clean = login_step2(ct, blob, master, key)
    ok_clean = sid_clean == long_to_bytes(x)[:-16]
    print("clean sanity:", ok_clean)
    import math
    for attempt in range(6):
        fb = random.choice(blocks)
        sid = login_step2(ct, blob, master, key, flip_block=fb)
        assert sid != "ERR"
        H = bytes_to_long(sid + b"\x00" * 16)
        C = (H - x) % n
        res = coppersmith_linear(C, n, 1 << 128, m=4, D=4)
        print("attempt", attempt, "block", fb, "roots:", len(res))
        if res:
            p, L = res[0]
            q = n // p
            print("FACTORED ✓ p*q==n:", p * q == n)
            secret = SHA256.new(long_to_bytes(p) + long_to_bytes(q)).digest()
            FLAG = b"FLAG-REDACTED-SEE-FLAGS-MIRROR"
            ctF = AES.new(secret, AES.MODE_ECB).encrypt(pad(FLAG, 16))
            dec = unpad(AES.new(secret, AES.MODE_ECB).decrypt(ctF), 16)
            print("AES roundtrip:", dec)
            break
