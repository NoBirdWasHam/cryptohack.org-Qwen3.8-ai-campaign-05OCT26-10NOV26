import sys, json, math, hashlib, random
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
import sympy
from sympy.ntheory.residue_ntheory import sqrt_mod
from eclib import Curve as CurveFp, point_order, PohligHellman, bsgs as bsgs_fp
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from w4_schoof2 import schoof_t

p = 1331169830894825846283645180581
a = (-35) % p
b = 98
G = (479691812266187139164535778017, 568535594075310466177352868412)
P1 = (1110072782478160369250829345256, 800079550745409318906383650948)
P2 = (1290982289093010194550717223760, 762857612860564354370535420319)
iv = 'eac58c26203c04f68d63dc2c58d79aca'
ct = 'bb9ecbd3662d0671fd222ccb07e27b5500f304e3621a6f8e9c815bc8e4e6ee6ebc718ce9ca115cb4e41acb90dbcabb0d'

print("trace via Schoof...", flush=True)
t0, M = schoof_t(p, a, b)
lim = 2 * math.isqrt(p) + 1
Efp = CurveFp(a, b, p)
tval = None; nE = None
for cand in {t0, t0 - M}:
    for sgn in {cand, -cand}:
        n = p + 1 - sgn
        if n <= 0: continue
        ok = True
        for _ in range(2):
            while True:
                x = random.randrange(1, p)
                y = sqrt_mod((x*x*x + a*x + b) % p, p)
                if y: break
            if Efp.mul((x, int(y)), n) is not None: ok = False; break
        if ok:
            tval = sgn; nE = n
            break
    if tval is not None: break
if tval is None:
    # extended candidate set (M borderline vs Hasse)
    lim = 2 * math.isqrt(p) + 1
    for k in range(-4, 5):
        cand = t0 + k * M
        if abs(cand) > lim: continue
        for sgn in {cand, -cand}:
            n = p + 1 - sgn
            if n <= 0: continue
            ok = True
            for _ in range(2):
                while True:
                    x = random.randrange(1, p)
                    y = sqrt_mod((x*x*x + a*x + b) % p, p)
                    if y: break
                if Efp.mul((x, int(y)), n) is not None: ok = False; break
            if ok:
                tval = sgn; nE = n
                break
        if tval is not None: break
assert tval is not None, "no trace candidate verified"
print("t =", tval, "#E =", nE, flush=True)

fac_n = sympy.factorint(nE)
print("#E factored:", fac_n, flush=True)
ordG = point_order(Efp, G, {q: e for q, e in fac_n.items()})
big = max(ordG.bit_length(), 1)
facs = sympy.factorint(ordG)
print("ordG =", ordG, facs, flush=True)

def decrypt(Sx):
    key = hashlib.sha1(str(Sx).encode('ascii')).digest()[:16]
    pt = unpad(AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct)), 16)
    return pt.decode()

if max(facs) <= 10**10:
    n_a = PohligHellman(Efp, G, P1, ordG, {q: 0 for q in facs} if False else facs)
    assert Efp.mul(G, n_a) == P1
else:
    print("order has big factors -> move to F_p^2", flush=True)
    # F_{p^2} = F_p[w]/(w^2 = z)
    z = 2
    while pow(z, (p - 1) // 2, p) != p - 1: z += 1
    class F2:
        __slots__ = ('a', 'b')
        def __init__(self, a, b=0):
            self.a = a % p; self.b = b % p
        def __add__(o2, o):
            return F2(o2.a + o.a, o2.b + o.b)
        def __sub__(o2, o):
            return F2(o2.a - o.a, o2.b - o.b)
        def __mul__(o2, o):
            return F2(o2.a*o.a + z*o2.b*o.b, o2.a*o.b + o2.b*o.a)
        def __eq__(self, o):
            return self.a == o.a and self.b == o.b
        def __hash__(self):
            return hash((self.a, self.b))
        def inv(self):
            nrm = (self.a*self.a - z*self.b*self.b) % p
            c = pow(nrm, -1, p)
            return F2(self.a*c, -self.b*c)
        def neg(self):
            return F2(-self.a, -self.b)
    def toF2(x, y):
        return (F2(x), F2(y))
    class Curve2:
        def __init__(self, a, b):
            self.a = F2(a); self.b = F2(b)
        def on(self, P):
            if P is None: return True
            x, y = P
            return (y*y - (x*x*x + self.a*x + self.b)) == F2(0)
        def inv(self, P):
            return None if P is None else (P[0], P[1].neg())
        def add(self, P, Q):
            if P is None: return Q
            if Q is None: return P
            x1, y1 = P; x2, y2 = Q
            if x1 == x2:
                if (y1 + y2.neg()) == F2(0): return None
                lam = (x1*x1*F2(3) + self.a) * (y1*F2(2)).inv()
            else:
                lam = (y2 - y1) * (x2 - x1).inv()
            x3 = lam*lam - x1 - x2
            return (x3, lam*(x1 - x3) - y1)
        def mul(self, P, n):
            if P is None or n == 0: return None
            if n < 0: return self.mul(self.inv(P), -n)
            R = None; Q = P
            while n:
                if n & 1: R = self.add(R, Q)
                Q = self.add(Q, Q); n >>= 1
            return R
    E2 = Curve2(a, b)
    G2 = toF2(*G); P12 = toF2(*P1); P22 = toF2(*P2)
    ntil = p + 1 + tval
    N2 = ordG * ntil
    facN = sympy.factorint(N2)
    print("p+1+t =", ntil, facN, flush=True)
    # order of G in E(F_p2)
    o2 = N2
    for q in facN:
        while o2 % q == 0 and E2.mul(G2, o2 // q) is None:
            o2 //= q
    fac_o2 = sympy.factorint(o2)
    print("ord_{p2}(G) =", o2, fac_o2, flush=True)
    assert max(fac_o2) <= 10**10, "still too big for PH: %d" % max(fac_o2)
    n_a = PohligHellman(E2, G2, P12, o2, fac_o2)
    assert E2.mul(G2, n_a) == P12, "PH over F_p2 failed"
S = Efp.mul(P2, n_a % ordG if 'ordG' in dir() else n_a)
assert S is not None and Efp.on(S)
flag = decrypt(S[0])
print("n_a =", n_a)
print("MOVING FLAG:", flag)
json.dump({'n_a': str(n_a), 'flag': flag}, open(r'~/AppData/Local/hermes/cache/scratch/w4_moving.json', 'w'))
