import random

# ---------- Fp2, p = 3 mod 4 ----------
class F2:
    def __init__(self, p): self.p = p
    def c(self, a, b=0): return (a % self.p, b % self.p)
    def add(F, o1, o2): return ((o1[0]+o2[0]) % F.p, (o1[1]+o2[1]) % F.p)
    def sub(F, o1, o2): return ((o1[0]-o2[0]) % F.p, (o1[1]-o2[1]) % F.p)
    def mul(F, o1, o2): return ((o1[0]*o2[0]-o1[1]*o2[1]) % F.p, (o1[0]*o2[1]+o1[1]*o2[0]) % F.p)
    def sm(F, o1, k): return (o1[0]*k % F.p, o1[1]*k % F.p)
    def inv(F, o1):
        n = (o1[0]*o1[0] + o1[1]*o1[1]) % F.p
        ni = pow(n, F.p-2, F.p)
        return (o1[0]*ni % F.p, (-o1[1])*ni % F.p)
    def sq(F, o1): return F.mul(o1, o1)
    def pow(F, o1, e):
        r = (1, 0); b = o1
        while e:
            if e & 1: r = F.mul(r, b)
            b = F.mul(b, b); e >>= 1
        return r
    def sqrt(F, o1):
        # p = 3 mod 4. Solve (a+bi)^2 = (c0,c1).
        p = F.p
        c0, c1 = o1
        if o1 == (0, 0): return (0, 0)
        if c1 == 0:
            # c0 in Fp: sqrt if QR, else pure-imaginary
            if pow(c0 % p, (p-1)//2, p) == 1:
                a = pow(c0, (p+1)//4, p)
                return (a, 0)
            else:
                b = pow((-c0) % p, (p+1)//4, p)
                return (0, b)
        n = (c0*c0 + c1*c1) % p          # norm
        s = pow(n, (p+1)//4, p)           # sqrt of norm (norm is square iff ... need ±s; exactly one of c0±s is QR)
        if (n * (s*s % p)) % p != n % p and s != 0:
            pass
        inv2 = (p + 1) // 2
        for cand in ((c0 + s) % p, (c0 - s) % p):
            if cand % p == 0: continue
            if pow(cand, (p-1)//2, p) == 1:
                a = pow(cand, (p+1)//4, p)
                b = c1 * pow(2*a % p, p-2, p) % p
                r = (a % p, b % p)
                assert F.mul(r, r) == o1, "sqrt failed"
                return r
        raise ValueError("not square")

# ---------- E: y^2 = x^3 + x over Fp2 ----------
class EC:
    def __init__(self, p):
        self.f = F2(p); self.p = p
    def rhs(self, x):
        f = self.f
        return f.add(f.mul(f.sq(x), x), x)
    def on(self, Pt):
        if Pt is None: return True
        x, y = Pt
        return self.f.sq(y) == self.rhs(x)
    def add(self, A, B):
        f = self.f
        if A is None: return B
        if B is None: return A
        x1, y1 = A; x2, y2 = B
        if x1 == x2:
            if f.add(y1, y2) == (0, 0): return None
            m = f.mul(f.add(f.sm(f.sq(x1), 3), (1, 0)), f.inv(f.add(y1, y1)))
        else:
            m = f.mul(f.sub(y2, y1), f.inv(f.sub(x2, x1)))
        x3 = f.sub(f.sub(f.sq(m), x1), x2)
        y3 = f.sub(f.mul(m, f.sub(x1, x3)), y1)
        return (x3, y3)
    def mul(self, k, A):
        R = None
        while k:
            if k & 1: R = self.add(R, A)
            A = self.add(A, A); k >>= 1
        return R
    def rand(self):
        while True:
            x = (random.randrange(self.p), random.randrange(self.p))
            try: y = self.f.sqrt(self.rhs(x))
            except (AssertionError, ValueError): continue
            return (x, y)

def velu_bruteforce(ec, K, l, seed=1):
    """Ground-truth: phi via sum formula; verify; interpolate codomain; fit coefficient sums."""
    f = ec.f
    random.seed(seed)
    G = [K]
    for i in range(1, l):
        G.append(ec.add(G[-1], K))
    assert G[l-1] is None and G[l-2] is not None, "order"
    Gstar = G[:l-1]
    assert len(Gstar) == l - 1
    def phi(Pt):
        if Pt is None: return None
        x, y = Pt
        sx = sy = (0, 0)
        for R in Gstar:
            S = ec.add(Pt, R)
            if S is None: return 'KERNEL'
            sx = f.add(sx, f.sub(S[0], R[0]))
            sy = f.add(sy, f.sub(S[1], R[1]))
        return (f.add(x, sx), f.add(y, sy))
    A, B = ec.rand(), ec.rand()
    ok_hom = ec.add(phi(A), phi(B)) == phi(ec.add(A, B))
    ok_ker = phi(K) == 'KERNEL'
    imgs = []
    T = A
    guard = 0
    while len(imgs) < 6 and guard < 200:
        pT = phi(T)
        if pT != 'KERNEL': imgs.append(pT)
        T = ec.add(T, B); guard += 1
    def solve3(M, b):
        n = 3
        Aa = [row[:] + [b[i]] for i, row in enumerate(M)]
        for c in range(n):
            piv = next(r for r in range(c, n) if Aa[r][c] != (0, 0))
            Aa[c], Aa[piv] = Aa[piv], Aa[c]
            ic = f.inv(Aa[c][c])
            Aa[c] = [f.mul(x, ic) for x in Aa[c]]
            for r in range(n):
                if r != c and Aa[r][c] != (0, 0):
                    fa = Aa[r][c]
                    Aa[r] = [f.sub(x, f.mul(fa, y)) for x, y in zip(Aa[r], Aa[c])]
        return [Aa[i][3] for i in range(n)]
    M = [[f.sq(u), u, (1, 0)] for (u, v) in imgs[:3]]
    b = [f.sub(f.sq(v), f.mul(f.sq(u), u)) for (u, v) in imgs[:3]]
    a2p, a4p, a6p = solve3(M, b)
    ok_curve = all(f.sq(v) == f.add(f.mul(f.sq(u), u), f.add(f.mul(a2p, f.sq(u)), f.add(f.mul(a4p, u), a6p)))
                   for (u, v) in imgs[3:])
    xs = [R[0] for R in Gstar]
    def sumk(k):
        acc = (0, 0)
        for x in xs:
            v = (1, 0)
            for _ in range(k): v = f.mul(v, x)
            acc = f.add(acc, v)
        return acc
    s = {k: sumk(k) for k in (1, 2, 3, 4, 5, 6)}
    t = f.add(f.sm(s[3], 2), s[1])              # sum 2x^3 + x   (a4=1)
    w = f.add(f.sm(s[4], 3), f.sm(s[2], 12))    # sum 3x^4 + 12x^2
    cand_a2 = f.sm(t, 5)
    cand_a4 = f.add((1, 0), f.sm(f.add(f.sm(f.sq(t), 3), w), 5))
    ok_a2 = cand_a2 == a2p
    ok_a4 = cand_a4 == a4p
    rem = f.sub(a6p, f.sm(f.add(f.sm(f.sq(t), 3), w), 5))
    ureq = f.sm(rem, pow(7, ec.p-2, ec.p))
    guesses = {
        "x6+5x4": f.add(s[6], f.sm(s[4], 5)),
        "x6+5x4+5x2": f.add(f.add(s[6], f.sm(s[4], 5)), f.sm(s[2], 5)),
        "x6+10x4": f.add(s[6], f.sm(s[4], 10)),
        "x6": s[6],
        "x6+5x4+2x2?": f.add(f.add(s[6], f.sm(s[4], 5)), f.sm(s[2], 2)),
    }
    hit = [k for k, v in guesses.items() if v == ureq]
    print(f"P={ec.p} l={l}: hom={ok_hom} ker={ok_ker} curve={ok_curve} a2'={ok_a2} a4'={ok_a4} u-hits={hit}")
    return hit

random.seed(7)
cases = []
for l in (5, 7, 13, 17, 19, 37):
    # find prime p = -1 mod 4l, small
    q = 4*l
    while True:
        cand = q - 1
        if all(cand % d for d in range(2, int(cand**0.5)+1)) and cand > 2*l:
            cases.append((cand, l)); break
        q += 4*l
allhit = True
for (p, l) in cases:
    if l > 60: continue
    ec = EC(p)
    K = None
    while True:
        R = ec.rand()
        Kc = ec.mul((p + 1) // l, R)
        if Kc is not None and ec.mul(l, Kc) is None:
            K = Kc; break
    try:
        hits = velu_bruteforce(ec, K, l)
        allhit = allhit and ("x6+5x4+5x2" in hits or "x6+5x4" in hits)
    except Exception as e:
        print("ERR", p, l, repr(e)); allhit = False
print("ALL:", allhit)
