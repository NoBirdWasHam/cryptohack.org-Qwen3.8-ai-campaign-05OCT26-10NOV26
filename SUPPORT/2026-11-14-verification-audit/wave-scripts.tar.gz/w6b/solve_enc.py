#!/usr/bin/env python3
import socket, json, base64, codecs

HOST, PORT = "socket.cryptohack.org", 13377

def decode(typ, enc):
    if typ == "base64":
        return base64.b64decode(enc).decode()
    if typ == "hex":
        return bytes.fromhex(enc).decode()
    if typ == "rot13":
        return codecs.decode(enc, "rot_13")
    if typ == "bigint":
        n = int(enc, 16)
        return n.to_bytes((n.bit_length() + 7) // 8, "big").decode()
    if typ == "utf-8":
        return "".join(chr(b) for b in enc)
    raise ValueError(typ)

s = socket.create_connection((HOST, PORT), timeout=20)
buf = b""
def recvobj():
    global buf
    while True:
        nl = buf.find(b"\n")
        if nl != -1:
            line, buf = buf[:nl], buf[nl+1:]
            if line.strip():
                return json.loads(line)
            continue
        c = s.recv(65536)
        if not c:
            raise EOFError(buf)
        buf += c

def sendobj(o):
    s.sendall((json.dumps(o) + "\n").encode())

flag = None
levels = 0
while True:
    obj = recvobj()
    if "flag" in obj:
        flag = obj["flag"]
        break
    if "error" in obj:
        print("SERVER ERROR at level", levels, obj)
        break
    if "type" not in obj:
        print("UNEXPECTED:", obj)
        break
    levels += 1
    dec = decode(obj["type"], obj["encoded"])
    sendobj({"decoded": dec})
    if levels % 20 == 0:
        print("passed", levels)
print("levels passed:", levels)
print("FLAG:", flag)
s.close()
