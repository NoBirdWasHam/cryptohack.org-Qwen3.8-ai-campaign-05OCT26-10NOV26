#!/usr/bin/env python3
"""Let's Decrypt Again (cryptohack 13394) solver."""
import socket, json, hashlib, random, re, math
from Crypto.Util.number import long_to_bytes, bytes_to_long, isPrime

HOST, PORT = "socket.cryptohack.org", 13394

def factor_small(n):
    f = {}
    d = 2
    while d*d <= n:
        while n % d == 0:
            f[d] = f.get(d,0)+1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1: f[n] = f.get(n,0)+1
    return f

def _crt(pairs):
    N = math.prod(m for _, m in pairs)
    r = 0
    for a, m in pairs:
        Mi = N//m
        r += a*Mi*pow(Mi, -1, m)
    return r % N

class DLPQk:
    """DLP in (Z/q^k)* assuming g is a generator."""
    def __init__(self, g, q, k):
        self.q, self.k = q, k
        self.n = q**k
        self.g = g % self.n
        self.order = (q-1) * q**(k-1)
        self.G = pow(self.g, q**(k-1), self.n)          # order q-1
        self.fq = factor_small(q-1)
        self.g2 = pow(self.g, q-1, self.n)              # order q^{k-1}
        self.gamma = pow(self.g2, q**(k-2), self.n)     # order q
        self.m = int(q**0.5)+1
        self.tbl = {}
        cur = 1
        for j in range(self.m):
            self.tbl.setdefault(cur, j)
            cur = cur*self.gamma % self.n
        self.ginv_m = pow(self.gamma, q - (self.m % q), self.n)  # gamma^-m

    def _dlog_prime(self, gi, hi, r):
        """dlog base gi (order r) of hi, r prime (small)"""
        if hi == 1: return 0
        mm = int(r**0.5)+1
        tb = {}
        c = 1
        for j in range(mm):
            tb.setdefault(c, j)
            c = c*gi % self.n
        gim = pow(gi, r - (mm % r), self.n) if mm % r else gi  # gi^-mm
        if mm % r:
            gim = pow(gi, r - (mm % r), self.n)
        else:
            gim = 1
        c = hi
        for i in range(mm+1):
            if c in tb:
                x = i*mm + tb[c]
                assert pow(gi, x, self.n) == hi
                return x
            c = c*gim % self.n
        raise ValueError("element not in subgroup")

    def _dlog_ppow(self, gi, hi, rr, r):
        """dlog base gi of hi, gi of order r^e"""
        e = 0
        t = rr
        while t > 1:
            t //= r
            e += 1
        x = 0
        gtop = pow(gi, rr//r, self.n)   # order r
        for i in range(e):
            w = pow(hi * pow(gi, -x, self.n), rr // r**(i+1), self.n)
            d = self._dlog_prime(gtop, w, r)
            x += d * r**i
        assert pow(gi, x, self.n) == hi
        return x

    def _bsgs_gamma(self, h):
        if h == 1: return 0
        c = h
        for i in range(self.m+2):
            if c in self.tbl:
                x = i*self.m + self.tbl[c]
                assert pow(self.gamma, x, self.n) == h
                return x
            c = c*self.ginv_m % self.n
        raise ValueError("gamma dlog fail")

    def log(self, h):
        h %= self.n
        # part 1: e mod (q-1)
        H = pow(h, self.q**(self.k-1), self.n)
        mods = []
        for r, e in self.fq.items():
            rr = r**e
            gi = pow(self.G, (self.q-1)//rr, self.n)
            hi = pow(H, (self.q-1)//rr, self.n)
            mods.append((self._dlog_ppow(gi, hi, rr, r), rr))
        e0 = _crt(mods)
        # part 2: q-part
        h2 = h * pow(self.g, -e0, self.n) % self.n
        t = 0
        c = self.k - 1
        for i in range(c):
            w = pow(h2 * pow(self.g2, -t, self.n), self.q**(c-1-i), self.n)
            t += self._bsgs_gamma(w) * self.q**i
        e = (e0 + (self.q-1)*t) % self.order
        assert pow(self.g, e, self.n) == h, "DLP verification failed"
        return e

# ---------------- digest models ----------------
def enc_A(msg): return b"\x00\x01\x00" + msg
def enc_D(msg): return (b"\x00\x01\x00" + msg)[-96:]
def enc_H(msg):
    h = hashlib.sha256(msg).digest()
    return b"\x00\x01" + b"\xff"*(96-3-32) + b"\x00" + h
def enc_G(msg):
    di = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(msg).digest()
    return b"\x00\x01" + b"\xff"*(96-3-51) + b"\x00" + di
def enc_G1(msg):
    di = bytes.fromhex("3021300906052b0e03021a05000414") + hashlib.sha1(msg).digest()
    return b"\x00\x01" + b"\xff"*(96-3-35) + b"\x00" + di
def enc_H1(msg):
    return b"\x00\x01" + b"\xff"*(96-3-20) + b"\x00" + hashlib.sha1(msg).digest()
MODELS = [("G1", enc_G1), ("H1", enc_H1), ("A", enc_A), ("H", enc_H), ("G", enc_G)]

# ---------------- btc check (from server code) ----------------
BTC_PAT = re.compile("^Please send all my money to ([1-9A-HJ-NP-Za-km-z]+)$")
def btc_check(msg):
    alpha = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    m = BTC_PAT.match(msg)
    if not m: return False
    addr = m.group(1)
    raw = b"\0" * (len(addr) - len(addr.lstrip(alpha[0])))
    res = 0
    for ch in addr:
        res = res*58 + alpha.index(ch)
    raw += long_to_bytes(res)
    if len(raw) != 25 or raw[0] not in (0,5): return False
    return raw[-4:] == hashlib.sha256(hashlib.sha256(raw[:-4]).digest()).digest()[:4]

CORES = [
    "This is a test for a fake signature.",
    "My name is Robin and I own CryptoHack.org",
    "Please send all my money to 3EovkHLK5kkAbE8Kpe53mkEbyQGjyf8ECw",
]
assert btc_check(CORES[2]), "bad BTC address"
assert re.match(r"^This is a test(.*)for a fake signature.$", CORES[0])
assert re.match(r"^My name is ([a-zA-Z\s]+) and I own CryptoHack.org$", CORES[1])

# ---------------- smooth-prime search ----------------
def is_smooth(n, bound):
    p = 2
    while p <= bound and n > 1:
        while n % p == 0:
            n //= p
        p += 1
    return n == 1

def good_q(SIG, q):
    if not isPrime(q) or SIG % q == 0: return False
    if not is_smooth(q-1, 997): return False
    if any(pow(SIG, (q-1)//r, q) == 1 for r in factor_small(q-1)): return False
    return pow(SIG, q-1, q*q) != 1

def find_q(SIG):
    if good_q(SIG, 2010103):
        return 2010103
    q = 2**20 | 1
    while q < 2**26:
        if good_q(SIG, q):
            return q
        q += 2
    raise RuntimeError("no q found")

# ---------------- socket ----------------
def connect():
    s = socket.create_connection((HOST, PORT), timeout=25)
    state = {"buf": b""}
    def _fill():
        c = s.recv(65536)
        if not c: raise EOFError(state["buf"])
        state["buf"] += c
    while b"\n" not in state["buf"]:
        _fill()
    nl = state["buf"].find(b"\n")
    greet = state["buf"][:nl]
    state["buf"] = state["buf"][nl+1:]
    def recvobj():
        while True:
            nl = state["buf"].find(b"\n")
            if nl != -1:
                line, state["buf"] = state["buf"][:nl], state["buf"][nl+1:]
                if line.strip():
                    return json.loads(line)
                continue
            _fill()
    def sendobj(o):
        s.sendall((json.dumps(o)+"\n").encode())
    return s, recvobj, sendobj, greet

def xor(a, b): return bytes(x ^ y for x, y in zip(a, b))

def get_SIG():
    s, recvobj, sendobj, greet = connect()
    sendobj({"option": "get_signature"})
    r = recvobj()
    s.close()
    return int(r["N"],16), int(r["E"],16), int(r["signature"],16)

def attempt(SIG, q, k, model):
    n = q**k
    dlp = DLPQk(SIG, q, k)
    s, recvobj, sendobj, greet = connect()
    try:
        sendobj({"option": "get_signature"})
        r = recvobj()
        assert int(r["signature"],16) == SIG
        sendobj({"option": "set_pubkey", "pubkey": hex(n)})
        r = recvobj()
        if "suffix" not in r:
            return None, r
        suffix = r["suffix"]
        shares = []
        for i, core in enumerate(CORES):
            msg = core + suffix
            D = bytes_to_long(model(msg.encode()))
            if D >= n or D % q == 0:
                return "SIZE", (i, D.bit_length(), n.bit_length(), D % q)
            e = dlp.log(D)
            sendobj({"option": "claim", "msg": msg, "index": i, "e": hex(e)})
            r = recvobj()
            if "secret" not in r:
                return None, r
            shares.append(bytes.fromhex(r["secret"]))
        return xor(xor(shares[0], shares[1]), shares[2]), None
    finally:
        s.close()

def main():
    N, E, SIG = get_SIG()
    print("SIG bits:", SIG.bit_length(), "N bits:", N.bit_length(), "E:", hex(E))
    q = find_q(SIG)
    k = 1
    while q**k < 2**1070: k += 1
    print("q =", q, "k =", k, "n bits =", (q**k).bit_length())
    dlp = DLPQk(SIG, q, k)
    x0 = random.randrange(1, dlp.order)
    assert dlp.log(pow(SIG, x0, q**k)) == x0, "DLP self-test failed"
    print("DLP self-test OK; q-1 factors:", factor_small(q-1))
    for name, model in MODELS:
        print("trying digest model", name, flush=True)
        try:
            flag, err = attempt(SIG, q, k, model)
        except Exception as ex:
            print("  model", name, "exception:", repr(ex))
            continue
        if flag:
            try:
                print("FLAG:", flag.decode())
            except UnicodeDecodeError:
                print("RAW FLAG BYTES:", flag.hex())
            return
        print("  model", name, "failed:", err)
    print("ALL MODELS FAILED")

if __name__ == "__main__":
    main()
