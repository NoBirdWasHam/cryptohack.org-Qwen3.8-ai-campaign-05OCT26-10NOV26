#!/usr/bin/env python3
"""Let's Decrypt Again (cryptohack 13394) solver.

Attack: server accepts forged "signatures" by checking bytes_to_long(pkcs1_encode(msg)) == pow(SIG, e, n)
with n, e attacker-supplied. Choose n = q^k (q small smooth prime, SIG a generator of (Z/q^k)*),
then e = log_SIG(digest) via Pohlig-Hellman. The random suffix appended to msgs is fine because
digest model (00 01 00 || msg) is linear-ish and we just solve DLP for whatever digest we compute.
"""
import socket, json, hashlib, random, re, sys
from Crypto.Util.number import long_to_bytes, bytes_to_long, isPrime

HOST, PORT = "socket.cryptohack.org", 13394
BIT = 768

# ---------------- PH DLP in (Z/q^k)^* assuming g is a generator ----------------
def factor_small(n):
    f = {}
    d = 2
    while d*d <= n:
        while n % d == 0:
            f[d] = f.get(d,0)+1
            n //= d
        d += 1 if d==2 else 2
    if n > 1: f[n] = f.get(n,0)+1
    return f

def bsgs(g, h, order, p, table=None):
    """solve g^x = h mod p, g of prime order `order`; optional prebuilt table"""
    if table is None:
        table = {}
        cur = 1
        m = int(order**0.5)+1
        for j in range(m):
            table.setdefault(cur, j)
            cur = cur*g % p
        # baby-step table; giant steps:
        gm = pow(g, -(m if hasattr(pow,'__call__') else 0), p) if False else pow(g, p-1-m, p)  # g^-m
        cur = h
        for i in range(m+1):
            if cur in table:
                x = i*m + table[cur]
                assert pow(g, x, p) == h
                return x
            cur = cur*gm % p
        raise ValueError("dlog not found")
    return None

class DLPQk:
    """DLP in (Z/q^k)* with generator g."""
    def __init__(self, g, q, k):
        self.g, self.q, self.k = g % (q**k), q, k
        self.n = q**k
        self.order = (q-1) * q**(k-1)
        # prime-to-q part: subgroup generator G = g^{q^{k-1}}, order q-1
        self.G = pow(g, q**(k-1), self.n)
        self.fq = factor_small(q-1)
        # baby-step table for the q-part gamma
        self.g2 = pow(g, q-1, self.n)                      # order q^{k-1}
        self.gamma = pow(self.g2, q**(k-2), self.n)         # order q
        m = int(q**0.5)+1
        self.m = m
        self.tbl = {}
        cur = 1
        for j in range(m):
            self.tbl.setdefault(cur, j)
            cur = cur*self.gamma % self.n
        self.ginv_m = pow(self.gamma, self.order//q - m if False else (q-1-m+ q//q*0), self.n)  # placeholder
        self.ginv_m = pow(self.gamma, q-1-m, self.n)        # gamma^{q-m} = gamma^{-m}

    def _dlog_small_prime_order(self, g, h, r):
        """dlog in subgroup of prime order r (mod self.n)"""
        cur = h
        m = self.tbl  # only valid for gamma base; use bsgs otherwise
        # generic small bsgs
        mm = int(r**0.5)+1
        tb = {}
        c = 1
        for j in range(mm):
            tb.setdefault(c, j)
            c = c*g % self.n
        gm = pow(g, r-mm, self.n)
        c = h
        for i in range(mm+1):
            if c in tb:
                return i*mm + tb[c]
            c = c*gm % self.n
        raise ValueError("no dlog (element not in subgroup)")

    def log(self, h):
        h %= self.n
        assert pow(self.g, self.order, self.n) == 1
        e0 = 0
        # part 1: e mod (q-1)
        H = pow(h, self.q**(self.k-1), self.n)
        for r, _ in self.fq.items():
            gi = pow(self.G, (self.q-1)//r, self.n)
            hi = pow(H, (self.q-1)//r, self.n)
            x = self._dlog_small_prime_order(gi, hi, r)
            e0 = crt(e0 % r, x)  # combine later properly
        # proper CRT over prime factors of q-1 (distinct primes; exponents: use full prime powers)
        mods = []
        for r, e in self.fq.items():
            rr = r**e
            gi = pow(self.G, (self.q-1)//rr, self.n)
            hi = pow(H, (self.q-1)//rr, self.n)
            x = self._dlog_ppow(gi, hi, rr, r)
            mods.append((x, rr))
        e0 = _crt(mods)
        # part 2: q-part
        h2 = h * pow(self.g, -e0, self.n) % self.n
        t = 0
        c = self.k - 1
        base = self.g2
        for i in range(c):
            w = pow(h2 * pow(base, -t, self.n), self.q**(c-1-i), self.n)
            # w = gamma^{t_i}
            ti = self._bsgs_gamma(w)
            t += ti * self.q**i
        e = (e0 + (self.q-1)*t) % self.order
        assert pow(self.g, e, self.n) == h, "DLP verification failed"
        return e

    def _dlog_ppow(self, g, h, rr, r):
        """dlog mod n where g has order r^e (r small prime, e small) — PH lift"""
        e = factor_small(rr)[r]
        x = 0
        gr = pow(g, rr//r, self.n)
        cur_h = h
        for i in range(e):
            hi = pow(cur_h, rr//r**(i+1) if False else rr//r, self.n)
            # standard lift
            w = pow(h * pow(g, -x, self.n), rr // r**(i+1), self.n)
            gi = pow(g, rr // r**(i+1), self.n)   # order r
            d = self._dlog_small_prime_order(gi, w, r) if w != 1 else 0
            x += d * r**i
        assert pow(g, x, self.n) == h
        return x

    def _bsgs_gamma(self, h):
        c = h
        for i in range(self.m+2):
            if c in self.tbl:
                x = i*self.m + self.tbl[c]
                assert pow(self.gamma, x, self.n) == h
                return x
            c = c*self.ginv_m % self.n
        raise ValueError("gamma dlog fail")

def _crt(pairs):
    from math import prod
    N = prod(m for _, m in pairs)
    r = 0
    for a, m in pairs:
        Mi = N//m
        r += a*Mi*pow(Mi, -1, m)
    return r % N

# ---------------- digest models ----------------
def enc_A(msg): return b"\x00\x01\x00" + msg
def enc_D(msg): return (b"\x00\x01\x00" + msg)[-96:]
def enc_H(msg):
    h = hashlib.sha256(msg).digest()
    return b"\x00\x01" + b"\xff"*(96-3-32) + b"\x00" + h
def enc_G(msg):
    di = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(msg).digest()
    return b"\x00\x01" + b"\xff"*(96-3-51) + b"\x00" + di
MODELS = [("A", enc_A), ("D", enc_D), ("H", enc_H), ("G", enc_G)]

# ---------------- btc check (copied from server) ----------------
BTC_PAT = re.compile("^Please send all my money to ([1-9A-HJ-NP-Za-km-z]+)$")
def btc_check(msg):
    alpha = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    addr = BTC_PAT.match(msg)
    if not addr: return False
    addr = addr.group(1)
    raw = b"\0" * (len(addr) - len(addr.lstrip(alpha[0])))
    res = 0
    for c in addr:
        res *= 58
        res += alpha.index(c)
    raw += long_to_bytes(res)
    if len(raw) != 25: return False
    if raw[0] not in [0,5]: return False
    return raw[-4:] == hashlib.sha256(hashlib.sha256(raw[:-4]).digest()).digest()[:4]

CORES = [
    "This is a test for a fake signature.",
    "My name is Robin and I own CryptoHack.org",
    "Please send all my money to 3EovkHLK5kkAbE8Kpe53mkEbyQGjyf8ECw",
]
assert btc_check(CORES[2]), "bad BTC address!"
assert re.match(r"^This is a test(.*)for a fake signature.$", CORES[0])
assert re.match(r"^My name is ([a-zA-Z\s]+) and I own CryptoHack.org$", CORES[1])

# ---------------- q search ----------------
def find_smooth_prime(SIG, lo=2**21, hi=2**23, max_fac=997):
    """prime q, q-1 smooth, SIG primitive root mod q and SIG^{q-1} != 1 mod q^2"""
    small_primes = []
    for n in range(2, max_fac+1):
        if all(n % p for p in small_primes): small_primes.append(n)
    q = lo | 1
    rng = range(q, hi, 2)
    for cand in rng:
        if not isPrime(cand): continue
        rem = cand - 1
        ok = True
        for p in small_primes:
            while rem % p == 0: rem //= p
            if rem == 1: break
        if rem != 1: continue
        if SIG % cand == 0: continue
        # primitive root mod q?
        f = factor_small(cand-1)
        isgen = all(pow(SIG, (cand-1)//r, cand) != 1 for r in f)
        if not isgen: continue
        if pow(SIG, cand-1, cand*cand) == 1: continue
        return cand
    raise RuntimeError("no smooth prime found")

# ---------------- socket helpers ----------------
def connect():
    s = socket.create_connection((HOST, PORT), timeout=25)
    buf = b""
    def recvobj():
        nonlocal buf
        while True:
            nl = buf.find(b"\n")
            if nl != -1:
                line, buf = buf[:nl], buf[nl+1:]
                if line.strip():
                    return json.loads(line)
                continue
            c = s.recv(65536)
            if not c: raise EOFError(buf)
            buf += c
    def sendobj(o):
        s.sendall((json.dumps(o)+"\n").encode())
    greet = None
    while b"\n" not in buf:
        c = s.recv(65536)
        if not c: break
        buf += c
    # greet is plain text (not JSON): take up to first newline, keep rest in buf
    nl = buf.find(b"\n")
    greet, buf = buf[:nl], buf[nl+1:]
    return s, recvobj, sendobj

def xor(a,b): return bytes(x^y for x,y in zip(a,b))

def attempt(SIG, q, k, model):
    n = q**k
    dlp = DLPQk(SIG, q, k)
    s, recvobj, sendobj = connect()
    try:
        sendobj({"option": "get_signature"})
        r = recvobj()
        assert int(r["signature"], 16) == SIG
        sendobj({"option": "set_pubkey", "pubkey": hex(n)})
        r = recvobj()
        if "suffix" not in r: return None, r
        suffix = r["suffix"]
        shares = []
        for i, core in enumerate(CORES):
            msg = core + suffix
            dig = model(msg.encode())
            D = bytes_to_long(dig)
            if D >= n or D % q == 0:
                return "SIZE", (i, D.bit_length(), n.bit_length())
            e = dlp.log(D % n)
            sendobj({"option": "claim", "msg": msg, "index": i, "e": hex(e)})
            r = recvobj()
            if "secret" not in r:
                return None, r
            shares.append(bytes.fromhex(r["secret"]))
        flag = xor(xor(shares[0], shares[1]), shares[2])
        return flag, None
    finally:
        s.close()

def main():
    s, recvobj, sendobj = connect()
    sendobj({"option": "get_signature"})
    r = recvobj()
    s.close()
    N = int(r["N"],16); E = int(r["E"],16); SIG = int(r["signature"],16)
    print("SIG bits:", SIG.bit_length(), "N bits:", N.bit_length(), "E:", hex(E))
    q = find_smooth_prime(SIG)
    # k such that q^k > max digest (~ 130 bytes = 1040 bits) plus margin
    k = 1 + (1100*1000)//q.bit_length()//1000 + 2
    while q**k < 2**1060: k += 1
    print("q =", q, "k =", k, "n bits =", (q**k).bit_length())
    # sanity: DLP self-test
    dlp = DLPQk(SIG, q, k)
    x0 = random.randrange(1, dlp.order)
    h0 = pow(SIG, x0, q**k)
    assert dlp.log(h0) == x0, "DLP self-test failed"
    print("DLP self-test OK")
    for name, model in MODELS:
        print("trying digest model", name)
        try:
            flag, err = attempt(SIG, q, k, model)
        except Exception as ex:
            print("  model", name, "exhausted:", ex)
            continue
        if flag:
            print("FLAG:", flag)
            return
        print("  model", name, "failed:", err)
    print("ALL MODELS FAILED")

if __name__ == "__main__":
    main()
