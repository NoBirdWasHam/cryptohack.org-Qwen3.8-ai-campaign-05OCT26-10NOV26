"""Clean Schoof: #E for y^2 = x^3 + a x + b over F_p."""
import sys, json, random, math
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')

def trim(A):
    while A and A[-1] == 0: A.pop()
    return A

class PF:  # prime field arithmetic p fixed
    def __init__(self, p):
        self.p = p
    def add(self, A, B):
        n = max(len(A), len(B))
        return trim([((A[i] if i < len(A) else 0) + (B[i] if i < len(B) else 0)) % self.p for i in range(n)])
    def sub(self, A, B):
        n = max(len(A), len(B))
        return trim([((A[i] if i < len(A) else 0) - (B[i] if i < len(B) else 0)) % self.p for i in range(n)])
    def mul(self, A, B):
        if not A or not B: return []
        R = [0] * (len(A) + len(B) - 1)
        for i, ai in enumerate(A):
            if ai:
                for j, bj in enumerate(B):
                    R[i + j] = (R[i + j] + ai * bj) % self.p
        return trim(R)
    def divmod(self, A, M):
        p = self.p
        R = A[:]; Q = [0] * max(0, len(A) - len(M) + 1)
        Mi = pow(M[-1], -1, p)
        while len(R) >= len(M) and R:
            if R[-1] == 0: R.pop(); continue
            d = len(R) - len(M)
            c = R[-1] * Mi % p
            Q[d] = (Q[d] + c) % p
            for i, m in enumerate(M):
                R[d + i] = (R[d + i] - c * m) % p
            R.pop()
        return trim(Q), trim(R)
    def mod(self, A, M):
        return self.divmod(A, M)[1]
    def powmod(self, A, e, M):
        R = [1]; B = self.mod(A, M)
        while e:
            if e & 1: R = self.mod(self.mul(R, B), M)
            B = self.mod(self.mul(B, B), M); e >>= 1
        return R
    def invmod(self, A, M):
        p = self.p
        r0, r1 = trim(A[:]), M[:]
        s0, s1 = [1], [0]
        while r1:
            q, r2 = self.divmod(r0, r1)
            r0, r1 = r1, r2
            s0, s1 = s1, self.sub(s0, self.mul(q, s1))
        if len(r0) != 1:
            raise ZeroDivisionError('not invertible')
        c = pow(r0[0], -1, p)
        return self.mul(s0, [c])

class Quad:
    """elements u0 + u1*y over F_p[x]/psi with y^2 = g(x)."""
    def __init__(self, pf, psi, g, a):
        self.pf = pf; self.psi = psi; self.g = g; self.a = a
    def m(self, A): return self.pf.mod(A, self.psi)
    def mul(self, U, V):
        pf = self.pf
        u0, u1 = U; v0, v1 = V
        c0 = pf.add(self.pf.mul(u0, v0), self.pf.mul(self.pf.mul(u1, v1), self.g))
        c1 = pf.add(self.pf.mul(u0, v1), self.pf.mul(u1, v0))
        return (self.m(c0), self.m(c1))
    def add(self, U, V):
        pf = self.pf
        return (self.m(pf.add(U[0], V[0])), self.m(pf.add(U[1], V[1])))
    def sub(self, U, V):
        pf = self.pf
        return (self.m(pf.sub(U[0], V[0])), self.m(pf.sub(U[1], V[1])))
    def neg(self, U):
        return (self.m([]), self.m([])) if U is None else self.sub((self.m([]), self.m([])), U)
    def inv(self, U):
        u0, u1 = U
        nrm = self.m(self.pf.sub(self.pf.mul(u0, u0), self.pf.mul(self.pf.mul(u1, u1), self.g)))
        ni = self.pf.invmod(nrm, self.psi)
        return (self.m(self.pf.mul(ni, u0)), self.m(self.pf.sub([], self.pf.mul(ni, u1))))

ZERO = (None, None)
def EQ(Qd, P, Q):
    if P is None or Q is None: return P is Q
    return P[0] == Q[0] and P[1] == Q[1]

def cadd(Qd, P, R):
    if P is None: return R
    if R is None: return P
    x1, y1 = P; x2, y2 = R
    if x1 == x2:
        if EQ(Qd, Qd.add(y1, Qd.neg(y2)), (Qd.m([]), Qd.m([]))):
            # 2P
            three = (Qd.m([3]), Qd.m([]))
            num = Qd.add(Qd.mul(three, Qd.mul(x1, x1)), (Qd.m([Qd.a]), Qd.m([])))
            den = Qd.mul((Qd.m([2]), Qd.m([])), y1)
            dinv = Qd.inv(den)
            lam = Qd.mul(num, dinv)
        else:
            return None
    else:
        num = Qd.sub(y2, y1)
        den = Qd.sub(x2, x1)
        dinv = Qd.inv(den)
        lam = Qd.mul(num, dinv)
    x3 = Qd.sub(Qd.sub(Qd.mul(lam, lam), x1), x2)
    y3 = Qd.sub(Qd.mul(lam, Qd.sub(x1, x3)), y1)
    return (x3, y3)

def cmul(Qd, n, P):
    R = None; Q = P
    while n:
        if n & 1: R = cadd(Qd, R, Q)
        Q = cadd(Qd, Q, Q); n >>= 1
    return R

def division_poly(l, pf, g):
    """psi_l for odd l as x-only poly list."""
    ps = {1: ([1], []), 2: ([], [2]), 3: (g and None) or None}
    # psi3 = 3x^4 + 6a x^2 + 12b x - a^2 ; derive: g = x^3 + a x + b
    a = None
    def fullmul(P, Q):
        p = pf.p
        c0 = pf.add(pf.mul(P[0], Q[0]), pf.mul(pf.mul(P[1], Q[1]), g))
        c1 = pf.add(pf.mul(P[0], Q[1]), pf.mul(pf.mul(P[1], Q[0]), []))
        return (c1 if False else c0, c1)
    def cube(B): return fullmul(fullmul(B, B), B)
    def get(k):
        if k in ps: return ps[k]
        if k % 2 == 1:
            m = (k - 1) // 2
            A = get(m + 2); B = cube(get(m))
            C = get(m - 1); D = cube(get(m + 1))
            ps[k] = (pf.sub(pf.add(A[0], []) if False else A[0], D[0]) if False else
                     fullmul(A, B))
            v1 = fullmul(A, B)
            v2 = fullmul(C, D)
            ps[k] = (pf.sub(v1[0], v2[0]), pf.sub(v1[1], v2[1]))
            return ps[k]
        else:
            m = k // 2
            s1 = fullmul(get(m + 2), fullmul(get(m - 1), get(m - 1)))
            s2 = fullmul(get(m - 2), fullmul(get(m + 1), get(m + 1))) if m >= 2 else (([], []), (0,))
            inner = (pf.sub(s1[0], s2[0]), pf.sub(s1[1], s2[1]))
            prod = fullmul(get(m), inner)
            # divide by 2y: prod = (0, W) -> q = W / (2g)
            assert prod[0] == [] or prod[0] == None or prod[0] == []
            two_g = [(2 * x) % pf.p for x in g]
            q, r = pf.divmod(prod[1], two_g)
            if r != []:
                raise RuntimeError('psi even division not exact')
            ps[k] = ([], q)
            return ps[k]
    # fix psi3
    return ps

def psi_odd(l, pf, a, b):
    """compute psi_l (odd l) directly, x-only."""
    p = pf.p
    g = trim([b % p, a % p, 0, 1])
    ps = {0: ([], []), 1: ([1], []), 2: ([], [2]),
          3: (trim([(-a*a) % p, (12*b) % p, (6*a) % p, 0, 3]), []),
          4: ([], trim([(4*c) % p for c in [(-8*b*b - a**3), (-4*a*b), (-5*a*a), (20*b), (5*a), 0, 1]]))}
    def fullmul(P, Q):
        c0 = pf.add(pf.mul(P[0], Q[0]), pf.mul(pf.mul(P[1], Q[1]), g))
        c1 = pf.add(pf.mul(P[0], Q[1]), pf.mul(P[1], Q[0]))
        return (c0, c1)
    def div2y(P):
        """exact division of pair P by 2y"""
        u0, u1 = P
        if u0 == [] or u0 is None:
            # (W y)/(2y) = W/2
            assert all(x % 2 == 0 for x in u1) or True
            return (trim([(x * pow(2, -1, p)) % p for x in u1]), [])
        # x-only: U/(2y) = U*y/(2y^2) = (0, U/(2g))
        q, r = pf.divmod(u0, [(2 * c) % p for c in g])
        assert r == [], 'inexact x-only div by 2g'
        return ([], [(x * pow(2, -1, p)) % p for x in q]) if False else ([], q)
    def cube(B): return fullmul(fullmul(B, B), B)
    def get(k):
        if k in ps: return ps[k]
        if k % 2 == 1:
            m = (k - 1) // 2
            v1 = fullmul(get(m + 2), cube(get(m)))
            v2 = fullmul(get(m - 1), cube(get(m + 1)))
            ps[k] = (pf.sub(v1[0], v2[0]), pf.sub(v1[1], v2[1]))
        else:
            m = k // 2
            s1 = fullmul(get(m + 2), fullmul(get(m - 1), get(m - 1)))
            s2 = fullmul(get(m - 2), fullmul(get(m + 1), get(m + 1)))
            inner = (pf.sub(s1[0], s2[0]), pf.sub(s1[1], s2[1]))
            ps[k] = div2y(fullmul(get(m), inner))
        return ps[k]
    r = get(l)
    assert r[1] == [], "odd psi must be x-only"
    return r[0], g

def t_mod_l(l, pf, a, b, g):
    psi, _ = psi_odd(l, pf, a, b)
    p = pf.p
    # factor psi over F_p; run the check on each field component.
    # NOTE: galoistools uses dense low->high coefficient lists.
    import sympy
    from sympy.polys.galoistools import gf_factor
    from sympy.polys.domains import ZZ
    fac_list = gf_factor(psi[::-1], p, ZZ)   # galoistools: high-degree first
    factors = []
    _coef, fs = fac_list
    for fh, mult in fs:
        lo = [c % p for c in reversed(fh)]   # back to low->high
        factors.append(trim(lo))
    assert factors, "factorization failed"
    def check(f):
        Qd = Quad(pf, f, g, a)
        x = (pf.mod([0, 1], f), [])   # canonical rep mod f (matters for deg f == 1)
        y = ([], [1])
        xp = pf.powmod([0, 1], p, f)
        gp = pf.powmod(g, (p - 1) // 2, f)
        phi = ((xp, []), ([], gp))
        xp2 = pf.powmod([0, 1], p * p, f)
        gp2 = pf.powmod(g, (p * p - 1) // 2, f)
        phi2 = ((xp2, []), ([], gp2))
        lhs = cadd(Qd, phi2, cmul(Qd, p % l, (x, y)))
        acc = None
        for r in range(l):
            if (acc is None and lhs is None) or (acc is not None and lhs is not None and acc[0] == lhs[0] and acc[1] == lhs[1]):
                return r
            acc = cadd(Qd, acc, phi)
        raise RuntimeError('t mod %d not found (component deg %d)' % (l, len(f) - 1))
    rr = None
    for f in factors:
        r = check(f)
        if rr is None:
            rr = r
        elif r != rr:
            # ambiguous components (possible if f divides discriminant-ish) -> prefer majority
            raise RuntimeError('component disagreement l=%d: %s vs %s' % (l, rr, r))
    return rr

def schoof_t(p, a, b):
    pf = PF(p)
    g = trim([b % p, a % p, 0, 1])
    mods = [2]
    xp = pf.mod(pf.powmod([0, 1], p, g), g)
    from functools import reduce
    def gcd(A, B):
        while B:
            _, B = B, pf.mod(A, B) if False else pf.divmod(A, B)[1]
            A = B_ = None
        return A
    # gcd of g and (x^p - x)
    A = g[:]; B = pf.sub(pf.mod(pf.powmod([0, 1], p, g), g), [0, 1])
    while B:
        A, B = B, pf.divmod(A, B)[1]
    if len(A) > 1:
        A = pf.mul(A, [pow(A[-1], -1, p)])
    t2 = 0 if len(A) > 1 else 1
    res = [t2]
    for l in [3, 5, 7, 11, 13, 17, 19, 23, 29, 31]:
        res.append(t_mod_l(l, pf, a, b, g))
        mods.append(l)
        print("  t mod", l, "=", res[-1], flush=True)
    t = 0; M = 1
    for m, r in zip(mods, res):
        t = (t + M * ((r - t) * pow(M, -1, m) % m)) % (M * m); M *= m
    return t, M

if __name__ == '__main__':
    p = 1331169830894825846283645180581
    a = (-35) % p; b = 98
    print("computing trace...")
    t0, M = schoof_t(p, a, b)
    lim = 2 * math.isqrt(p) + 1
    from eclib import Curve
    E = Curve(a, b, p)
    from sympy.ntheory.residue_ntheory import sqrt_mod
    for cand in {t0, t0 - M}:
        for sgn in (cand, -cand):
            n = p + 1 - sgn
            if n < 0: continue
            ok = True
            for _ in range(2):
                while True:
                    x = random.randrange(1, p)
                    y = sqrt_mod((x*x*x + a*x + b) % p, p)
                    if y: break
                P = (x, int(y))
                if E.mul(P, n) is not None: ok = False; break
            if ok:
                print("FOUND: t =", sgn, "#E =", n)
                json.dump({'t': sgn, 'nE': n}, open(r'~/AppData/Local/hermes/cache/scratch/w4_schoof.json', 'w'))
                sys.exit(0)
    print("no candidate verified?!")
