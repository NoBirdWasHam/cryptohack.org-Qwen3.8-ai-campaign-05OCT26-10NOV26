import socket, json, sys, hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

INJ = sys.argv[1] if len(sys.argv) > 1 else '0x0'
host, port = 'socket.cryptohack.org', int(sys.argv[2]) if len(sys.argv) > 2 else 13371
logf = sys.argv[3] if len(sys.argv) > 3 else 'pi_flow.log'
s = socket.create_connection((host, port), timeout=20)
s.settimeout(20)
buf = b''
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout: out.append('<TIMEOUT buf=%r>' % buf[:120]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return out

def find(lines, label):
    for l in lines:
        if label in l:
            body = l.split(label, 1)[1].strip()
            j = body.find('{'); k = body.rfind('}')
            if j >= 0 and k > j:
                try: return json.loads(body[j:k+1])
                except Exception: return None
    return None

log = []
msgs = {}
lines = rd(); log += lines
amsg = find(lines, 'Intercepted from Alice:')
if amsg is None:
    print("no alice msg", lines); sys.exit(1)
log += ['>>> relay alice->bob', json.dumps(amsg)]
s.sendall((json.dumps(amsg) + '\n').encode())
p_hex, g_hex = amsg['p'], amsg['g']
r = rd(); log += r
bmsg = find(r, 'Intercepted from Bob:')
print("BOB MSG:", bmsg)
if bmsg and 'B' in bmsg:
    inj = dict(bmsg); inj['B'] = INJ
    log += ['>>> inject B=' + INJ, json.dumps(inj)]
    s.sendall((json.dumps(inj) + '\n').encode())
else:
    # maybe next prompt was Send to Alice with the flag already; try injecting toward alice anyway
    inj = json.dumps({"B": INJ})
    s.sendall((inj + '\n').encode())
    log += ['>>> raw inject ' + inj]
final = []
for i in range(5):
    rr = rd(); final += rr
    if any('<EOF>' in l for l in rr): break
log += final
open(logf, 'w').write('\n'.join(log))
print('\n'.join(final))
# try to decrypt with s = int(INJ,16)**anything mod p -> equals INJ value for 0/1
cand_iv = cand_ct = None
txt = '\n'.join(final)
import re
miv = re.search(r'"iv": "([0-9a-f]+)"', txt); mct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt)
if miv and mct:
    ivb, ctb = bytes.fromhex(miv.group(1)), bytes.fromhex(mct.group(1))
    for sv in [int(INJ, 16), 0, 1]:
        key = hashlib.sha1(str(sv).encode('ascii')).digest()[:16]
        pt = AES.new(key, AES.MODE_CBC, ivb).decrypt(ctb)
        try:
            flag = unpad(pt, 16).decode('ascii')
            print("DECRYPTED s=%d ->" % sv, flag)
        except Exception:
            pass
s.close()
