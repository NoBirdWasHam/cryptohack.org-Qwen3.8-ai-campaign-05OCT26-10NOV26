import sys, os, subprocess
SC = r"~/AppData/Local/hermes/cache/scratch"
sys.path.insert(0, SC)
from btl_driver import setup, run_scan, jmont
import struct

p = 92935740571
l = 23233935143
K = ((6312697112, 11428792286), (30552079595, 78608501229))

# setup reuses rand kernel; here kernel is GIVEN: replicate A, x1 computation
src = open(SC + "/btl_velu_check.py").read()
ns = {}; exec(src.split("random.seed(7)")[0], ns)
F2 = ns['F2']
f = F2(p)
sqrt2 = f.sqrt((2, 0))
A = f.sm(f.inv(sqrt2), 3)
usq = f.sqrt(f.sm(f.inv((2, 0)), -1))
inv3 = pow(3, p-2, p)
A3 = f.sm(A, inv3)
x1 = f.sub(f.mul(usq, K[0]), A3)
y2m = f.mul(f.mul(usq, usq), f.mul(usq, f.sq(K[1])))
rhs = f.mul(x1, f.add(f.add(f.sq(x1), f.mul(A, x1)), (1, 0)))
assert y2m == rhs, "x1 invalid"
print("A =", A, " x1 =", x1, flush=True)

N = 16
Sx, Si, P0, H1, Hm1 = run_scan(os.path.join(SC, "scan_big.exe"), p, l, A, x1, N)
sigma = f.sub(Sx, Si)
ApCH = f.mul(P0, f.sub(A, f.sm(sigma, 3)))
jCH, _ = jmont(f, ApCH)
base = f.mul(f.sub(A, (2, 0)), f.inv(f.add(A, (2, 0))))
dl = f.pow(base, l)
ratio = f.mul(H1, f.inv(Hm1))
dval = f.mul(dl, f.mul(f.sq(ratio), f.sq(ratio)))
ApED = f.mul((2, 0), f.mul(f.add((1, 0), dval), f.inv(f.sub((1, 0), dval))))
jED, _ = jmont(f, ApED)
print("A'CH =", ApCH)
print("A'ED =", ApED)
print("jCH =", jCH)
print("jED =", jED)
print("MATCH:", jCH == jED)
a, b = jCH
print("FLAG_FMT:", f"{b}*i + {a}")
