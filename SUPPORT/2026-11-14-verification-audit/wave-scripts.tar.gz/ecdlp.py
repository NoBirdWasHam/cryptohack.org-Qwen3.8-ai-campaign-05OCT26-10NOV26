"""Clean PH + rho helpers."""
from math import isqrt
import random

def bsgs(E, G, H, r):
    """x with H=[x]G, G of order r (r prime or small prime power)."""
    m = isqrt(r) + 1
    table = {}
    cur = None
    for j in range(m):
        if cur is not None and cur not in table: table[cur] = j
        cur = E.add(cur, G)
    Gm = E.mul(G, m)
    cur = H
    for i in range(m + 1):
        if cur in table:
            x = i*m + table[cur]
            if E.mul(G, x % r) == H: return x % r
        cur = E.add(cur, Gm)
    cur = H
    for i in range(m + 1):
        if cur in table:
            x = i*m - table[cur]
            if E.mul(G, x % r) == H: return x % r
        cur = E.add(cur, Gm)
    raise RuntimeError("bsgs failed")

def crt_pair(a, m, b, n):
    return (a + m * ((b - a) * pow(m, -1, n) % n)) % (m*n)

def ph(E, G, H, ordG, fac, small_lim=2**30):
    """DLP via Pohlig-Hellman; works for prime-power factors. fac=dict q->v_q(ordG)."""
    x, mod = 0, 1
    for q in sorted(fac):
        e = 0; t = ordG
        while t % q == 0: t //= q; e += 1
        pe = q**e
        Gq = E.mul(G, ordG // pe)   # order pe
        Hq = E.mul(H, ordG // pe)
        if pe <= small_lim or q > small_lim:
            if q > small_lim:
                # single digit, prime order q large -> caller must supply rho result
                raise RuntimeError("large prime factor needs rho path (q=%d)" % q)
        xi = 0
        gq = E.mul(Gq, pe // q)     # order q
        for k in range(e):
            rem = E.add(Hq, E.inv(E.mul(Gq, xi)))
            hk = E.mul(rem, pe // (q**(k+1)))
            dk = bsgs(E, gq, hk, q)
            xi += dk * (q**k)
        x = crt_pair(x, mod, xi, pe)
        mod *= pe
    return x % mod

def rho(E, G, H, r, seed=0, max_steps=None, dp_bits=24):
    """Pollard lambda, distinguished points, memory-safe. H=[x]G, ord(G)=r prime."""
    rng = random.Random(seed)
    # walk: X = a*G + b*H ; partition by X.x % 3 (or hash)
    def step(X, a, b):
        x, y = X
        i = (x & 3) if r.bit_length() else 0
        i = x % 3 if False else int.from_bytes(x.to_bytes(48,'little'),'little') % 3 if False else (x * 11400714819323198485 % (2**61-1)) % 3
        if i == 0:
            return E.add(X, G), (a + 1) % r, b
        if i == 1:
            return E.add(X, H), a, (b + 1) % r
        X2 = E.add(G, H)
        return E.add(X, X2), a, b
    mask = (1 << dp_bits) - 1
    trials = 0
    while True:
        trials += 1
        X = E.add(G, H)
        a, b = 1, 1
        seen = {X: (a, b)}
        steps = 0
        while True:
            (X, a, b) = step(X, a, b)
            steps += 1
            if X is not None and X[0] & mask == 0:
                if X in seen:
                    (a0, b0) = seen[X]
                    if (b - b0) % r:
                        x = (a0 - a) * pow(b - b0, -1, r) % r
                        if E.mul(G, x) == H: return x
                    break  # collision but b==b0, restart
                seen[X] = (a, b)
            if max_steps and steps > max_steps: break
        if trials % 50 == 0: print("rho trials:", trials, "seen", len(seen), flush=True)
