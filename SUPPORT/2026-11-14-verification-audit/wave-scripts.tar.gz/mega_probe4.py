import socket, json, sys, binascii

def stream(sock, fp):
    buf = b""
    while True:
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except Exception:
                fp.write("RAWLINE: " + line[:3000].decode(errors="replace") + "\n")
        chunk = sock.recv(65536)
        if not chunk:
            fp.write("EOF\n"); return
        buf += chunk

def session(fp, tag, do_queries):
    s = socket.create_connection(("socket.cryptohack.org", 13409), timeout=25)
    st = stream(s, fp)
    material = None
    # first JSON line should contain material
    for msg in st:
        fp.write(f"[{tag}] MSG KEYS: {sorted(msg.keys())}\n")
        if "share_key_pub" in msg:
            material = msg; break
        if "error" in msg:
            fp.write(f"[{tag}] ERR early: {msg}\n"); s.close(); return None
    if material is None:
        s.close(); return None
    n, e = material["share_key_pub"]
    fp.write(f"[{tag}] n bits={n.bit_length()} e={e} n_low={n & ((1<<64)-1)}\n")
    fp.write(f"[{tag}] authhash={material.get('auth_key_hashed')}\n")
    fp.write(f"[{tag}] nhex_head={format(n,'x')[:80]}...\n")
    fp.write(f"[{tag}] nhex_tail=...{format(n,'x')[-80:]}\n")
    out = {}
    for action_payload in do_queries(material):
        s.sendall((json.dumps(action_payload) + "\n").encode())
        resp = next(st, None)
        fp.write(f"[{tag}] REQ {action_payload.get('action')} -> {str(resp)[:400]}\n")
        if action_payload.get("action") == "get_encrypted_flag" and resp and "encrypted_flag" in resp:
            out["enc_flag"] = resp["encrypted_flag"]
        if action_payload.get("action") == "wait_login" and resp and "auth_key_hashed" in resp:
            out["sid_resp_pending"] = True
    s.close()
    return n, e, out, material

def queries_probe(mat):
    # 1) free flag blob
    yield {"action": "get_encrypted_flag"}
    # login cycle: wait_login then replay-encrypt query ct=2
    yield {"action": "wait_login"}
    yield {"action": "send_challenge", "SID_enc": "02",
           "share_key_enc": mat["share_key_enc"], "master_key_enc": mat["master_key_enc"]}

def queries_probe2(mat):
    yield {"action": "wait_login"}
    # ct = 0 -> m = 0 -> SID '' expected
    yield {"action": "send_challenge", "SID_enc": "00",
           "share_key_enc": mat["share_key_enc"], "master_key_enc": mat["master_key_enc"]}
    yield {"action": "wait_login"}
    # ct = n+1 (bytes longer than key): m = 1 -> SID ''
    n, e = mat["share_key_pub"]
    yield {"action": "send_challenge", "SID_enc": format(n + 1, "x").rjust(512, "0"),
           "share_key_enc": mat["share_key_enc"], "master_key_enc": mat["master_key_enc"]}
    yield {"action": "wait_login"}
    # ct = (n+1)^e?? m=1.. use 2^e mod n -> m should be 2 (SID hex = '02'!!)
    ct = pow(2, e, n)
    yield {"action": "send_challenge", "SID_enc": format(ct, "x").rjust(512, "0"),
           "share_key_enc": mat["share_key_enc"], "master_key_enc": mat["master_key_enc"]}

with open(r"~/AppData/Local/hermes/cache/scratch/mega_probe4.log", "w") as fp:
    r1 = session(fp, "s1", queries_probe)
    r2 = session(fp, "s2", queries_probe2)
    if r1 and r2:
        n1, n2 = r1[0], r2[0]
        fp.write(f"n reused across sessions: {n1 == n2}\n")
print("done")
