import socket, json, sys, hashlib, re
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

mode = sys.argv[1]  # 'honest' | 'knownB'
s = socket.create_connection(('socket.cryptohack.org', 13371), timeout=20)
s.settimeout(20)
buf = b''
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout: out.append('<TIMEOUT>'); break
        if not d:
            out.append(buf.decode(errors='replace') + '<EOF>'); buf = b''; break
        buf += d
    return out
def find(lines, label):
    for l in lines:
        if label in l:
            body = l.split(label, 1)[1]
            j = body.find('{'); k = body.rfind('}')
            try: return json.loads(body[j:k+1])
            except Exception: return None
    return None
lines = rd()
amsg = find(lines, 'Intercepted from Alice:')
p = int(amsg['p'], 16); g = int(amsg['g'], 16); A = int(amsg['A'], 16)
log = list(lines)
b_to_send = dict(amsg)
if mode == 'knownB':
    # we play Bob: pick b ourselves, send B=g^b
    b = 0x1337beefcafe
    B = pow(g, b, p)
    b_to_send = {"B": "0x%x" % B}
    s.sendall((json.dumps(amsg) + '\n').encode())
    r = rd(); log += r
    s.sendall((json.dumps(b_to_send) + '\n').encode())
    sA = pow(int(b_to_send['B'], 16), 1, p)  # placeholder
    sA = pow(B, 1, p)
    # Alice's s = B^a (a unknown) ; Bob's s = A^b known
    cands = {'A^b(mine)': pow(A, b, p), 'B^a?no': 0}
    # also our own view: g^ab = A^b
else:
    s.sendall((json.dumps(amsg) + '\n').encode())
    r = rd(); log += r
    bmsg = find(r, 'Intercepted from Bob:')
    s.sendall((json.dumps(bmsg) + '\n').encode())
    cands = {}
fin = []
for i in range(5):
    rr = rd(); fin += rr
    if any('<EOF>' in l for l in rr): break
log += fin
open('pi_%s_flow.log' % mode, 'w').write('\n'.join(log))
txt = '\n'.join(fin)
print(txt[:700])
miv = re.search(r'"iv": "([0-9a-f]+)"', txt); mct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt)
if miv and mct and cands:
    ivb, ctb = bytes.fromhex(miv.group(1)), bytes.fromhex(mct.group(1))
    for nm, sv in cands.items():
        key = hashlib.sha1(str(sv).encode('ascii')).digest()[:16]
        pt = AES.new(key, AES.MODE_CBC, ivb).decrypt(ctb)
        try:
            print("DECRYPTED %s -> %s" % (nm, unpad(pt,16).decode('ascii')))
        except Exception:
            print("cand %s miss" % nm)
s.close()
