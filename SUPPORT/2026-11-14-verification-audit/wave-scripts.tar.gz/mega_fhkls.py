# FHKLS / Boneh-Venkatesan small roots of linear poly mod hidden factor
import math
from fpylll import IntegerMatrix, LLL
import sympy

def small_roots_linear(C, N, X, tau_bits=None, beta=0.5, verbose=False):
    """Return list of L with |L| <= X and gcd(C+L, N) nontrivial prime factor.
    C+L = z*p, |z| < N/X, p ~ N^beta."""
    if tau_bits is None:
        tau_bits = 300
    tau = 1 << tau_bits
    x = sympy.Symbol("x")
    # polynomials: p1 = x + C ; p2 = N ; p3 = tau*x
    best = None
    for mu in range(2, 60):
        for nu in range(4, 90):
            rows = []
            # (N*x - mu*tau)*(N^nu - tau^(nu-1)*(x+C)) = -mu*tau*N^nu + N^(nu+1)*x + tau^nu*(x+C) - mu*tau^(nu-1)*(x+C)*x
            r = [0, 0, 0]
            r[0] = mu * tau * pow(N, nu)
            a1 = pow(N, nu + 1) + pow(tau, nu) - mu * tau * C
            a2 = -mu * tau * pow(tau, nu - 1)
            r[1] = a1 * X
            r[2] = a2 * X * X
            rows.append(r)
            # b1 = tau^nu*(x+C) - N^nu*(x+C)
            rows.append([pow(tau, nu) * C - pow(N, nu) * C, (pow(tau, nu) - pow(N, nu)) * X, 0])
            # b2 = tau^(nu-1) * x * (x + C)
            rows.append([0, pow(tau, nu - 1) * C * X, pow(tau, nu - 1) * X * X])
            M = IntegerMatrix.from_matrix(rows)
            LLL(M)
            row = M[0]
            v0, v1, v2 = (int(row[0]), int(row[1]), int(row[2]))
            if v2 % (X * X) or v1 % X:
                continue
            a = v2 // (X * X)
            b = v1 // X
            c = v0
            if a == 0:
                continue
            disc = b * b - 4 * a * c
            if disc < 0:
                continue
            s = math.isqrt(disc)
            for cand in ((-b + s) // (2 * a), (-b - s) // (2 * a)):
                if abs(cand) <= X:
                    g = math.gcd(C + cand, N)
                    if 1 < g < N and g * (N // g) == N:
                        if verbose: print(f"hit mu={mu} nu={nu} L={cand}")
                        return (g, cand)
            # also try near-miss roots via sympy nroots for safety
    return None

if __name__ == "__main__":
    from Crypto.PublicKey import RSA
    import random
    random.seed(2)
    for trial in range(2):
        k = RSA.generate(1024)
        p = k.p
        z = random.randrange(1 << 500, 1 << 505)
        L = random.randrange(-(1 << 127), 1 << 127)
        A = z * p - L
        g = small_roots_linear(-A, k.n, 1 << 128, tau_bits=320)
        print("trial", trial, "result gcd:", g[0] if g else None, "match p:", g and (g[0] == p or k.n // g[0] == p))
