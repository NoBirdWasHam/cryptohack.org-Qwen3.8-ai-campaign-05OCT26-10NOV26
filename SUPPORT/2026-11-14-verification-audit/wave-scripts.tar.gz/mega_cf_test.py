# Continued-fraction factor recovery: p | (A + L), |L| < 2^128, p ~ sqrt(N)
import math, random

def cf_factor(N, A, X=1 << 130, denom_cap=1 << 1200):
    """Find factor of N given A with |A - z*p| < X for some prime p|N, p ~ N^0.5.
    Uses CF of N/A (~ q/z): convergents' NUMERATORS are candidates for q."""
    if A < 0: A += N
    if A == 0: return None
    g = math.gcd(A, N)
    if 1 < g < N: return g
    # continued fraction of N/A as rational: num=N, den=A
    # convergents p_{-2}=0,p_{-1}=1 ; q_{-2}=1,q_{-1}=0
    p_nm2, p_nm1 = 0, 1
    q_nm2, q_nm1 = 1, 0
    nn, dd = N, A
    steps = 0
    cands = []
    while dd != 0 and steps < 5000:
        a = nn // dd
        # semiconvergents between previous (p_nm1/q_nm1) and next
        p_n = a * p_nm1 + p_nm2
        q_n = a * q_nm1 + q_nm2
        # semiconvergent candidates: c*p_nm1 + p_nm2 for c in 1..a (approximants), numerator = q-cand for q of N
        # enumerate semiconvergents with numerator >= N^0.45 (candidate for q)
        lo_num = 1 << 950
        hi_num = 1 << 1150
        # numerators of semiconvergents: c*p_nm1 + p_nm2, c=1..a (a may be huge; last a huge typically)
        if p_nm1 >= lo_num or True:
            if a > 0 and p_nm1 != 0:
                cmin = max(1, (lo_num - p_nm2 + p_nm1 - 1) // p_nm1)
                cmax = min(a, (hi_num - p_nm2) // p_nm1 if p_nm1 > 0 else 0)
                if cmax - cmin > 2000000:
                    cmin = max(cmin, cmax - 2000000)
                if cmax >= cmin:
                    for c in range(cmin, cmax + 1):
                        cand = c * p_nm1 + p_nm2
                        if cand > 1 and N % cand == 0:
                            return cand
        # full convergent
        if 1 < p_n < N and N % p_n == 0:
            return p_n
        if q_n > denom_cap and p_n > denom_cap:
            pass
        p_nm2, p_nm1 = p_nm1, p_n
        q_nm2, q_nm1 = q_nm1, q_n
        nn, dd = dd, nn - a * dd
        steps += 1
    return None

if __name__ == "__main__":
    from Crypto.PublicKey import RSA
    random.seed(3)
    hits = 0
    for trial in range(3):
        k = RSA.generate(2048)
        p, q = k.p, k.q
        z = random.randrange(1 << 1000, q)
        L = random.randrange(0, 1 << 128)
        A = (z * p - L) % k.n
        f = cf_factor(k.n, A)
        print("trial", trial, "->", "factor found" if f else "NONE", f == p or f == q if f else "")
        hits += 1 if (f == p or f == q) else 0
    print("hits:", hits, "/3")
