import socket, json, time
host, port = 'socket.cryptohack.org', 13371
s = socket.create_connection((host, port), timeout=15)
s.settimeout(10)
buf = b''
def rd():
    global buf
    out = []
    while True:
        if b'\n' in buf:
            ln, buf = buf.split(b'\n', 1); out.append(ln.decode(errors='replace')); continue
        try: d = s.recv(65536)
        except socket.timeout:
            out.append('<TIMEOUT buf=%r>' % buf[:100]); break
        if not d:
            if buf: out.append(buf.decode(errors='replace') + '<EOF>')
            buf = b''; out.append('<EOF>'); break
        buf += d
    return '\n'.join(out)
first = rd()
print("FIRST:", first[:300])
msg = json.loads(first.split('Intercepted from Alice:',1)[1])
p = int(msg['p'],16)
inj = json.dumps({"p": "0x%x" % p, "g": "0x02", "A": "0x0"})
s.sendall((inj + '\n').encode())
print("TO BOB:", inj[:80])
r1 = rd(); print("R1:", r1[:400])
if 'Send to Alice' in r1:
    bob = json.loads(r1.split('Send to Alice:',1)[1].split('<')[0]) if '<' in r1 else json.loads(r1.split('Send to Alice:',1)[1])
    s.sendall((json.dumps(bob)+'\n').encode())
    print("RELAY TO ALICE ok")
    r2 = rd(); print("R2:", r2[:600])
    print("R3:", rd()[:600])
s.close()
