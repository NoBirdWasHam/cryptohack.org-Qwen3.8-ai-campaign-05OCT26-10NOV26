#!/usr/bin/env python3
"""W7A: run lpi_live.py LIVE against socket.cryptohack.org:13430 with raw transcript logging."""
import sys, os, json, time
sys.path.insert(0, r"~/AppData/Local/hermes/cache/scratch/w6e")
import lpi_live

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lpi_live_w7a.raw.log")
_rawf = open(RAW, "a", encoding="utf-8")

_orig_read = lpi_live.Conn.read_line
def logged_read(self, timeout=30):
    line = _orig_read(self, timeout)
    _rawf.write("[RECV %s] %s\n" % (time.strftime("%H:%M:%S"), line)); _rawf.flush()
    return line
lpi_live.Conn.read_line = logged_read

_orig_send = lpi_live.Conn.send_cmd
def logged_send(self, obj):
    _rawf.write("[SEND %s] %s\n" % (time.strftime("%H:%M:%S"), json.dumps(obj))); _rawf.flush()
    r = _orig_send(self, obj)
    return r
lpi_live.Conn.send_cmd = logged_send

if __name__ == "__main__":
    _rawf.write("\n===== w7a live run start %s =====\n" % time.ctime()); _rawf.flush()
    import runpy
    # replicate lpi_live main with result capture
    for trial in range(4):
        try:
            f = lpi_live.attempt(trial)
        except Exception as ex:
            print("EXC", type(ex).__name__, ex, flush=True)
            f = None
        if f:
            flag = f.decode(errors="replace")
            print("FINAL", flag, flush=True)
            open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "lpi_w7a_flag.txt"), "w").write(flag)
            sys.exit(0)
        print("retry", trial, flush=True)
        time.sleep(3)
    sys.exit(1)
