#!/usr/bin/env python3
"""letsproveit attack library (v2, clean).
p-capture: refresh(our seed); the next get_proof's getPrime takes the FIRST candidate
c0 = Random(nonce+seed).getrandbits(1024)|1; if c0 is prime (verified locally with our
own primality test) the server accepts it and no isPrime-RNG-consumption ambiguity
matters for p -> p known exactly, pycryptodome-version-independent.
y = 2^F mod p; Pohlig-Hellman on the smooth part of p-1 (primes <= LPH) gives F mod l^a.
CRT over ~6 proofs -> masked F; unmask with the instance nonce; drop the inserted
nonprintable byte."""
import random, time, math
from Crypto.Util.number import long_to_bytes, bytes_to_long
import flint

LPH = 1 << 34          # max prime for Pohlig-Hellman (BSGS sqrt <= 2^17)
TRIAL_B = 2000000

def sieve(n):
    s = bytearray([1]) * (n+1)
    s[0] = s[1] = 0
    for i in range(2, int(n**0.5)+1):
        if s[i]:
            s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i, v in enumerate(s) if v]

SMALL_PRIMES = sieve(TRIAL_B)

def first_candidate(nonce: bytes, seed: bytes):
    R = random.Random(nonce + seed)
    return R.getrandbits(1024) | 1

def smooth_part_fac(n):
    """factor out primes <= TRIAL_B; return (fac dict, remaining)"""
    fac = {}
    for p in SMALL_PRIMES:
        if p*p > n: break
        while n % p == 0:
            fac[p] = fac.get(p, 0) + 1
            n //= p
    return fac, n

def rho_split(n, max_steps=1<<18):
    """Brent-style Pollard rho with batched gcd; factor up to ~2^34; None on miss."""
    if flint.fmpz(n).is_prime(): return None
    import math as _m
    for c0 in (1, 3, 5):
        x = 2; y = 2; c = c0; d = 1
        prod = 1; steps = 0; saved = None
        while d == 1 and steps < max_steps:
            for _ in range(128):
                x = (x*x + c) % n
                diff = abs(x - y)
                if diff == 0:
                    prod = 0
                else:
                    prod = (prod * diff) % n
                y = (y*y + c) % n
                y = (y*y + c) % n
                steps += 1
            d = _m.gcd(prod, n)
            if d == n:
                # backtracking fallback not kept; treat as miss for this c
                d = 1
                break
        if 1 < d < n:
            return d
    return None

def factor_small_part(n, fac=None):
    """complete factorization restricted to prime factors <= LPH**2ish; returns dict
    of small primes (<= LPH) with exponents; ignores big cofactor."""
    if fac is None: fac = {}
    stack = [n]
    while stack:
        x = stack.pop()
        if x <= 1: continue
        fx = flint.fmpz(x)
        if fx.is_prime():
            if x <= LPH: fac[x] = fac.get(x, 0) + 1
            continue
        d = rho_split(x)
        if d is None:
            continue
        stack.append(d); stack.append(x // d)
    return fac

def order_l_part(g, p, l, a):
    """g has order l^ap dividing l^a; return ap (0 if g==1)."""
    if g % p == 1: return 0
    x = g
    for ap in range(1, a+1):
        x = pow(x, l, p)
        if x == 1:
            return ap
    return None

def bsgs_in_group(g, y, p, order_ub):
    """dlog y = g^d, ord(g) | order_ub, brute BSGS with m=ceil(sqrt(order_ub))."""
    m = math.isqrt(order_ub) + 2
    table = {1: 0}
    cur = 1
    for j in range(1, m):
        cur = cur * g % p
        if cur not in table: table[cur] = j
    gm = pow(g, -m, p)
    gamma = y
    for i in range(0, m):
        if gamma in table:
            d = table[gamma] + i*m
            return d
        gamma = gamma * gm % p
    return None

def ph_prime_power(g, y, p, l, a):
    """ord(g)=l^a exactly; solve y=g^x -> x mod l^a."""
    x = 0
    g1 = pow(g, l**(a-1), p)     # order l
    m = math.isqrt(l) + 2
    table = {1: 0}
    cur = 1
    for j in range(1, m):
        cur = cur * g1 % p
        if cur not in table: table[cur] = j
    g1m = pow(g1, -m, p)
    def dlog_l(h):
        gam = h
        for i in range(0, m):
            if gam in table: return table[gam] + i*m
            gam = gam * g1m % p
        return None
    lk = 1
    for k in range(a):
        h = pow(y * pow(g, -x, p), l**(a-1-k), p)
        d = dlog_l(h)
        if d is None or d >= l:
            if d is not None: d %= l
            else: return None
        x += d * lk
        lk *= l
    return x % (l**a)

def congruences_from_proof(p, y, verbose=False):
    """returns list of (r, mod) with F = dlog_2(y) ≡ r (mod), mod = l^ap | p-1."""
    fac, rem = smooth_part_fac(p - 1)
    if rem > 1:
        fac.update(factor_small_part(rem))
    out = []
    for l, a in fac.items():
        if l > LPH: continue
        e0 = (p - 1) // (l**a)
        g = pow(2, e0, p)
        yy = pow(y, e0, p)
        ap = order_l_part(g, p, l, a)
        if ap is None or ap == 0:
            continue
        x = ph_prime_power(g, yy, p, l, ap)
        if x is None:
            if verbose: print("PH fail", l, ap)
            continue
        # sanity
        if pow(g, x, p) != yy:
            if verbose: print("PH verify fail", l, ap)
            continue
        out.append((x, l**ap))
    return out

def crt(a1, m1, a2, m2):
    g = math.gcd(m1, m2)
    if (a2 - a1) % g: return None
    l = m1 // g * m2
    u = pow(m1 // g, -1, m2 // g)
    t = ((a2 - a1) // g * u) % (m2 // g)
    return (a1 + m1 * t) % l, l

def crt_all(congs):
    a, m = 0, 1
    for (r, mm) in congs:
        t = crt(a, m, r % mm, mm)
        if t is None: return None
        a, m = t
    return a, m

# ---------------- search ----------------
def search_seeds(nonce, need, min_bits=45, tmax=600, score_cap=10**18):
    """find `need` seeds s.t. first candidate is prime and p-1 has smooth part >= 2^min_bits"""
    good = []
    seen = set()
    t0 = time.time()
    s = 0
    while len(good) < need and time.time() - t0 < tmax:
        s += 1
        seed = s.to_bytes(8, "big")
        p = first_candidate(nonce, seed)
        if not flint.fmpz(p).is_prime():
            continue
        fac, rem = smooth_part_fac(p - 1)
        bits = sum((math.log2(l)) * e for l, e in fac.items() if l <= LPH)
        if bits < min_bits - 8:   # cheap reject
            continue
        fac2 = dict((l, e) for l, e in fac.items() if l <= LPH)
        if rem > 1:
            fac2.update(factor_small_part(rem))
            bits = sum(math.log2(l) * e for l, e in fac2.items() if l <= LPH)
        if bits >= min_bits:
            good.append((seed, p, bits))
    return good

# ---------------- unmask ----------------
def unmask(F_bytes, nonce, flaglen=38):
    """F_bytes: 39-byte masked value. returns candidate flag or None"""
    if len(F_bytes) != 39 or not F_bytes.startswith(b"crypto{"):
        return None
    middle = bytes(x ^ n for x, n in zip(F_bytes[7:38], nonce))
    body = F_bytes[:7] + middle + F_bytes[38:]
    # remove exactly one byte so that: len==38, starts FLAG-REDACTED-SEE-FLAGS-MIRROR, all printable
    cands = []
    for i in range(39):
        cand = body[:i] + body[i+1:]
        if len(cand) != flaglen: continue
        if not cand.startswith(b"FLAG-REDACTED-SEE-FLAGS-MIRROR"): continue
        if all(32 <= c < 127 for c in cand):
            cands.append(cand)
    if len(cands) == 1:
        return cands[0]
    if len(cands) > 1:
        return cands
    return None
