# ecb_oracle: ECB byte-at-a-time (flag is secret suffix). bean_counter: frozen CTR counter
# (stup=False => keystream constant) => 16-byte repeating XOR over a PNG; recover KS from
# PNG magic + IHDR length/type, decrypt, save PNG.
import requests, json, time

B = "https://aes.cryptohack.org"
out = {}
S = requests.Session()

def enc_ecb(hexpt):
    last = None
    for _ in range(6):
        try:
            r = S.get(f"{B}/ecb_oracle/encrypt/{hexpt}/", timeout=30)
            r.raise_for_status()
            d = r.json()
            if "ciphertext" not in d:
                raise RuntimeError(d)
            return bytes.fromhex(d["ciphertext"])
        except Exception as e:
            last = e
            time.sleep(2)
    raise last

def bcs():
    lens = {L: len(enc_ecb((b"A" * L).hex())) for L in range(1, 40)}
    total1 = lens[1]                       # = 16*(floor((LF+1)/16)+1)
    jump = next(L for L in range(2, 40) if lens[L] > lens[L - 1])  # LF+L ≡ 0 mod 16 here
    LF = next(x - 1 for x in range(total1 - 16, total1) if (x + jump - 1) % 16 == 0)
    print(f"ecb_oracle: LF={LF} (total1={total1}, jump={jump})")

    known = b""
    while len(known) < LF:
        i = len(known)
        psz = (15 - i) % 16
        if psz == 0:
            psz = 16  # empty prefix 404s on this route; shift target one block right
        P = b"A" * psz
        ct = enc_ecb(P.hex())
        tpos = psz + i                     # byte offset of F[i] in message
        blk = tpos // 16
        actual = ct[blk * 16:(blk + 1) * 16]
        got = None
        for c in range(256):
            Q = b""
            for p in range(blk * 16, blk * 16 + 16):
                if p < psz:
                    Q += b"A"
                elif p == tpos:
                    Q += bytes([c])
                else:
                    Q += known[p - psz:p - psz + 1]
            if len(Q) != 16:
                raise RuntimeError((psz, i, blk))
            if enc_ecb(Q.hex())[:16] == actual:
                got = c
                break
        if got is None:
            raise RuntimeError(f"byte {i} not found")
        known += bytes([got])
        print(i, known)
    flag = known.decode()
    assert flag.startswith("FLAG-REDACTED-SEE-FLAGS-MIRROR"), flag
    return flag

try:
    out["ecb_oracle"] = bcs()
    print("ecb_oracle:", out["ecb_oracle"])
except Exception as e:
    print("ecb FAIL", repr(e))

try:
    r = requests.get(f"{B}/bean_counter/encrypt/", timeout=60)
    r.raise_for_status()
    enc = bytes.fromhex(r.json()["encrypted"])
    magic = bytes([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
    ks = bytearray(16)
    for j in range(8):
        ks[j] = enc[j] ^ magic[j]
    for j, b in enumerate(b"\x00\x00\x00\x0d"):  # IHDR length big-endian = 13
        ks[8 + j] = enc[8 + j] ^ b
    for j, b in enumerate(b"IHDR"):
        ks[12 + j] = enc[12 + j] ^ b
    ks = bytes(ks)
    dec = bytes(c ^ ks[i % 16] for i, c in enumerate(enc))
    print("bean png sig ok:", dec[:8] == magic, "IHDR ok:", dec[12:16] == b"IHDR", "chunk2@33:", dec[33:41])
    open("bean_flag_dec.png", "wb").write(dec)
    out["bean_counter_png"] = "bean_flag_dec.png"
except Exception as e:
    print("bean FAIL", repr(e))

json.dump(out, open("res_hard.json", "w"), indent=2)
print("done")
