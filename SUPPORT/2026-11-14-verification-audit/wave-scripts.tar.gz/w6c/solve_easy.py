# Solvers: block_cipher_starter, ecbcbcwtf, symmetry, flipping_cookie, lazy_cbc, passwords_as_keys
import requests, hashlib
from Crypto.Cipher import AES

B = "https://aes.cryptohack.org"
out = {}

def get(url, **kw):
    r = requests.get(url, timeout=30, **kw)
    r.raise_for_status()
    return r.json()

def xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

# ---------- block_cipher_starter: ECB decrypt oracle over encrypt_flag output ----------
try:
    ct = bytes.fromhex(get(f"{B}/block_cipher_starter/encrypt_flag/")["ciphertext"])
    pt = bytes.fromhex(get(f"{B}/block_cipher_starter/decrypt/{ct.hex()}/")["plaintext"])
    out["block_cipher_starter"] = pt.decode()
    print("bcs:", out["block_cipher_starter"])
except Exception as e:
    print("bcs FAIL", repr(e))

# ---------- ecbcbcwtf: CBC ct, ECB decrypt oracle -> P_i = D(C_i) ^ C_{i-1} ----------
try:
    ct = bytes.fromhex(get(f"{B}/ecbcbcwtf/encrypt_flag/")["ciphertext"])
    iv, blocks = ct[:16], [ct[i:i+16] for i in range(16, len(ct), 16)]
    flag = b""
    for i, c in enumerate(blocks):
        D = bytes.fromhex(get(f"{B}/ecbcbcwtf/decrypt/{c.hex()}/")["plaintext"])
        flag += xor(D, iv if i == 0 else blocks[i-1])
    out["ecbcbcwtf"] = flag.decode()
    print("wtf:", out["ecbcbcwtf"])
except Exception as e:
    print("wtf FAIL", repr(e))

# ---------- symmetry: OFB, attacker-chosen IV == flag IV, zero plaintext -> keystream ----------
try:
    ct = bytes.fromhex(get(f"{B}/symmetry/encrypt_flag/")["ciphertext"])
    iv, c = ct[:16], ct[16:]
    url = f"{B}/symmetry/encrypt/{'00'*len(c)}/{iv.hex()}/"
    ks = bytes.fromhex(get(url)["ciphertext"])
    flag = xor(c, ks)
    out["symmetry"] = flag.decode()
    print("sym:", out["symmetry"])
except Exception as e:
    print("sym FAIL", repr(e))

# ---------- flipping_cookie: IV bitflip 'admin=False;' -> 'admin=True;;' ----------
try:
    d = get(f"{B}/flipping_cookie/get_cookie/")
    full = bytes.fromhex(d["cookie"])
    iv, cookie = full[:16], full[16:]
    delta = bytes(16)
    dd = bytearray(16)
    pairs = [(6, 'F', 'T'), (7, 'a', 'r'), (8, 'l', 'u'), (9, 's', 'e'), (10, 'e', ';')]
    for pos, a, b in pairs:
        dd[pos] = ord(a) ^ ord(b)
    iv2 = xor(iv, bytes(dd))
    res = get(f"{B}/flipping_cookie/check_admin/{cookie.hex()}/{iv2.hex()}/")
    print("fc resp:", res)
    if "flag" in res:
        out["flipping_cookie"] = res["flag"]
    else:
        print("flipping_cookie: no flag in response", res)
except Exception as e:
    print("fc FAIL", repr(e))

# ---------- lazy_cbc: IV=KEY; receive(C||C) leaks D(C)^KEY for D(C)=P^KEY => KEY ----------
try:
    P = b"A" * 16
    C1 = bytes.fromhex(get(f"{B}/lazy_cbc/encrypt/{P.hex()}/")["ciphertext"])[:16]
    KEY = None
    for attempt in range(6):
        if attempt:
            P = bytes((i * 7 + attempt * 13) % 251 for i in range(16))
            C1 = bytes.fromhex(get(f"{B}/lazy_cbc/encrypt/{P.hex()}/")["ciphertext"])[:16]
        res = get(f"{B}/lazy_cbc/receive/{(C1+C1).hex()}/")
        if "error" not in res or "Invalid plaintext: " not in res.get("error", ""):
            print("lazy_cbc recv:", res)
            continue
        L = bytes.fromhex(res["error"].split("Invalid plaintext: ")[1])
        # block1 of leak = D(C1) ^ C1 = (P ^ KEY) ^ C1  =>  KEY = b1 ^ P ^ C1
        KEY = xor(xor(L[16:32], P), C1)
        res2 = get(f"{B}/lazy_cbc/get_flag/{KEY.hex()}/")
        if "plaintext" in res2:
            out["lazy_cbc"] = bytes.fromhex(res2["plaintext"]).decode()
            print("lazy:", out["lazy_cbc"])
            break
        KEY = None
    if "lazy_cbc" not in out:
        print("lazy_cbc FAILED")
except Exception as e:
    print("lazy FAIL", repr(e))

# ---------- passwords_as_keys: ECB, key = md5(word); offline brute with wordlist ----------
try:
    ct = bytes.fromhex(get(f"{B}/passwords_as_keys/encrypt_flag/")["ciphertext"])
    c = bytes.fromhex
    import urllib.request, os
    wpath = "words.txt"
    if not os.path.exists(wpath):
        url = "https://gist.githubusercontent.com/wchargin/8927565/raw/d9783627c731268fb2935a731a618aa8e95cf465/words"
        urllib.request.urlretrieve(url, wpath)
    words = [w.strip() for w in open(wpath, encoding="utf-8", errors="replace") if w.strip()]
    b0 = ct[:16]
    hit = None
    for w in words:
        k = hashlib.md5(w.encode()).digest()
        p = AES.new(k, AES.MODE_ECB).decrypt(b0)
        if p.startswith(b"crypto{") or p.startswith(b"crypto["):
            hit = (w, k)
            break
    if hit:
        w, k = hit
        pt = AES.new(k, AES.MODE_ECB).decrypt(ct)
        out["passwords_as_keys"] = pt.decode(errors="replace")
        print("pak word:", w, "->", out["passwords_as_keys"])
    else:
        print("passwords_as_keys: no word hit (wordlist %d)" % len(words))
except Exception as e:
    print("pak FAIL", repr(e))

import json
json.dump(out, open("res_easy.json", "w"), indent=2)
print("saved", len(out), "flags")
