import hashlib, sys
from Crypto.Cipher import AES
def dec(S, iv, ct):
    key = hashlib.sha1(str(S).encode('ascii')).digest()[:16]
    pt = AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct))
    try:
        pad = pt[-pt[-1]:]
        if all(b == len(pad) for b in pad): pt = pt[:-len(pad)]
    except Exception: pass
    try: return pt.decode()
    except Exception: return None
iv, ct = sys.argv[2], sys.argv[3]
for S in [int(x) for x in sys.argv[1:2]] + [0, 1]:
    r = dec(S, iv, ct)
    print(S, "->", r)
