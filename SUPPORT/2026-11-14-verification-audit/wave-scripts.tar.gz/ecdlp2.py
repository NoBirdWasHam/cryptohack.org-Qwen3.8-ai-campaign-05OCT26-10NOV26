"""Clean PH + rho helpers."""
from math import isqrt

def bsgs(E, G, H, r):
    """x with H=[x]G, G of order r (r prime)."""
    if H is None: return 0
    m = isqrt(r) + 1
    table = {}
    cur = None
    for j in range(m):
        if cur is not None and cur not in table: table[cur] = j
        cur = E.add(cur, G)
    Gm = E.mul(G, m)
    cur = H
    for i in range(m + 2):
        if cur in table:
            x = (table[cur] - i*m) % r
            if E.mul(G, x) == H: return x
        cur = E.add(cur, Gm)
    raise RuntimeError("bsgs failed")

def crt_pair(a, m, b, n):
    return (a + m * ((b - a) * pow(m, -1, n) % n)) % (m*n)

def ph(E, G, H, ordG, fac, large=None, small_lim=10**12):
    """DLP x=log_G H via Pohlig-Hellman. fac: dict q -> v_q(ordG).
    'large': dict q -> value mod q for prime factors > small_lim (precomputed by rho)."""
    large = large or {}
    x, mod = 0, 1
    for q in sorted(fac):
        e = 0; t = ordG
        while t % q == 0: t //= q; e += 1
        pe = q**e
        if q > small_lim:
            xi = large[q] % pe
        else:
            Gq = E.mul(G, ordG // pe)   # order pe
            Hq = E.mul(H, ordG // pe)
            xi = 0
            gq = E.mul(Gq, pe // q)     # order q
            for k in range(e):
                rem = E.add(Hq, E.inv(E.mul(Gq, xi)))
                hk = E.mul(rem, pe // (q**(k+1)))
                dk = bsgs(E, gq, hk, q)
                xi += dk * (q**k)
        x = crt_pair(x, mod, xi, pe)
        mod *= pe
    return x % mod

def rho(E, G, H, r, dp_bits=16, verbose=False):
    """Pollard lambda w/ distinguished points. H=[x]G, ord(G)=r prime."""
    if H is None: return 0
    GpH = E.add(G, H)
    mask = (1 << dp_bits) - 1
    def step(X, a, b):
        i = X[0] % 3
        if i == 0: return E.add(X, G), (a + 1) % r, b
        if i == 1: return E.add(X, H), a, (b + 1) % r
        return E.add(X, GpH), a, b
    trials = 0
    while True:
        trials += 1
        X = GpH
        a, b = 1, 1
        seen = {}
        while True:
            if X[0] & mask == 0:
                if X in seen:
                    a0, b0 = seen[X]
                    if (b - b0) % r:
                        xx = (a0 - a) * pow(b - b0, -1, r) % r
                        if E.mul(G, xx) == H:
                            if verbose: print("rho solved after trials", trials, flush=True)
                            return xx
                    break
                seen[X] = (a, b)
            X, a, b = step(X, a, b)
            if X is None:
                break  # walked to infinity, restart
