import json, hashlib, re, sympy
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
txt = open('eg_relay_DH64.txt').read()
p  = int(re.search(r'"p": "0x([0-9a-f]+)"', txt).group(1), 16)
g  = int(re.search(r'"g": "0x([0-9a-f]+)"', txt).group(1), 16)
A  = int(re.search(r'"A": "0x([0-9a-f]+)"', txt).group(1), 16)
B  = int(re.search(r'"B": "0x([0-9a-f]+)"', txt).group(1), 16)
iv = re.search(r'"iv": "([0-9a-f]+)"', txt).group(1)
ct = re.search(r'"encrypted_flag": "([0-9a-f]+)"', txt).group(1)
a = sympy.ntheory.residue_ntheory.discrete_log(p, A, g, phi=p-1)
assert pow(g, a, p) == A
S = pow(B, a, p)
print("a =", a, "S =", S)
key = hashlib.sha1(str(S).encode('ascii')).digest()[:16]
pt = AES.new(key, AES.MODE_CBC, bytes.fromhex(iv)).decrypt(bytes.fromhex(ct))
flag = unpad(pt, 16).decode()
print("FLAG:", flag)
open('eg_flag.txt','w').write(flag)
