import socket, sys, time
host, port = 'socket.cryptohack.org', int(sys.argv[1])
lines = sys.argv[2] if len(sys.argv) > 2 else ''
s = socket.create_connection((host, port), timeout=15)
s.settimeout(12)
log = []
def rd():
    try:
        d = s.recv(65536)
    except socket.timeout:
        return '<TIMEOUT>'
    if not d: return '<EOF>'
    t = d.decode(errors='replace')
    log.append('<<< ' + t)
    return t
print(rd())
for ln in filter(None, lines.split('|')):
    if ln == 'SLEEP':
        time.sleep(6); continue
    if ln == 'RD2':
        print(rd()); print(rd()); continue
    print('>>> ' + ln)
    s.sendall((ln + '\n').encode())
    print(rd())
open(sys.argv[3], 'w').write('\n'.join(log))
s.close()
