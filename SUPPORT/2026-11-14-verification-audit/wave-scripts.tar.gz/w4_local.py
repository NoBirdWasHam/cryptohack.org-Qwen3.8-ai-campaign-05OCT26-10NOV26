import sys, json, hashlib
sys.path.insert(0, r'~/AppData/Local/hermes/cache/scratch')
from eclib import Curve
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import sympy

res = {}
# ---- dh1: inverse of 209 mod 991
inv = pow(209, -1, 991)
assert 209*inv % 991 == 1
res['dh-starter-1'] = str(inv)

# ---- dh2: smallest primitive root mod 28151
p = 28151
assert sympy.isprime(p)
fac = sympy.factorint(p-1)  # {2:1, ...}
def is_gen(g):
    return all(pow(g, (p-1)//q, p) != 1 for q in fac)
g = 2
while not is_gen(g): g += 1
res['dh-starter-2'] = str(g)
print("dh2 factor(p-1) =", fac, "g =", g)

# ---- dh3/4/5 solved separately (parsed straight from statement text)
dhfix = json.load(open(r'~/AppData/Local/hermes/cache/scratch/w4_dh.json'))
res['dh-starter-3'] = dhfix['dh-starter-3']
res['dh-starter-4'] = dhfix['dh-starter-4']
res['dh-starter-5'] = dhfix['dh-starter-5']

# ---- ECC starters on E: y^2=x^3+497x+1768 mod 9739
E = Curve(497, 1768, 9739)
assert E.mul((5323,5438), 1337) == (1089, 6931)      # ecc2 test
assert E.add((5274,2841),(8669,740)) == (1024, 4440) # ecc1 test
assert E.add((5274,2841),(5274,2841)) == (7284,2107)
# ecc0
P = (8045, 6936); assert E.on(P)
Q = E.inv(P); assert E.add(P, Q) is None
res['ecc0'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR' % Q
# ecc1
Pq, Qq, Rq = (493,5564),(1539,4742),(4403,5202)
for Pt in (Pq,Qq,Rq): assert E.on(Pt)
S = E.add(E.add(E.add(Pq,Pq),Qq),Rq); assert E.on(S)
res['ecc1'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR' % S
# ecc2
P2 = (2339,2213); assert E.on(P2)
Q2 = E.mul(P2, 7863); assert E.on(Q2)
res['ecc2'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR' % Q2
# ecc3: shared=[1829]QA, key sha1 hexdigest of x
G3 = (1804,5368); QA = (815,3190); assert E.on(G3) and E.on(QA)
S3 = E.mul(QA, 1829); assert E.on(S3)
res['ecc3'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR' % hashlib.sha1(str(S3[0]).encode('ascii')).hexdigest()
# ecc4: x-only
xQA = 4726
rhs = (xQA**3 + 497*xQA + 1768) % 9739
y = pow(rhs, (9739+1)//4, 9739)
assert y*y % 9739 == rhs
for yA in (y, (-y) % 9739):
    S4 = E.mul((xQA, yA), 6534)
    key4 = hashlib.sha1(str(S4[0]).encode('ascii')).digest()[:16]
    iv4 = bytes.fromhex('cd9da9f1c60925922377ea952afc212c')
    ct4 = bytes.fromhex('febcbe3a3414a730b125931dccf912d2239f3e969c4334d95ed0ec86f6449ad8')
    try:
        flag4 = unpad(AES.new(key4, AES.MODE_CBC, iv4).decrypt(ct4), 16).decode()
        res['ecc4'] = flag4
        print("ecc4 x shared =", S4[0], "flag:", flag4)
        break
    except Exception as e:
        print("ecc4 y=%d failed: %r" % (yA, e))

# ---- ladder: Montgomery y^2 = x^3 + 486662 x^2 + x over 2^255-19, G.x=9, k=0x1337c0decafe
p255 = 2**255 - 19
A, B = 486662, 1
xG = 9
import sympy
rhsG = (xG**3 + A*xG*xG + xG) % p255
from sympy.ntheory.residue_ntheory import sqrt_mod
yG = int(sqrt_mod(rhsG, p255))
assert yG*yG % p255 == rhsG
def madd(P_, Q_):
    x1,y1 = P_; x2,y2 = Q_
    assert x1 != x2
    al = (y2-y1)*pow(x2-x1, -1, p255) % p255
    x3 = (B*al*al - A - x1 - x2) % p255
    return (x3, (al*(x1-x3)-y1) % p255)
def mdbl(P_):
    x1,y1 = P_
    al = (3*x1*x1 + 2*A*x1 + 1)*pow(2*B*y1, -1, p255) % p255
    x3 = (B*al*al - A - 2*x1) % p255
    return (x3, (al*(x1-x3)-y1) % p255)
# x-only Montgomery ladder (differential xADD/xDBL, needs no y)
def xdbl(x):
    num = pow(x*x - 1, 2, p255)
    den = 4*x % p255 * (x*x + A*x + 1) % p255
    return num * pow(den, -1, p255) % p255
def xadd(xm, x, xp):
    num = pow(x*xp - 1, 2, p255)
    den = xm * (x - xp)**2 % p255
    return num * pow(den, -1, p255) % p255
def mladder_xonly(xP, k):
    x0, x1 = xP, xdbl(xP)
    for i in range(k.bit_length()-2, -1, -1):
        if (k >> i) & 1 == 0:
            x0, x1 = xdbl(x0), xadd(xP, x0, x1)
        else:
            x0, x1 = xadd(xP, x0, x1), xdbl(x1)
    return x0
k = 0x1337c0decafe
res_x = mladder_xonly(xG, k)
# cross-check with plain affine double-and-add (both y-signs)
def madd_da(P_, n):
    R = None; Qd = P_
    while n:
        if n & 1:
            R = Qd if R is None else madd(R, Qd)
        Qd = mdbl(Qd); n >>= 1
    return R
Qa = madd_da((xG, yG), k)
Qa2 = madd_da((xG, (-yG) % p255), k)
assert Qa[0] == res_x and Qa2[0] == res_x, "ladder/DA mismatch"
y = Qa[1]; assert (y*y - (Qa[0]**3 + A*Qa[0]**2 + Qa[0])) % p255 == 0
res['ladder'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR' % res_x
res['bg'] = 'FLAG-REDACTED-SEE-FLAGS-MIRROR'

json.dump({k: v for k, v in res.items()}, open(r'~/AppData/Local/hermes/cache/scratch/w4_local.json','w'), indent=1)
for kk, vv in res.items():
    print(kk, '=', vv if not isinstance(vv, tuple) else str(vv)[:80])
