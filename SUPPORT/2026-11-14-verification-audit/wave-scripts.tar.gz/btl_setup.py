import sympy
p = 92935740571
print("p prime:", sympy.isprime(p), "p%4:", p % 4)
f = sympy.factorint(p + 1)
print("p+1 =", f)
l0 = 23233935143
print("23233935143 prime:", sympy.isprime(l0))

# F_p^2 arithmetic: i^2 = -1
class E2:
    __slots__ = ("a", "b")
    def __init__(self, a, b):
        self.a = a % p; self.b = b % p
    def __add__(o1, o2): return E2(o1.a + o2.a, o1.b + o2.b)
    def __sub__(o1, o2): return E2(o1.a - o2.a, o1.b - o2.b)
    def __mul__(o1, o2):
        if isinstance(o2, int):
            return E2(o1.a * o2, o1.b * o2)
        # karatsuba
        z0 = o1.a * o2.a; z2 = o1.b * o2.b
        z1 = (o1.a + o1.b) * (o2.a + o2.b) - z0 - z2
        return E2(z0 - z2, z1)
    def __rmul__(o1, o2):
        if isinstance(o2, int):
            return E2(o1.a * o2, o1.b * o2)
        raise TypeError
    def neg(o1): return E2(-o1.a, -o1.b)
    def inv(o1):
        n = (o1.a * o1.a + o1.b * o1.b) % p
        ni = pow(n, p - 2, p)
        return E2(o1.a * ni, -o1.b * ni)
    def conj(o1): return E2(o1.a, -o1.b)
    def __eq__(o1, o2): return o1.a == o2.a and o1.b == o2.b
    def sq(o1): return o1 * o1

ONE = E2(1, 0); ZERO = E2(0, 0)

# Curve E: y^2 = x^3 + x, affine (few ops needed for order test)
def padd(P, Q):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P; x2, y2 = Q
    if x1 == x2:
        if (y1 + y2) == ZERO: return None
        m = (x1*x1*3 + ONE) * (y1 + y1).inv()
    else:
        m = (y2 - y1) * (x2 - x1).inv()
    x3 = m*m - x1 - x2
    y3 = m*(x1 - x3) - y1
    return (x3, y3)

def pmul(k, P):
    R = None
    while k:
        if k & 1: R = padd(R, P)
        P = padd(P, P); k >>= 1
    return R

Kx = E2(6312697112, 11428792286)
Ky = E2(30552079595, 78608501229)
# on curve? y^2 ?= x^3 + x
print("on curve:", (Ky*Ky) == (Kx*Kx*Kx + Kx))

l0 = 23233935143
# order of K divides p+1 = 4*l0. Test.
Q = pmul(4, (Kx, Ky))
print("4K is O:", Q is None)
Q = pmul(l0, (Kx, Ky))
print("l0*K is O:", Q is None)
Q = pmul(2 * l0, (Kx, Ky))
print("2*l0*K is O:", Q is None)
