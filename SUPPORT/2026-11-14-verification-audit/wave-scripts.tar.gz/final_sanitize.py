"""Final sanitizer + flag-string policy pass over the published tree.
Shared classifier for scrub + verification (single source of truth)."""
import pathlib, re, json

OUT = pathlib.Path(r"~/Practice_runs/cryptohack_org/_REPO_BUILD/cryptohack.org-Qwen3.8-ai-campaign-05OCT26-10NOV26")

PII_SUBS = [
    (re.compile(r"[A-Za-z]:[\\/]+Users[\\/]+[\w.-]+", re.I), "~"),
    (re.compile(r"/c/Users/[\w.-]+", re.I), "~"),
    (re.compile(r"/home/(?!example)[\w.-]+"), "~"),
    (re.compile(r"192\.168\.\d+\.\d+"), "LAN-HOST"),
    (re.compile(r"(?<![\w])Strata(?![\w])"), "GPU-HOST"),
    (re.compile(r"(?<![\w])sparrow[\w.-]*(?![\w])", re.I), "ACCOUNT"),
    (re.compile(r"(?<![\w])GTF\w*(?![\w])"), "USER"),
    (re.compile(r'(_csrf_token["\']?\s*[:=]\s*["\'])([A-Za-z0-9]{16,})(["\'])'), r"\1REDACTED\3"),
]
PII_DETECT = [re.compile(r"C:\\+Users\\+(?!example)[A-Za-z0-9._-]+"),
              re.compile(r"/c/Users/(?!.*\.\.\.)[\w.-]+", re.I),
              re.compile(r"/home/(?!example)[\w.-]+"),
              re.compile(r"192\.168\.\d+\.\d+"),
              re.compile(r"(?<![\w])Strata(?![\w])"),
              re.compile(r"(?<![\w])[Ss]parrow[\w.-]*(?![\w])"),
              re.compile(r"(?<![\w])GTF\w*(?![\w])")]

FS = re.compile(r"crypto\{[^}\n]{1,160}\}|cryptohack\{[^}\n]{1,160}\}", re.I)
KEEP_TOKENS = ["test", "local", "fake", "simulated", "selfcheck", "selftest", "revalidation",
    "example", "...", "…", "?", "{n}", "{t}", "str(v)", "%019x", "{str", "37", "24 secret",
    "26 bytes", "suffix", "prefix", "middle", "zkpr00f", "ag41n_zk", "fishy_fischlin", "tetctf",
    "index(", "split", "startswith", "endswith", "ends `", "` +", "`/", "ord(", "j < 7", "'{",
    '"{', '{"', "big-endian", "tail-zero", "x1", "c1", "flag value withheld", "f4ke", "l0c4l"]
def flagstr_keep(s: str) -> bool:
    low = s.lower()
    core = s[s.find("{")+1:]
    if set(core.rstrip("}")) <= set("?."): return True
    return any(tok in low for tok in KEEP_TOKENS)

EXTS = (".md",".py",".txt",".log",".json",".jsonl",".sh",".gp",".sage",".yaml")
n_pii = n_leak = files_t = 0
for f in OUT.rglob("*"):
    rel = f.relative_to(OUT)
    if not f.is_file() or rel.parts[0] in ("FLAGS", ".git") or f.suffix not in EXTS: continue
    t = f.read_text(encoding="utf-8", errors="replace")
    t0 = t
    for p, r in PII_SUBS:
        t, _ = p.subn(r, t)
    vals = [m.group(0) for m in FS.finditer(t)]
    for v in vals:
        if not flagstr_keep(v):
            t = t.replace(v, "[flag value withheld — real-flag strings live only under FLAGS/]")
    if t != t0:
        f.write_text(t, encoding="utf-8"); files_t += 1
        n_pii += sum(len(p.findall(t0)) for p in PII_DETECT)
        n_leak += sum(1 for v in vals if not flagstr_keep(v))
print("sanitizer pass: files touched", files_t, "| PII sanitized ~", n_pii, "| flag strings scrubbed", n_leak)

# whole-tree detect (must be zero, incl. FLAGS-external binary-ish we skip by design)
hits = 0
for f in OUT.rglob("*"):
    rel = f.relative_to(OUT)
    if not f.is_file() or rel.parts[0] in ("FLAGS", ".git") or f.suffix not in EXTS: continue
    t = f.read_text(encoding="utf-8", errors="replace")
    hits += sum(len(p.findall(t)) for p in PII_DETECT)
    hits += sum(1 for m in FS.finditer(t) if not flagstr_keep(m.group(0)))
print("residual PII+leak hits:", hits)
